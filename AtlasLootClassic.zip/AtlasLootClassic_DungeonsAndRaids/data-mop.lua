-----------------------------------------------------------------------
-- Upvalued Lua API.
-----------------------------------------------------------------------
local _G = getfenv(0)
local select = _G.select
local string = _G.string
local format = string.format

-- WoW

-- ----------------------------------------------------------------------------
-- AddOn namespace.
-- ----------------------------------------------------------------------------
local addonname = ...
local AtlasLoot = _G.AtlasLoot
if AtlasLoot:GameVersion_LT(AtlasLoot.MOP_VERSION_NUM) then return end
local data = AtlasLoot.ItemDB:Add(addonname, 1, AtlasLoot.MOP_VERSION_NUM)

local AL = AtlasLoot.Locales
local ALIL = AtlasLoot.IngameLocales
local NORMAL_DIFF = data:AddDifficulty("NORMAL", nil, nil, nil, true)
local HEROIC_DIFF = data:AddDifficulty("HEROIC", nil, nil, nil, true)
local CELESTIAL_DIFF = data:AddDifficulty("CELESTIAL", nil, nil, nil, true)
local VENDOR_DIFF = data:AddDifficulty(AL["Vendor"], "vendor", 0)
--- For SoO and WoD classic (lol) pre-patch
--local MYTHIC_DIFF = data:AddDifficulty(AL["Mythic"], nil, nil, nil, true)

local NORMAL_ITTYPE = data:AddItemTableType("Item", "Item")
local SET_ITTYPE = data:AddItemTableType("Set", "Item")
local AC_ITTYPE = data:AddItemTableType("Achievement", "Item")

local DUNGEON_CONTENT = data:AddContentType(AL["Dungeons"], ATLASLOOT_DUNGEON_COLOR)
local RAID_CONTENT = data:AddContentType(AL["Raids"], ATLASLOOT_RAID40_COLOR)

-- extra
local CLASS_NAME = AtlasLoot:GetColoredClassNames()

-- name formats
local NAME_COLOR, NAME_COLOR_BOSS = "|cffC0C0C0", "|cffC0C0C0"

-- colors
--local BLUE = "|cff6666ff%s|r"
--local GREY = "|cff999999%s|r"
--local GREEN = "|cff66cc33%s|r"
local RED = "|cffcc6666%s|r"
local PURPLE = "|cff9900ff%s|r"
local WHITE = "|cffffffff%s|r"

-- format
local BONUS_LOOT_SPLIT = "%s - %s"

local T14_SET = {
    name = format(AL["Tier %s Sets"], "14"),
    ExtraList = true,
    TableType = SET_ITTYPE,
    IgnoreAsSource = true,
    [CELESTIAL_DIFF] = {
        {1, 50001143 }, -- Warlock
        {3, 50001137 }, -- Priest Holy
        {4, 50001138 }, -- Priest Shadow
        {6, 50001139 }, -- Rogue
        {8, 50001129 }, -- Hunter
        {10, 50001145 }, -- Warrior Tank
        {11, 50001144 }, -- Warrior Dps
        {13, 50001124 }, -- Death Knight Tank
        {14, 50001123 }, -- Death Knight DPS
        {16, 50001130 }, -- Mage
        {18, 50001125 }, -- Druid Resto
        {19, 50001126 }, -- Druid Balance
        {20, 50001127 }, -- Druid Feral
        {21, 50001128 }, -- Druid Guardian
        {23, 50001141 }, -- Shaman Resto
        {24, 50001140 }, -- Shaman Elemental
        {25, 50001142 }, -- Shaman Enhance
        {27, 50001134 }, -- Paladin Holy
        {28, 50001136 }, -- Paladin Prot
        {29, 50001135 }, -- Paladin DPS
        {101, 50001131 }, -- Monk Mistweaver
        {102, 50001133 }, -- Monk Brewmaster
        {103, 50001132 }, -- Monk Windwalker
     },
    [NORMAL_DIFF] = {
        {1, 50011143 }, -- Warlock
        {3, 50011137 }, -- Priest Holy
        {4, 50011138 }, -- Priest Shadow
        {6, 50011139 }, -- Rogue
        {8, 50011129 }, -- Hunter
        {10, 50011145 }, -- Warrior Tank
        {11, 50011144 }, -- Warrior Dps
        {13, 50011124 }, -- Death Knight Tan
        {14, 50011123 }, -- Death Knight DPS
        {16, 50011130 }, -- Mage
        {18, 50011125 }, -- Druid Resto
        {19, 50011126 }, -- Druid Balance
        {20, 50011127 }, -- Druid Feral
        {21, 50011128 }, -- Druid Guardian
        {23, 50011141 }, -- Shaman Resto
        {24, 50011140 }, -- Shaman Elemental
        {25, 50011142 }, -- Shaman Enhance
        {27, 50011134 }, -- Paladin Holy
        {28, 50011136 }, -- Paladin Prot
        {29, 50011135 }, -- Paladin DPS
        {101, 50011131 }, -- Monk Mistweaver
        {102, 50011133 }, -- Monk Brewmaster
        {103, 50011132 }, -- Monk Windwalker
    },
    [HEROIC_DIFF] = {
        {1, 50021143 }, -- Warlock
        {3, 50021137 }, -- Priest Holy
        {4, 50021138 }, -- Priest Shadow
        {6, 50021139 }, -- Rogue
        {8, 50021129 }, -- Hunter
        {10, 50021145 }, -- Warrior Tank
        {11, 50021144 }, -- Warrior Dps
        {13, 50021124 }, -- Death Knight Tan
        {14, 50021123 }, -- Death Knight DPS
        {16, 50021130 }, -- Mage
        {18, 50021125 }, -- Druid Resto
        {19, 50021126 }, -- Druid Balance
        {20, 50021127 }, -- Druid Feral
        {21, 50021128 }, -- Druid Guardian
        {23, 50021141 }, -- Shaman Resto
        {24, 50021140 }, -- Shaman Elemental
        {25, 50021142 }, -- Shaman Enhance
        {27, 50021134 }, -- Paladin Holy
        {28, 50021136 }, -- Paladin Prot
        {29, 50021135 }, -- Paladin DPS
        {101, 50021131 }, -- Monk Mistweaver
        {102, 50021133 }, -- Monk Brewmaster
        {103, 50021132 }, -- Monk Windwalker
    },
}

local T15_SET = {
    name = format(AL["Tier %s Sets"], "15"),
    ExtraList = true,
    TableType = SET_ITTYPE,
    IgnoreAsSource = true,
    ContentPhaseMoP = 3,
    [CELESTIAL_DIFF] = {
        { 1, 50001171 }, -- Warlock
        { 3, 50001165 }, -- Priest Holy
        { 4, 50001166 }, -- Priest Shadow
        { 6, 50001167 }, -- Rogue
        { 8, 50001157 }, -- Hunter
        { 10, 50001173 }, -- Warrior Tank
        { 11, 50001172 }, -- Warrior Dps
        { 13, 50001151 }, -- Death Knight Tank
        { 14, 50001152 }, -- Death Knight DPS
        { 16, 50001158 }, -- Mage
        { 18, 50001154 }, -- Druid Resto
        { 19, 50001156 }, -- Druid Guardian
        { 20, 50001155 }, -- Druid Balance
        { 21, 50001153 }, -- Druid Feral
        { 23, 50001168 }, -- Shaman Resto
        { 24, 50001170 }, -- Shaman Elemental
        { 25, 50001169 }, -- Shaman Enhance
        { 27, 50001163 }, -- Paladin Holy
        { 28, 50001164 }, -- Paladin Prot
        { 29, 50001162 }, -- Paladin DPS
        { 101, 50001160 }, -- Monk Mistweaver
        { 102, 50001161 }, -- Monk Brewmaster
        { 103, 50001159 }, -- Monk Windwalker
    },
    [NORMAL_DIFF] = {
        { 1, 50011171 }, -- Warlock
        { 3, 50011165 }, -- Priest Holy
        { 4, 50011166 }, -- Priest Shadow
        { 6, 50011167 }, -- Rogue
        { 8, 50011157 }, -- Hunter
        { 10, 50011173 }, -- Warrior Tank
        { 11, 50011172 }, -- Warrior Dps
        { 13, 50011151 }, -- Death Knight Tank
        { 14, 50011152 }, -- Death Knight DPS
        { 16, 50011158 }, -- Mage
        { 18, 50011154 }, -- Druid Resto
        { 19, 50011156 }, -- Druid Guardian
        { 20, 50011155 }, -- Druid Balance
        { 21, 50011153 }, -- Druid Feral
        { 23, 50011168 }, -- Shaman Resto
        { 24, 50011170 }, -- Shaman Elemental
        { 25, 50011169 }, -- Shaman Enhance
        { 27, 50011163 }, -- Paladin Holy
        { 28, 50011164 }, -- Paladin Prot
        { 29, 50011162 }, -- Paladin DPS
        { 101, 50011160 }, -- Monk Mistweaver
        { 102, 50011161 }, -- Monk Brewmaster
        { 103, 50011159 }, -- Monk Windwalker
    },
    [HEROIC_DIFF] = {
        { 1, 50021171 }, -- Warlock
        { 3, 50021165 }, -- Priest Holy
        { 4, 50021166 }, -- Priest Shadow
        { 6, 50021167 }, -- Rogue
        { 8, 50021157 }, -- Hunter
        { 10, 50021173 }, -- Warrior Tank
        { 11, 50021172 }, -- Warrior Dps
        { 13, 50021151 }, -- Death Knight Tank
        { 14, 50021152 }, -- Death Knight DPS
        { 16, 50021158 }, -- Mage
        { 18, 50021154 }, -- Druid Resto
        { 19, 50021156 }, -- Druid Guardian
        { 20, 50021155 }, -- Druid Balance
        { 21, 50021153 }, -- Druid Feral
        { 23, 50021168 }, -- Shaman Resto
        { 24, 50021170 }, -- Shaman Elemental
        { 25, 50021169 }, -- Shaman Enhance
        { 27, 50021163 }, -- Paladin Holy
        { 28, 50021164 }, -- Paladin Prot
        { 29, 50021162 }, -- Paladin DPS
        { 101, 50021160 }, -- Monk Mistweaver
        { 102, 50021161 }, -- Monk Brewmaster
        { 103, 50021159 }, -- Monk Windwalker
    },
}

local T16_SET = {
    name = format(AL["Tier %s Sets"], "16"),
    ExtraList = true,
    TableType = SET_ITTYPE,
    IgnoreAsSource = true,
    ContentPhaseMoP = 5,
    [CELESTIAL_DIFF] = {
        { 1, 50001181 }, -- Warlock
        { 3, 50001187 }, -- Priest Holy
        { 4, 50001186 }, -- Priest Shadow
        { 6, 50001185 }, -- Rogue
        { 8, 50001195 }, -- Hunter
        { 10, 50001179 }, -- Warrior Tank
        { 11, 50001180 }, -- Warrior Dps
        { 13, 50001201 }, -- Death Knight Tank
        { 14, 50001200 }, -- Death Knight DPS
        { 16, 50001194 }, -- Mage
        { 18, 50001198 }, -- Druid Resto
        { 19, 50001196 }, -- Druid Guardian
        { 20, 50001197 }, -- Druid Balance
        { 21, 50001199 }, -- Druid Feral
        { 23, 50001184 }, -- Shaman Resto
        { 24, 50001182 }, -- Shaman Elemental
        { 25, 50001183 }, -- Shaman Enhance
        { 27, 50001189 }, -- Paladin Holy
        { 28, 50001188 }, -- Paladin Prot
        { 29, 50001190 }, -- Paladin DPS
        { 101, 50001192 }, -- Monk Mistweaver
        { 102, 50001191 }, -- Monk Brewmaster
        { 103, 50001193 }, -- Monk Windwalker
    },
    [NORMAL_DIFF] = {
        { 1, 50021181 }, -- Warlock
        { 3, 50021187 }, -- Priest Holy
        { 4, 50021186 }, -- Priest Shadow
        { 6, 50021185 }, -- Rogue
        { 8, 50021195 }, -- Hunter
        { 10, 50021179 }, -- Warrior Tank
        { 11, 50021180 }, -- Warrior Dps
        { 13, 50021201 }, -- Death Knight Tank
        { 14, 50021200 }, -- Death Knight DPS
        { 16, 50021194 }, -- Mage
        { 18, 50021198 }, -- Druid Resto
        { 19, 50021196 }, -- Druid Guardian
        { 20, 50021197 }, -- Druid Balance
        { 21, 50021199 }, -- Druid Feral
        { 23, 50021184 }, -- Shaman Resto
        { 24, 50021182 }, -- Shaman Elemental
        { 25, 50021183 }, -- Shaman Enhance
        { 27, 50021189 }, -- Paladin Holy
        { 28, 50021188 }, -- Paladin Prot
        { 29, 50021190 }, -- Paladin DPS
        { 101, 50021192 }, -- Monk Mistweaver
        { 102, 50021191 }, -- Monk Brewmaster
        { 103, 50021193 }, -- Monk Windwalker
    },
    [HEROIC_DIFF] = {
        { 1, 50031181 }, -- Warlock
        { 3, 50031187 }, -- Priest Holy
        { 4, 50031186 }, -- Priest Shadow
        { 6, 50031185 }, -- Rogue
        { 8, 50031195 }, -- Hunter
        { 10, 50031179 }, -- Warrior Tank
        { 11, 50031180 }, -- Warrior Dps
        { 13, 50031201 }, -- Death Knight Tank
        { 14, 50031200 }, -- Death Knight DPS
        { 16, 50031194 }, -- Mage
        { 18, 50031198 }, -- Druid Resto
        { 19, 50031196 }, -- Druid Guardian
        { 20, 50031197 }, -- Druid Balance
        { 21, 50031199 }, -- Druid Feral
        { 23, 50031184 }, -- Shaman Resto
        { 24, 50031182 }, -- Shaman Elemental
        { 25, 50031183 }, -- Shaman Enhance
        { 27, 50031189 }, -- Paladin Holy
        { 28, 50031188 }, -- Paladin Prot
        { 29, 50031190 }, -- Paladin DPS
        { 101, 50031192 }, -- Monk Mistweaver
        { 102, 50031191 }, -- Monk Brewmaster
        { 103, 50031193 }, -- Monk Windwalker
    },
}

local MOP_DUNGEON_HERO_AC_TABLE = {	--[Pandaria Dungeon Hero]
    name = select(2, GetAchievementInfo(6925)),
    TableType = AC_ITTYPE,
    ExtraList = true,
    CoinTexture = "Achievement",
    [HEROIC_DIFF] = {
        { 1, 6925 },
        { 2, 6758 },			{ 17, 6456 },
        { 3, 6756 },			{ 18, 6470 },
        { 4, 6759 },			{ 19, 6760 },
        { 5, 6761 },			{ 20, 6762 },
        { 6, 6763 }
    },
}

local MOP_CELESTIAL_HERO_AC_TABLE = {	--[Pandaria Celestial Hero]
    name = select(2, GetAchievementInfo(60901)),
    TableType = AC_ITTYPE,
    ExtraList = true,
    CoinTexture = "Achievement",
    [CELESTIAL_DIFF] = {
        { 1, 60901 },
        { 2, 60892 },			{ 17, 60893 },
        { 3, 60894 },			{ 18, 60895 },
        { 4, 60896 },			{ 19, 60897 },
        { 5, 60898 },			{ 20, 60899 },
        { 6, 60900 }
    },
}

local MOP_GLORY_OF_THE_HERO_AC_TABLE = {		--[Glory of the Pandaria Hero]
    name = select(2, GetAchievementInfo(6927)),
    TableType = AC_ITTYPE,
    ExtraList = true,
    CoinTexture = "Achievement",
    [HEROIC_DIFF] = {
        { 1, 6927 },
        { 2, 6925 },			{ 17, 6460 },
        { 3, 6475 },			{ 18, 6671 },
        { 4, 6420 },			{ 19, 6089 },
        { 5, 6400 },			{ 20, 6402 },
        { 6, 6478 },			{ 21, 6736 },
        { 7, 6713 },			{ 22, 6477 },
        { 8, 6472 },			{ 23, 6471 },
        { 9, 6479 },			{ 24, 6476 },
        { 10, 6684 },			{ 25, 6427 },
        { 11, 6928 },			{ 26, 6929 },
        { 12, 6531 },			{ 27, 6394 },
        { 13, 6396 },			{ 28, 6821 },
        { 14, 6688 },			{ 29, 6485 },
        { 15, 6822 },			{ 30, 6715 },
    },
}

local MOP_RAID1_AC_TABLE = {	-- Glory of the Pandaria Raider
    name = select(2, GetAchievementInfo(6932)),
    TableType = AC_ITTYPE,
    ExtraList = true,
    CoinTexture = "Achievement",
    [NORMAL_DIFF] = {
        { 1, 6932 },
        { 2, 6823 },			{ 17, 6674 },
        { 3, 7056 },			{ 18, 6687 },
        { 4, 6686 },			{ 19, 6455 },
        { 5, 6937 },			{ 20, 6936 },
        { 6, 6553 },			{ 21, 6683 },
        { 7, 6518 },			{ 22, 6922 },
        { 8, 6717 },			{ 23, 6824 },
        { 9, 6933 },			{ 24, 6825 },
    },
    [HEROIC_DIFF] = {
        { 1, 6932 },
        { 2, 6719 },			{ 17, 6720 },
        { 3, 6721 },			{ 18, 6722 },
        { 4, 6723 },			{ 19, 6724 },
        { 5, 6725 },			{ 20, 6726 },
        { 6, 6727 },			{ 21, 6728 },
        { 7, 6729 },			{ 22, 6730 },
        { 8, 6731 },			{ 23, 6732 },
        { 9, 6733 }
    },
}

local MOP_RAID2_AC_TABLE = {	-- Glory of the Thundering Raider
    name = select(2, GetAchievementInfo(8124)),
    TableType = AC_ITTYPE,
    ExtraList = true,
    ContentPhaseMoP = 3,
    CoinTexture = "Achievement",
    [NORMAL_DIFF] = {
        { 1, 8124 },
        { 2, 8038 },			{ 17, 8094 },
        { 3, 8077 },			{ 18, 8073 },
        { 4, 8097 },			{ 19, 8082 },
        { 5, 8037 },			{ 20, 8098 },
        { 6, 8087 },			{ 21, 8081 },
        { 7, 8090 },			{ 22, 8086 },
    },
    [HEROIC_DIFF] = {
        { 1, 8124 },
        { 2, 8056 },			{ 17, 8057 },
        { 3, 8058 },			{ 18, 8059 },
        { 4, 8060 },			{ 19, 8061 },
        { 5, 8062 },			{ 20, 8063 },
        { 6, 8064 },			{ 21, 8065 },
        { 7, 8066 }
    },
}

local PATTERNS_ILVL_496 = {		-- Patterns with iLvl 496 (Mogu, HoF, ToEs)
    name = AL["Patterns"],
    ExtraList = true,
    [NORMAL_DIFF] = {
        { 1, 86381 },	-- Pattern: Legacy of the Emperor
        { 2, 86379 },	-- Pattern: Robe of Eternal Rule
        { 3, 86380 },	-- Pattern: Imperial Silk Gloves
        { 4, 86382 },	-- Pattern: Touch of the Light
        { 6, 86238 },	-- Pattern: Chestguard of Nemeses
        { 7, 86281 },	-- Pattern: Nightfire Robe
        { 8, 86279 },	-- Pattern: Liferuned Leather Gloves
        { 9, 86280 },	-- Pattern: Murderer's Gloves
        { 10, 86283 },	-- Pattern: Raiment of Blood and Bone
        { 11, 86297 },	-- Pattern: Stormbreaker Chestguard
        { 12, 86272 },	-- Pattern: Fists of Lightning
        { 13, 86284 },	-- Pattern: Raven Lord's Gloves
        { 16, 87412 },	-- Plans: Chestplate of Limitless Faith
        { 17, 87410 },	-- Plans: Ornate Battleplate of the Master
        { 18, 87408 },	-- Plans: Unyielding Bloodplate
        { 19, 87411 },	-- Plans: Bloodforged Warfists
        { 20, 87409 },	-- Plans: Gauntlets of Battle Command
        { 21, 87413 },	-- Plans: Gauntlets of Unbound Devotion
    },
}

data["StormstoutBrewery"] = {
    EncounterJournalID = 302,
    InstanceID = 961,
    MapID = 5963,
    ContentType = DUNGEON_CONTENT,
    LevelRange = {85, 85, 90},
    items = {
        {	--BreweryOokOok
            EncounterJournalID = 668,
            [NORMAL_DIFF] = {
                { 1, 80897 },	-- Bracers of Displaced Air
                { 2, 80896 },	-- Nimbletoe Chestguard
                { 3, 80892 },	-- Ook's Hozen Slicer
            },
            [HEROIC_DIFF] = {
                { 1, 81064 },	-- Bracers of Displaced Air
                { 2, 81080 },	-- Nimbletoe Chestguard
                { 3, 81134 },	-- Barreldodger Boots
                { 4, 81133 },	-- Empty Fruit Barrel
                { 5, 81061 },	-- Ook's Hozen Slicer
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 18, "ac6089" },
            },
            [CELESTIAL_DIFF] = {
                { 1, 81064 },	-- Bracers of Displaced Air
                { 2, 81080 },	-- Nimbletoe Chestguard
                { 3, 81134 },	-- Barreldodger Boots
                { 4, 81133 },	-- Empty Fruit Barrel
                { 5, 81061 },	-- Ook's Hozen Slicer
                { 16, "c3414", [ATLASLOOT_IT_AMOUNT1] = 2 }, -- August Stone Shard
                { 17, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 19, "ac6089" },
            },
        },
        {	--BreweryHoptallus
            EncounterJournalID = 669,
            [NORMAL_DIFF] = {
                { 1, 80898 },	-- Hopping Mad Leggings
                { 2, 80899 },	-- Bubble-Breaker Bracers
                { 3, 80893 },	-- Bottle of Potent Potables
            },
            [HEROIC_DIFF] = {
                { 1, 81136 },	-- Cloak of Hidden Flasks
                { 2, 81135 },	-- Belt of Brazen Inebriation
                { 3, 81077 },	-- Hopping Mad Leggings
                { 4, 81065 },	-- Bubble-Breaker Bracers
                { 5, 81076 },	-- Bottle of Potent Potables
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
            },
            [CELESTIAL_DIFF] = {
                { 1, 81136 },	-- Cloak of Hidden Flasks
                { 2, 81135 },	-- Belt of Brazen Inebriation
                { 3, 81077 },	-- Hopping Mad Leggings
                { 4, 81065 },	-- Bubble-Breaker Bracers
                { 5, 81076 },	-- Bottle of Potent Potables
                { 16, "c3414", [ATLASLOOT_IT_AMOUNT1] = 2 }, -- August Stone Shard
                { 17, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
            },
        },
        {	--BreweryYanZhu
            EncounterJournalID = 670,
            [NORMAL_DIFF] = {
                { 1, 80903 },	-- Fermenting Belt
                { 2, 80900 },	-- Fizzy Spaulders
                { 3, 80902 },	-- Uncasked Chestguard
                { 4, 80901 },	-- Sudsy Legplates
                { 5, 80894 },	-- Gao's Keg Tapper
                { 6, 80895 },	-- Yan-Zhu's Pressure Valve
                { 16, "ac6457" },
            },
            [HEROIC_DIFF] = {
                { 1, 87545 },	-- Inelava, Spirit of Inebriation
                { 2, 81059 },	-- Fermenting Belt
                { 3, 81068 },	-- Fizzy Spaulders
                { 4, 81081 },	-- Uncasked Chestguard
                { 5, 81078 },	-- Sudsy Legplates
                { 6, 81141 },	-- Alemental Seal
                { 7, 81139 },	-- Lime-Rimmed Signet
                { 8, 81138 },	-- Carbonic Carbuncle
                { 9, 81062 },	-- Gao's Keg Tapper
                { 10, 81140 },	-- Wort Sitrring Rod
                { 11, 81066 },	-- Yan-Zhu's Pressure Valve
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 18, "ac6456" },
            },
            [CELESTIAL_DIFF] = {
                { 1, 95870}, -- Abandoned Spaulders of Arrowflight
                { 2, 95871}, -- Abandoned Spaulders of Renewal
                { 3, 95976}, -- Abandoned Zandalari Bucklebreaker
                { 4, 95975}, -- Abandoned Zandalari Goreplate
                { 5, 95648}, -- Bindings of Multiplicative Strikes
                { 6, 95753}, -- Black Blood Legplates
                { 7, 95728}, -- Durumu's Baleful Gaze
                { 8, 95726}, -- Fabled Feather of Ji-Kun
                { 9, 95869}, -- Forgotten Mantle of the Sun
                { 10, 95672}, -- Gaze of Gara'jal
                { 11, 95701}, -- Grips of Cinderflesh
                { 12, 95755}, -- Hydra-Scale Bloodcloak
                { 13, 95780}, -- Iron Qon's Boot Knife
                { 14, 95647}, -- Jalak's Maelstrom Staff
                { 15, 95727}, -- Ji-Kun's Rising Winds
                { 16, 95821}, -- Legplates of the Lightning Throne
                { 17, 95808}, -- Legplates of Whipping Ionization
                { 18, 95673}, -- Loa-Ridden Bracers
                { 19, 95754}, -- Metabolically Boosted Shoulderplates
                { 20, 95977}, -- Necklace of the Terra-Cotta Vanquisher
                { 21, 95674}, -- Overloaded Bladebreaker Cuirass
                { 22, 95700}, -- Poisonblood Bladeshoulders
                { 23, 95699}, -- Quadra-Head Brooch
                { 24, 95782}, -- Quet'zal's Crackling Cord
                { 25, 95646}, -- Talisman of Living Poison
                { 26, 95809}, -- Uroe, Harbinger of Terror
                { 27, 95781}, -- Voice of the Quilen
                { 101, 87545 },	-- Inelava, Spirit of Inebriation
                { 102, 81059 },	-- Fermenting Belt
                { 103, 81068 },	-- Fizzy Spaulders
                { 104, 81081 },	-- Uncasked Chestguard
                { 105, 81078 },	-- Sudsy Legplates
                { 106, 81141 },	-- Alemental Seal
                { 107, 81139 },	-- Lime-Rimmed Signet
                { 108, 81138 },	-- Carbonic Carbuncle
                { 109, 81062 },	-- Gao's Keg Tapper
                { 110, 81140 },	-- Wort Sitrring Rod
                { 116, "INV_Box_01", nil, AL["Tier Token iLvl502"], nil, "Tier15CelestialTierTokens" },
                { 118, "c3414", [ATLASLOOT_IT_AMOUNT1] = "2/5" }, -- August Stone Shard
                { 119, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 121, "ac60893" },
            },
        },
        MOP_DUNGEON_HERO_AC_TABLE,
        MOP_CELESTIAL_HERO_AC_TABLE,
        MOP_GLORY_OF_THE_HERO_AC_TABLE,
    }
}

data["TempleOfTheJadeSerpent"] = {
    EncounterJournalID = 313,
    InstanceID = 960,
    MapID = 5956,
    ContentType = DUNGEON_CONTENT,
    LevelRange = {85, 85, 90},
    items = {
        {	--TJSMari
            EncounterJournalID = 672,
            [NORMAL_DIFF] = {
                { 1, 80862 },	-- Treads of Corrupted Water
                { 2, 80860 },	-- Waterburst Helm
                { 3, 80861 },	-- Riverbed Chestguard
            },
            [HEROIC_DIFF] = {
                { 1, 81123 },	-- Wind-Soaked Drape
                { 2, 81072 },	-- Treads of Corrupted Water
                { 3, 81075 },	-- Waterburst Helm
                { 4, 81083 },	-- Riverbed Chestguard
                { 5, 81124 },	-- Crystallized Droplet
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 18, "ac6460" },
            },
            [CELESTIAL_DIFF] = {
                { 1, 81123 },	-- Wind-Soaked Drape
                { 2, 81072 },	-- Treads of Corrupted Water
                { 3, 81075 },	-- Waterburst Helm
                { 4, 81083 },	-- Riverbed Chestguard
                { 5, 81124 },	-- Crystallized Droplet
                { 16, "c3414", [ATLASLOOT_IT_AMOUNT1] = 2 }, -- August Stone Shard
                { 17, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 19, "ac6460" },
            },
        },
        {	--TJSStonestep
            EncounterJournalID = 664,
            [NORMAL_DIFF] = {
                { 1, 80864 },	-- Girdle of Endemic Anger
                { 2, 80865 },	-- Sunheart Waistband
                { 3, 80863 },	-- Stonestep Boots
            },
            [HEROIC_DIFF] = {
                { 1, 81058 },	-- Girdle of Endemic Anger
                { 2, 81126 },	-- Leggings of Whispered Dreams
                { 3, 81060 },	-- Sunheart Waistband
                { 4, 81073 },	-- Stonestep Boots
                { 5, 81125 },	-- Windswept Pages
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
            },
            [CELESTIAL_DIFF] = {
                { 1, 81058 },	-- Girdle of Endemic Anger
                { 2, 81126 },	-- Leggings of Whispered Dreams
                { 3, 81060 },	-- Sunheart Waistband
                { 4, 81073 },	-- Stonestep Boots
                { 5, 81125 },	-- Windswept Pages
                { 16, "c3414", [ATLASLOOT_IT_AMOUNT1] = 2 }, -- August Stone Shard
                { 17, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
            },
        },
        {	--TJSFlameheart
            EncounterJournalID = 658,
            [NORMAL_DIFF] = {
                { 1, 80866 },	-- Cape of Entanglement
                { 2, 80867 },	-- Serpentstrike Shoulderpads
                { 3, 80872 },	-- Firebelcher Hand Cannon
            },
            [HEROIC_DIFF] = {
                { 1, 81084 },	-- Cape of Entanglement
                { 2, 81127 },	-- Flameheart Sandals
                { 3, 81070 },	-- Serpentstrike Shoulderpads
                { 4, 81128 },	-- Signet of Dancing Jade
                { 5, 81067 },	-- Firebelcher Hand Cannon
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
            },
            [CELESTIAL_DIFF] = {
                { 1, 81084 },	-- Cape of Entanglement
                { 2, 81127 },	-- Flameheart Sandals
                { 3, 81070 },	-- Serpentstrike Shoulderpads
                { 4, 81128 },	-- Signet of Dancing Jade
                { 5, 81067 },	-- Firebelcher Hand Cannon
                { 16, "c3414", [ATLASLOOT_IT_AMOUNT1] = 2 }, -- August Stone Shard
                { 17, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
            },
        },
        {	--TJSShaDoubt
            EncounterJournalID = 335,
            [NORMAL_DIFF] = {
                { 1, 80868 },	-- Doubtridden Shoulderguards
                { 2, 80870 },	-- Chestguard of Despair
                { 3, 80871 },	-- Neverdare Shoulders
                { 4, 80869 },	-- Hopecrusher Gauntlets
                { 5, 80873 },	-- Dubious Handaxe
                { 6, 80874 },	-- Staff of Trembling Will
                { 16, "ac6757" },
            },
            [HEROIC_DIFF] = {
                { 1, 87544 },	-- Je'lyu, Spirit of the Serpent
                { 2, 81129 },	-- Cloak of Failing Will
                { 3, 81132 },	-- Paralyzing Gloves
                { 4, 81071 },	-- Doubtridden Shoulderguards
                { 5, 81082 },	-- Chestguard of Despair
                { 6, 81069 },	-- Neverdare Shoulders
                { 7, 81074 },	-- Hopecrusher Gauntlets
                { 8, 81130 },	-- Binding of Broken Dreams
                { 9, 81131 },	-- Mindbreaker Pendant
                { 10, 81063 },	-- Dubious Handaxe
                { 11, 81079 },	-- Staff of Trembling Will
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 18, "ac6758" },
                { 19, "ac6926" },
                { 20, "ac6475" },
                { 21, "ac6671" },
            },
            [CELESTIAL_DIFF] = {
                { 1, 95731 }, -- Aberrant Chestguard of Torment
                { 2, 95758 }, -- Acid-Spine Bonemace
                { 3, 95756 }, -- Band of the Scaled Tyrant
                { 4, 95651 }, -- Bloodlord's Bloodsoaked Legplates
                { 5, 95979 }, -- Columnbreaker Stompers
                { 6, 95729 }, -- Crimson Bloom Legguards
                { 7, 95784 }, -- Dam'ren's Frozen Footguards
                { 8, 95677 }, -- Fortitude of the Zandalari
                { 9, 95650 }, -- Frozen Warlord's Bracers
                { 10, 95812 }, -- Legwraps of Cardinality
                { 11, 95730 }, -- Links of the Disintegrator
                { 12, 95978 }, -- Locksmasher Greaves
                { 13, 95980 }, -- Necklace of the Terra-Cotta Protector
                { 14, 95702 }, -- Plated Toothbreaker Girdle
                { 15, 95757 }, -- Primordius' Talisman of Rage
                { 16, 95872 }, -- Reconstructed Holy Shoulderplates
                { 17, 95873 }, -- Reconstructed Furious Shoulderplates
                { 18, 95874 }, -- Reconstructed Bloody Shoulderplates
                { 19, 95785 }, -- Ro'shak's Remembrance
                { 20, 95703 }, -- Rot-Proof Greatplate
                { 21, 95783 }, -- Saddle-Scarred Leggings
                { 22, 95811 }, -- Soul Barrier
                { 23, 95704 }, -- Spinescale Seal
                { 24, 95649 }, -- Sul'lithuz Sandmail
                { 25, 95676 }, -- Talisman of Angry Spirits
                { 26, 95810 }, -- Ultimate Protection of the Emperor
                { 27, 95675 }, -- Zerat, Malakk's Soulburning Greatsword
                { 101, 87544 },	-- Je'lyu, Spirit of the Serpent
                { 102, 81129 },	-- Cloak of Failing Will
                { 103, 81132 },	-- Paralyzing Gloves
                { 104, 81071 },	-- Doubtridden Shoulderguards
                { 105, 81082 },	-- Chestguard of Despair
                { 106, 81069 },	-- Neverdare Shoulders
                { 107, 81074 },	-- Hopecrusher Gauntlets
                { 108, 81130 },	-- Binding of Broken Dreams
                { 109, 81131 },	-- Mindbreaker Pendant
                { 110, 81063 },	-- Dubious Handaxe
                { 111, 81079 },	-- Staff of Trembling Will
                { 116, "INV_Box_01", nil, AL["Tier Token iLvl502"], nil, "Tier15CelestialTierTokens" },
                { 118, "c3414", [ATLASLOOT_IT_AMOUNT1] = "2/5" }, -- August Stone Shard
                { 119, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 121, "ac60892" },
                { 122, "ac6926" },
                { 123, "ac6475" },
                { 124, "ac6671" },
            },
        },
        MOP_DUNGEON_HERO_AC_TABLE,
        MOP_CELESTIAL_HERO_AC_TABLE,
        MOP_GLORY_OF_THE_HERO_AC_TABLE,
    }
}

data["ShadoPanMonastery"] = {
    EncounterJournalID = 312,
    InstanceID = 959,
    MapID = 5918,
    ContentType = DUNGEON_CONTENT,
    LevelRange = {87, 87, 90},
    items = {
        {	--ShadoPanCloudstrike
            EncounterJournalID = 673,
            [NORMAL_DIFF] = {
                { 1, 80909 },	-- Azure Serpent Chestguard
                { 2, 80910 },	-- Leggings of the Charging Soul
                { 3, 80908 },	-- Sparkbreath Girdle
            },
            [HEROIC_DIFF] = {
                { 1, 81179 },	-- Star Summoner Bracers
                { 2, 81110 },	-- Azure Serpent Chestguard
                { 3, 81092 },	-- Leggings of the Charging Soul
                { 4, 81086 },	-- Sparkbreath Girdle
                { 5, 81180 },	-- Cloudstrike Pendant
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
            },
            [CELESTIAL_DIFF] = {
                { 1, 81179 },	-- Star Summoner Bracers
                { 2, 81110 },	-- Azure Serpent Chestguard
                { 3, 81092 },	-- Leggings of the Charging Soul
                { 4, 81086 },	-- Sparkbreath Girdle
                { 5, 81180 },	-- Cloudstrike Pendant
                { 16, "c3414", [ATLASLOOT_IT_AMOUNT1] = 2 }, -- August Stone Shard
                { 17, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
            },
        },
        {	--ShadoPanSnowdrift
            EncounterJournalID = 657,
            [NORMAL_DIFF] = {
                { 1, 80912, 33 },	-- Gauntlets of Resolute Fury
                { 2, 80911, 33 },	-- Quivering Heart Girdle
                { 3, 80937, 33 },	-- Snowdrift's Bladed Staff
            },
            [HEROIC_DIFF] = {
                { 1, 81101, 20 },	-- Gauntlets of Resolute Fury
                { 2, 81087, 20 },	-- Quivering Heart Girdle
                { 3, 81182, 20 },	-- Eye of the Tornado
                { 4, 81181, 20 },	-- Heart of Fire
                { 5, 81108, 20 },	-- Snowdrift's Bladed Staff
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 18, "ac6477" },
            },
            [CELESTIAL_DIFF] = {
                { 1, 81101, 20 },	-- Gauntlets of Resolute Fury
                { 2, 81087, 20 },	-- Quivering Heart Girdle
                { 3, 81182, 20 },	-- Eye of the Tornado
                { 4, 81181, 20 },	-- Heart of Fire
                { 5, 81108, 20 },	-- Snowdrift's Bladed Staff
                { 16, "c3414", [ATLASLOOT_IT_AMOUNT1] = 2 }, -- August Stone Shard
                { 17, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 19, "ac6477" },
            },
        },
        {	--ShadoPanShaViolence
            EncounterJournalID = 685,
            [NORMAL_DIFF] = {
                { 1, 80913 },	-- Gloves of Enraged Slaughter
                { 2, 80915 },	-- Spike-Soled Stompers
                { 3, 80883 },	-- Crescent of Ichor
            },
            [HEROIC_DIFF] = {
                { 1, 81102 },	-- Gloves of Enraged Slaughter
                { 2, 81185 },	-- Bladed Smoke Bracers
                { 3, 81113 },	-- Spike-Soled Stompers
                { 4, 81184 },	-- Necklace of Disorientation
                { 5, 81089 },	-- Crescent of Ichor
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 18, "ac6926" },
                { 19, "ac6472" },
            },
            [CELESTIAL_DIFF] = {
                { 1, 81102 },	-- Gloves of Enraged Slaughter
                { 2, 81185 },	-- Bladed Smoke Bracers
                { 3, 81113 },	-- Spike-Soled Stompers
                { 4, 81184 },	-- Necklace of Disorientation
                { 5, 81089 },	-- Crescent of Ichor
                { 16, "c3414", [ATLASLOOT_IT_AMOUNT1] = 2 }, -- August Stone Shard
                { 17, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 19, "ac6926" },
                { 20, "ac6472" },
            },
        },
        {	--ShadoPanTaranZhu
            EncounterJournalID = 686,
            [NORMAL_DIFF] = {
                { 1, 80919 },	-- Darkbinder Leggings
                { 2, 80916 },	-- Shadowspine Shoulderguards
                { 3, 80917 },	-- Blastwalker Footguards
                { 4, 80918 },	-- Mindbinder Plate Gloves
                { 5, 80936 },	-- Warmace of Taran Zhu
                { 6, 80935 },	-- Shield of Blind Hate
                { 16, "ac6469" },
            },
            [HEROIC_DIFF] = {
                { 1, 87543 },	-- Ka'eng, Breath of the Shadow
                { 2, 81188 },	-- Robes of Fevered Dreams
                { 3, 81093 },	-- Darkbinder Leggings
                { 4, 81099 },	-- Shadowspine Shoulderguards
                { 5, 81114 },	-- Blastwalker Footguards
                { 6, 81187 },	-- Hateshatter Chestplate
                { 7, 81103 },	-- Mindbinder Plate Gloves
                { 8, 81189 },	-- Ring of Malice
                { 9, 81186 },	-- Seal of Hateful Meditation
                { 10, 81107 },	-- Warmace of Taran Zhu
                { 11, 81096 },	-- Shield of Blind Hate
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 18, "ac6470" },
                { 19, "ac6471" },
            },
            [CELESTIAL_DIFF] = {
                { 1, 95971 },  -- Abandoned Zandalari Moonstrap
                { 2, 95970 },  -- Abandoned Zandalari Silentbelt
                { 3, 95776 },  -- Anima-Ringed Fingers
                { 4, 95774 },  -- Athame of the Sanguine Ritual
                { 5, 95639 },  -- Drape of Booming Nights
                { 6, 95721 },  -- Featherflight Belt
                { 7, 95720 },  -- Giorgio's Caduceus of Pure Moods
                { 8, 95749 },  -- Gloves of Cushioned Air
                { 9, 95722 },  -- Grasp of the Ruthless Mother
                { 10, 95642 },  -- Infinitely Conducting Bracers
                { 11, 95666 },  -- Kura-Kura, Kazra'jin's Skullcleaver
                { 12, 95747 },  -- Legplates of Re-Emergence
                { 13, 95863 },  -- Lost Shoulders of Fire
                { 14, 95865 },  -- Lost Shoulders of Fluidity
                { 15, 95864 },  -- Lost Shoulders of Healing
                { 16, 95667 },  -- Mar'li's Bloodstained Sandals
                { 17, 95800 },  -- Moonjade Necklace
                { 18, 95969 },  -- Necklace of the Terra-Cotta Mender
                { 19, 95694 },  -- Robes of Concussive Shocks
                { 20, 95802 },  -- Rune of Re-Origination
                { 21, 95803 },  -- Shan-Dun, Breaker of Hope
                { 22, 95640 },  -- Soulblade of the Breaking Storm
                { 23, 95695 },  -- Spaulders of Quaking Fear
                { 24, 95748 },  -- Talisman of Bloodlust
                { 25, 95693 },  -- Vampire Bat-Hide Bracers
                { 26, 95775 },  -- Worldbinder Leggings
                { 27, 95668 },  -- Zandalari Robes of the Final Rite
                { 101, 87543 },	-- Ka'eng, Breath of the Shadow
                { 102, 81188 },	-- Robes of Fevered Dreams
                { 103, 81093 },	-- Darkbinder Leggings
                { 104, 81099 },	-- Shadowspine Shoulderguards
                { 105, 81114 },	-- Blastwalker Footguards
                { 106, 81187 },	-- Hateshatter Chestplate
                { 107, 81103 },	-- Mindbinder Plate Gloves
                { 108, 81189 },	-- Ring of Malice
                { 109, 81186 },	-- Seal of Hateful Meditation
                { 110, 81107 },	-- Warmace of Taran Zhu
                { 111, 81096 },	-- Shield of Blind Hate
                { 116, "INV_Box_01", nil, AL["Tier Token iLvl502"], nil, "Tier15CelestialTierTokens" },
                { 118, "c3414", [ATLASLOOT_IT_AMOUNT1] = "2/5" }, -- August Stone Shard
                { 119, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 121, "ac60895" },
                { 122, "ac6471" },
            },
        },
        MOP_DUNGEON_HERO_AC_TABLE,
        MOP_CELESTIAL_HERO_AC_TABLE,
        MOP_GLORY_OF_THE_HERO_AC_TABLE,
    }
}

data["MoguShanPalace"] = {
    EncounterJournalID = 321,
    InstanceID = 994,
    MapID = 6182,
    ContentType = DUNGEON_CONTENT,
    LevelRange = {87, 87, 90},
    items = {
        {	--MoguShanTrialKing
            EncounterJournalID = 708,
            [NORMAL_DIFF] = {
                { 1, 85178 },	-- Conflagrating Gloves
                { 2, 85176 },	-- Hurricane Belt
                { 3, 85175 },	-- Crest of the Clan Lords
                { 4, 85179 },	-- Meteoric Greathelm
                { 5, 85177 },	-- Whirling Dervish Choker
            },
            [HEROIC_DIFF] = {
                { 1, 81240 },	-- Conflagrating Gloves
                { 2, 81238 },	-- Hurricane Belt
                { 3, 81237 },	-- Crest of the Clan Lords
                { 4, 81241 },	-- Meteoric Greathelm
                { 5, 81239 },	-- Whirling Dervish Choker
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
            },
            [CELESTIAL_DIFF] = {
                { 1, 81240 },	-- Conflagrating Gloves
                { 2, 81238 },	-- Hurricane Belt
                { 3, 81237 },	-- Crest of the Clan Lords
                { 4, 81241 },	-- Meteoric Greathelm
                { 5, 81239 },	-- Whirling Dervish Choker
                { 16, "c3414", [ATLASLOOT_IT_AMOUNT1] = 2 }, -- August Stone Shard
                { 17, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
            },
        },
        {	--MoguShanGekkan
            EncounterJournalID = 690,
            [NORMAL_DIFF] = {
                { 1, 85182 },	-- Cloak of Cleansing Flame
                { 2, 85184 },	-- Hexxer's Lethargic Gloves
                { 3, 85180 },	-- Glintrok Sollerets
                { 4, 85181 },	-- Iron Protector Talisman
                { 5, 85183 },	-- Claws of Gekkan
            },
            [HEROIC_DIFF] = {
                { 1, 81244 },	-- Cloak of Cleansing Flame
                { 2, 81246 },	-- Hexxer's Lethargic Gloves
                { 3, 81242 },	-- Glintrok Sollerets
                { 4, 81243 },	-- Iron Protector Talisman
                { 5, 81245 },	-- Claws of Gekkan
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 18, "ac6478" },
            },
            [CELESTIAL_DIFF] = {
                { 1, 81244 },	-- Cloak of Cleansing Flame
                { 2, 81246 },	-- Hexxer's Lethargic Gloves
                { 3, 81242 },	-- Glintrok Sollerets
                { 4, 81243 },	-- Iron Protector Talisman
                { 5, 81245 },	-- Claws of Gekkan
                { 16, "c3414", [ATLASLOOT_IT_AMOUNT1] = 2 }, -- August Stone Shard
                { 17, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 19, "ac6478" },
            },
        },
        {	--MoguShanXin
            EncounterJournalID = 698,
            [NORMAL_DIFF] = {
                { 1, 85194 },	-- Regal Silk Shoulderpads
                { 2, 85192 },	-- Soulbinder Treads
                { 3, 85187 },	-- Boots of Plummeting Death
                { 4, 85189 },	-- Groundshaker Bracers
                { 5, 85193 },	-- Mind's Eye Breastplate
                { 6, 85186 },	-- Axebreaker Gauntlets
                { 7, 85191 },	-- Mindcapture Pendant
                { 8, 85188 },	-- Blade Trap Signet
                { 9, 85190 },	-- Firescribe Dagger
                { 10, 85185 },	-- Ghostheart
                { 16, "ac6755" },
            },
            [HEROIC_DIFF] = {
                { 1, 87542 },	-- Mogu'Dar, Blade of the Thousand Slaves
                { 2, 81257 },	-- Regal Silk Shoulderpads
                { 3, 81255 },	-- Soulbinder Treads
                { 4, 81249 },	-- Boots of Plummeting Death
                { 5, 81252 },	-- Groundshaker Bracers
                { 6, 81256 },	-- Mind's Eye Breastplate
                { 7, 81248 },	-- Axebreaker Gauntlets
                { 8, 81254 },	-- Mindcapture Pendant
                { 9, 81251 },	-- Blade Trap Signet
                { 10, 81253 },	-- Firescribe Dagger
                { 11, 81247 },	-- Ghostheart
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 18, "ac6756" },
                { 19, "ac6736" },
            },
            [CELESTIAL_DIFF] = {
                { 1, 95735 }, -- Artery Rippers
                { 2, 95681 }, -- Beady-Eye Bracers
                { 3, 95762 }, -- Bracers of Fragile Bone
                { 4, 95629 }, -- Cloudbreaker Greatbelt
                { 5, 95657 }, -- Dinomancer's Spiritbinding Spire
                { 6, 95737 }, -- Durumu's Severed Tentacle
                { 7, 95710 }, -- Fetish of the Hydra
                { 8, 95655 }, -- Flamecaster's Burning Crown
                { 9, 95708 }, -- Frostborn Wristwraps
                { 10, 95764 }, -- Leggings of the Malformed Sapling
                { 11, 95818 }, -- Lei Shen's Orb of Command
                { 12, 95817 }, -- Lightning-Imbued Chalice
                { 13, 95709 }, -- Megaera's Shining Eye
                { 14, 95958 }, -- Necklace of the Terra-Cotta Archer
                { 15, 95790 }, -- Qon's Flaming Scimitar
                { 16, 95682 }, -- Quakestompers
                { 17, 95789 }, -- Rein-Binder's Fists
                { 18, 95736 }, -- Reinforced Mirror-Sheen Cloak
                { 19, 95683 }, -- Shoulderguards of Centripetal Destruction
                { 20, 95816 }, -- Soul Prism of Lei Shen
                { 21, 95627 }, -- Spearman's Jingling Leggings
                { 22, 95959 }, -- Spiderweb Tabi
                { 23, 95628 }, -- Static-Shot Shoulderguards
                { 24, 95763 }, -- Stolen Relic of Zuldazar
                { 25, 95656 }, -- Vaccinator's Armwraps
                { 26, 95878 }, -- Visage of the Doomed
                { 27, 95791 }, -- Wu-Lai, Bladed Fan of the Empyreans
                { 101, 87542 },	-- Mogu'Dar, Blade of the Thousand Slaves
                { 102, 81257 },	-- Regal Silk Shoulderpads
                { 103, 81255 },	-- Soulbinder Treads
                { 104, 81249 },	-- Boots of Plummeting Death
                { 105, 81252 },	-- Groundshaker Bracers
                { 106, 81256 },	-- Mind's Eye Breastplate
                { 107, 81248 },	-- Axebreaker Gauntlets
                { 108, 81254 },	-- Mindcapture Pendant
                { 109, 81251 },	-- Blade Trap Signet
                { 110, 81253 },	-- Firescribe Dagger
                { 111, 81247 },	-- Ghostheart
                { 116, "INV_Box_01", nil, AL["Tier Token iLvl502"], nil, "Tier15CelestialTierTokens" },
                { 118, "c3414", [ATLASLOOT_IT_AMOUNT1] = "2/5" }, -- August Stone Shard
                { 119, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 121, "ac60894" },
                { 122, "ac6736" },
            },
        },
        MOP_DUNGEON_HERO_AC_TABLE,
        MOP_CELESTIAL_HERO_AC_TABLE,
        MOP_GLORY_OF_THE_HERO_AC_TABLE,
    }
}

data["GateoftheSettingSun"] = {
    EncounterJournalID = 303,
    InstanceID = 962,
    MapID = 5976,
    ContentType = DUNGEON_CONTENT,
    LevelRange = {88, 88, 90},
    items = {
        {	--GotSSKiptilak
            EncounterJournalID = 655,
            [NORMAL_DIFF] = {
                { 1, 80920 },	-- Fallout Filter
                { 2, 80921 },	-- Saboteur's Stabilizing Bracers
                { 3, 80934 },	-- Pendant of Precise Timing
            },
            [HEROIC_DIFF] = {
                { 1, 81104 },	-- Fallout-Filtering Hood
                { 2, 81090 },	-- Saboteur's Stabilizing Bracers
                { 3, 81190 },	-- Grenadier's Belt
                { 4, 81095 },	-- Pendant of Precise Timing
                { 5, 81191 },	-- Pulled Grenade Pin
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 18, "ac6479" }
            },
            [CELESTIAL_DIFF] = {
                { 1, 81104 },	-- Fallout-Filtering Hood
                { 2, 81090 },	-- Saboteur's Stabilizing Bracers
                { 3, 81190 },	-- Grenadier's Belt
                { 4, 81095 },	-- Pendant of Precise Timing
                { 5, 81191 },	-- Pulled Grenade Pin
                { 16, "c3414", [ATLASLOOT_IT_AMOUNT1] = 2 }, -- August Stone Shard
                { 17, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 19, "ac6479" }
            },
        },
        {	--GotSSGadok
            EncounterJournalID = 675,
            [NORMAL_DIFF] = {
                { 1, 80922 },	-- Airstream Treads
                { 2, 80923 },	-- Impaler's Girdle
                { 3, 80924 },	-- Acid-Scarred Spaulders
            },
            [HEROIC_DIFF] = {
                { 1, 81229 },	-- Bomber's Precision Gloves
                { 2, 81111 },	-- Airstream Treads
                { 3, 81085 },	-- Impaler's Girdle
                { 4, 81098 },	-- Acid-Scarred Spaulders
                { 5, 81192 },	-- Vision of the Predator
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
            },
            [CELESTIAL_DIFF] = {
                { 1, 81229 },	-- Bomber's Precision Gloves
                { 2, 81111 },	-- Airstream Treads
                { 3, 81085 },	-- Impaler's Girdle
                { 4, 81098 },	-- Acid-Scarred Spaulders
                { 5, 81192 },	-- Vision of the Predator
                { 16, "c3414", [ATLASLOOT_IT_AMOUNT1] = 2 }, -- August Stone Shard
                { 17, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
            },
        },
        {	--GotSSRimok
            EncounterJournalID = 676,
            [NORMAL_DIFF] = {
                { 1, 80926 },	-- Leggings of the Frenzy
                { 2, 80925 },	-- Swarmcall Helm
                { 3, 80933 },	-- Mantid Trochanter
            },
            [HEROIC_DIFF] = {
                { 1, 81106 },	-- Leggings of the Frenzy
                { 2, 81105 },	-- Swarmcall Helm
                { 3, 81230 },	-- Ri'mok's Shattered Scale
                { 4, 81232 },	-- Viscous Ring
                { 5, 81088 },	-- Mantid Trochanter
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
            },
            [CELESTIAL_DIFF] = {
                { 1, 81106 },	-- Leggings of the Frenzy
                { 2, 81105 },	-- Swarmcall Helm
                { 3, 81230 },	-- Ri'mok's Shattered Scale
                { 4, 81232 },	-- Viscous Ring
                { 5, 81088 },	-- Mantid Trochanter
                { 16, "c3414", [ATLASLOOT_IT_AMOUNT1] = 2 }, -- August Stone Shard
                { 17, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
            },
        },
        {	--GotSSRaigonn
            EncounterJournalID = 649,
            [NORMAL_DIFF] = {
                { 1, 80929 },	-- Wall-Breaker Legguards
                { 2, 80928 },	-- Treads of Fixation
                { 3, 80930 },	-- Swarmbringer Chestguard
                { 4, 80927 },	-- Hive Protector's Gauntlets
                { 5, 80932 },	-- Carapace Breaker
                { 6, 80931 },	-- Shield of the Protectorate
            },
            [HEROIC_DIFF] = {
                { 1, 87546 },	-- Klatith, Fangs of the Swarm
                { 2, 81234 },	-- Drape of the Screeching Swarm
                { 3, 81235 },	-- Shoulders of Engulfing Winds
                { 4, 81236 },	-- Frenzyswarm Bracers
                { 5, 81091 },	-- Wall-Breaker Legguards
                { 6, 81112 },	-- Treads of Fixation
                { 7, 81109 },	-- Swarmbringer Chestguard
                { 8, 81100 },	-- Hive Protector's Gauntlets
                { 9, 81094 },	-- Carapace Breaker
                { 10, 81233 },	-- Impervious Carapace
                { 11, 81097 },	-- Shield of the Protectorate
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 18, "ac6759" },
                { 19, "ac6945" },
            },
            [CELESTIAL_DIFF] = {
                { 1, 95877 }, -- Bo-Ris, Horror in the Night
                { 2, 95732 }, -- Caustic Spike Bracers
                { 3, 95876 }, -- Do-tharak, the Swordbreaker
                { 4, 95707 }, -- Gleaming-Eye Shoulderpads
                { 5, 95813 }, -- Gloves of the Maimed Vizier
                { 6, 95875 }, -- Greatsword of Frozen Hells
                { 7, 95680 }, -- Grips of Vampiric Cruelty
                { 8, 95760 }, -- Helix-Breaker Gloves
                { 9, 95653 }, -- Horn-Rimmed Doomcloak
                { 10, 95705 }, -- Hydraskull Choker
                { 11, 95761 }, -- Leggings of Ebon Veins
                { 12, 95733 }, -- Legplates of the Dark Parasite
                { 13, 95626 }, -- Lightning-Eye Hood
                { 14, 95786 }, -- Orb of Arcing Lightning
                { 15, 95652 }, -- Puncture-Proof Greathelm
                { 16, 95625 }, -- Renataki's Soul Charm
                { 17, 95788 }, -- Ro'shak's Molten Chain
                { 18, 95759 }, -- Robes of Mutagenic Blood
                { 19, 95679 }, -- Rockfall Ribwraps
                { 20, 95706 }, -- Sandals of Arcane Fury
                { 21, 95678 }, -- Shattered Tortoiseshell Longbow
                { 22, 95624 }, -- Sign of the Bloodied God
                { 23, 95654 }, -- Spark of Zandalar
                { 24, 95787 }, -- Spurs of the Storm Cavalry
                { 25, 95815 }, -- Torall, Rod of the Shattered Throne
                { 26, 95734 }, -- Treads of the Blind Eye
                { 27, 95814 }, -- Unerring Vision of Lei Shen
                { 101, 87546 },	-- Klatith, Fangs of the Swarm
                { 102, 81234 },	-- Drape of the Screeching Swarm
                { 103, 81235 },	-- Shoulders of Engulfing Winds
                { 104, 81236 },	-- Frenzyswarm Bracers
                { 105, 81091 },	-- Wall-Breaker Legguards
                { 106, 81112 },	-- Treads of Fixation
                { 107, 81109 },	-- Swarmbringer Chestguard
                { 108, 81100 },	-- Hive Protector's Gauntlets
                { 109, 81094 },	-- Carapace Breaker
                { 110, 81233 },	-- Impervious Carapace
                { 111, 81097 },	-- Shield of the Protectorate
                { 116, "INV_Box_01", nil, AL["Tier Token iLvl502"], nil, "Tier15CelestialTierTokens" },
                { 118, "c3414", [ATLASLOOT_IT_AMOUNT1] = "2/5" }, -- August Stone Shard
                { 119, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 121, "ac60896" },
                { 122, "ac6945" },
            },
        },
        MOP_DUNGEON_HERO_AC_TABLE,
        MOP_CELESTIAL_HERO_AC_TABLE,
        MOP_GLORY_OF_THE_HERO_AC_TABLE,
    }
}

data["SiegeofNiuzaoTemple"] = {
    EncounterJournalID = 324,
    InstanceID = 1011,
    MapID = 6214,
    ContentType = DUNGEON_CONTENT,
    LevelRange = {88, 88, 90},
    items = {
        {	--NTJinbak
            EncounterJournalID = 693,
            [NORMAL_DIFF] = {
                { 1, 100952 },	-- Hood of Viridian Residue
                { 2, 100953 },	-- Girdle of Soothing Detonation
                { 3, 100954 },	-- Sap-Encrusted Legplates
                { 4, 100950 },	-- Engraved Amber Pendant
                { 5, 100951 },	-- Flashfrozen Resin Globule
            },
            [HEROIC_DIFF] = {
                { 1, 81262 },	-- Hood of Viridian Residue
                { 2, 81272 },	-- Girdle of Soothing Detonation
                { 3, 81270 },	-- Sap-Encrusted Legplates
                { 4, 81271 },	-- Engraved Amber Pendant
                { 5, 81263 },	-- Flashfrozen Resin Globule
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
            },
            [CELESTIAL_DIFF] = {
                { 1, 81262 },	-- Hood of Viridian Residue
                { 2, 81272 },	-- Girdle of Soothing Detonation
                { 3, 81270 },	-- Sap-Encrusted Legplates
                { 4, 81271 },	-- Engraved Amber Pendant
                { 5, 81263 },	-- Flashfrozen Resin Globule
                { 16, "c3414", [ATLASLOOT_IT_AMOUNT1] = 2 }, -- August Stone Shard
                { 17, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
            },
        },
        {	--NTVojak
            EncounterJournalID = 738,
            [NORMAL_DIFF] = {
                { 1, 100956 },	-- Bombardment Bracers
                { 2, 100957 },	-- Chestwrap of Arcing Flame
                { 3, 100958 },	-- Archer's Precision Grips
                { 4, 100959 },	-- Sightfinder Helm
                { 5, 100955 },	-- Siege-Captain's Scimitar
            },
            [HEROIC_DIFF] = {
                { 1, 81276 },	-- Bombardment Bracers
                { 2, 81275 },	-- Chestwrap of Arcing Flame
                { 3, 81277 },	-- Archer's Precision Grips
                { 4, 81274 },	-- Sightfinder Helm
                { 5, 81273 },	-- Siege-Captain's Scimitar
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 18, "ac6688" },
            },
            [CELESTIAL_DIFF] = {
                { 1, 81276 },	-- Bombardment Bracers
                { 2, 81275 },	-- Chestwrap of Arcing Flame
                { 3, 81277 },	-- Archer's Precision Grips
                { 4, 81274 },	-- Sightfinder Helm
                { 5, 81273 },	-- Siege-Captain's Scimitar
                { 16, "c3414", [ATLASLOOT_IT_AMOUNT1] = 2 }, -- August Stone Shard
                { 17, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 19, "ac6688" },
            },
        },
        {	--NTPavalak
            EncounterJournalID = 692,
            [NORMAL_DIFF] = {
                { 1, 100961 },	-- Aerial Bombardment Cloak
                { 2, 100962 },	-- Breezebinder Handwraps
                { 3, 100964 },	-- Siegeworn Bracers
                { 4, 100963 },	-- Vial of Ichorous Blood
                { 5, 100960 },	-- Tempestuous Longbow
            },
            [HEROIC_DIFF] = {
                { 1, 81282 },	-- Aerial Bombardment Cloak
                { 2, 81281 },	-- Breezebinder Handwraps
                { 3, 81280 },	-- Siegeworn Bracers
                { 4, 81264 },	-- Vial of Ichorous Blood
                { 5, 81279 },	-- Tempestuous Longbow
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 18, "ac6485" },
            },
            [CELESTIAL_DIFF] = {
                { 1, 81282 },	-- Aerial Bombardment Cloak
                { 2, 81281 },	-- Breezebinder Handwraps
                { 3, 81280 },	-- Siegeworn Bracers
                { 4, 81264 },	-- Vial of Ichorous Blood
                { 5, 81279 },	-- Tempestuous Longbow
                { 16, "c3414", [ATLASLOOT_IT_AMOUNT1] = 2 }, -- August Stone Shard
                { 17, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 19, "ac6485" },
            },
        },
        {	--NTNeronok
            EncounterJournalID = 727,
            [NORMAL_DIFF] = {
                { 1, 100971 },	-- Breezeswept Hood
                { 2, 100972 },	-- Whisperwind Spaulders
                { 3, 100967 },	-- Windblast Helm
                { 4, 100968 },	-- Galedodger Chestguard
                { 5, 100974 },	-- Belt of Totemic Binding
                { 6, 100975 },	-- Airbender Sandals
                { 7, 100970 },	-- Spaulders of Immovable Stone
                { 8, 100969 },	-- Anchoring Sabatons
                { 9, 100965 },	-- Ner'onok's Razor Katar
                { 10, 100973 },	-- Gustwalker Staff
            },
            [HEROIC_DIFF] = {
                { 1, 87547 },
                { 2, 81289 },	-- Breezeswept Hood
                { 3, 81291 },	-- Whisperwind Spaulders
                { 4, 81283 },	-- Windblast Helm
                { 5, 81285 },	-- Galedodger Chestguard
                { 6, 81290 },	-- Belt of Totemic Binding
                { 7, 81292 },	-- Airbender Sandals
                { 8, 81287 },	-- Spaulders of Immovable Stone
                { 9, 81284 },	-- Anchoring Sabatons
                { 10, 81286 },	-- Ner'onok's Razor Katar
                { 11, 81288 },	-- Gustwalker Staff
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 18, "ac6763" },
                { 19, "ac6822" },
            },
            [CELESTIAL_DIFF] = {
                { 1, 95972 }, -- Abandoned Zandalari Arrowlinks
                { 2, 95974 }, -- Abandoned Zandalari Greatbelt
                { 3, 95973 }, -- Abandoned Zandalari Waterchain
                { 4, 95670 }, -- Amun-Thoth, Sul's Spiritrending Talons
                { 5, 95750 }, -- Bracers of Mutagenic Fervor
                { 6, 95805 }, -- Conduit-Breaker Chain Leggings
                { 7, 95723 }, -- Crown of Potentiated Birth
                { 8, 95778 }, -- Crown of the Golden Golem
                { 9, 95779 }, -- Delicate Vial of the Sanguinaire
                { 10, 95806 }, -- Doomed Crown of Lei Shen
                { 11, 95725 }, -- Egg-Shard Grips
                { 12, 95868 }, -- Forgotten Mantle of the Moon
                { 13, 95804 }, -- Fusion Slasher Chestguard
                { 14, 95643 }, -- Ghostbinder Greatboots
                { 15, 95644 }, -- Ionized Yojamban Carapace
                { 16, 95867 }, -- Jerthud, Graceful Hand of the Savior
                { 17, 95777 }, -- Matter-Swapped Legplates
                { 18, 95698 }, -- Megaera's Poisoned Fang
                { 19, 95866 }, -- Nadagast's Exsanguinator
                { 20, 95752 }, -- Pathogenic Gauntlets
                { 21, 95696 }, -- Refreshing Abalone Girdle
                { 22, 95671 }, -- Robes of Treacherous Ground
                { 23, 95751 }, -- Synapse-String Handguards
                { 24, 95724 }, -- Talonrender Chestplate
                { 25, 95697 }, -- Tortos' Shellseizers
                { 26, 95645 }, -- Wastewalker's Sandblasted Drape
                { 27, 95669 }, -- Wushoolay's Final Choice
                { 101, 87547 }, -- Tolakesh, Horn of the Black Ox
                { 102, 81289 },	-- Breezeswept Hood
                { 103, 81291 },	-- Whisperwind Spaulders
                { 104, 81283 },	-- Windblast Helm
                { 105, 81285 },	-- Galedodger Chestguard
                { 106, 81290 },	-- Belt of Totemic Binding
                { 107, 81292 },	-- Airbender Sandals
                { 108, 81287 },	-- Spaulders of Immovable Stone
                { 109, 81284 },	-- Anchoring Sabatons
                { 110, 81286 },	-- Ner'onok's Razor Katar
                { 111, 81288 },	-- Gustwalker Staff
                { 116, "INV_Box_01", nil, AL["Tier Token iLvl502"], nil, "Tier15CelestialTierTokens" },
                { 118, "c3414", [ATLASLOOT_IT_AMOUNT1] = "2/5" }, -- August Stone Shard
                { 119, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 121, "ac60900" },
                { 122, "ac6822" },
            },
        },
        MOP_DUNGEON_HERO_AC_TABLE,
        MOP_CELESTIAL_HERO_AC_TABLE,
        MOP_GLORY_OF_THE_HERO_AC_TABLE,
    }
}

data["ScarletHallsMoP"] = {
    EncounterJournalID = 311,
    InstanceID = 1001,
    MapID = 6052,
    ContentType = DUNGEON_CONTENT,
    LoadDifficulty = HEROIC_DIFF,
    LevelRange = {90, 90, 90},
    items = {
        {	--SHBraun
            EncounterJournalID = 660,
            -- [NORMAL_DIFF] = "AtlasLootClassic",
            [HEROIC_DIFF] = {
                { 1, 81695 },	-- Hound Trainer's Gloves
                { 2, 81696 },	-- Canine Commander's Breastplate
                { 3, 81694 },	-- Commanding Bracers
                { 4, 81563 },	-- Beastbinder Ring
                { 5, 81693 },	-- Houndmaster's Compound Crossbow
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 18, "ac6684" },
            },
            [CELESTIAL_DIFF] = {
                { 1, 81695 },	-- Hound Trainer's Gloves
                { 2, 81696 },	-- Canine Commander's Breastplate
                { 3, 81694 },	-- Commanding Bracers
                { 4, 81563 },	-- Beastbinder Ring
                { 5, 81693 },	-- Houndmaster's Compound Crossbow
                { 16, "c3414", [ATLASLOOT_IT_AMOUNT1] = 2 }, -- August Stone Shard
                { 17, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 19, "ac6684" },
            },
        },
        {	--SHHarlan
            EncounterJournalID = 654,
            -- [NORMAL_DIFF] = "AtlasLootClassic",
            [HEROIC_DIFF] = {
                { 1, 81699 },	-- Scarlet Sandals
                { 2, 81700 },	-- Lightblade Bracer
                { 3, 81698 },	-- Harlan's Shoulders
                { 4, 81568 },	-- Armsmaster's Sealed Locket
                { 5, 81697 },	-- The Gleaming Ravager
                { 7, 23192, [ATLASLOOT_IT_FILTERIGNORE] = true },	-- Tabard of the Scarlet Crusade
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 18, "ac6427" },
            },
            [CELESTIAL_DIFF] = {
                { 1, 81695 },	-- Hound Trainer's Gloves
                { 2, 81696 },	-- Canine Commander's Breastplate
                { 3, 81694 },	-- Commanding Bracers
                { 4, 81563 },	-- Beastbinder Ring
                { 5, 81693 },	-- Houndmaster's Compound Crossbow
                { 16, "c3414", [ATLASLOOT_IT_AMOUNT1] = 2 }, -- August Stone Shard
                { 17, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 19, "ac6684" },
            },
        },
        {	--SHKoegler
            EncounterJournalID = 656,
            -- [NORMAL_DIFF] = "AtlasLootClassic",
            [HEROIC_DIFF] = {
                { 1, 87550 },	-- Vithrak, Gaze of the Deadman
                { 2, 82817 },	-- Robes of Koegler
                { 3, 82818 },	-- Vellum-Ripper Gloves
                { 4, 82815 },	-- Bindburner Belt
                { 5, 82819 },	-- Bradbury's Entropic Legguards
                { 6, 82812 },	-- Pyretic Legguards
                { 7, 81564 },	-- Scorched Scarlet Key
                { 8, 81565 },	-- Temperature-Sensing Necklace
                { 9, 82816 },	-- Melted Hypnotic Blade
                { 10, 82813 },	-- Koegler's Ritual Knife
                { 11, 82814 },	-- Mograine's Immaculate Might
                { 13, 87268, [ATLASLOOT_IT_FILTERIGNORE] = true }, -- Codex of the Crusade
                { 15, 82470 }, -- Ancient Tome of Portal: Dalaran
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 18, "ac6760" },
            },
            [CELESTIAL_DIFF] = {
                { 1, 95961 }, --Abandoned Zandalari Firecord
                { 2, 95962 }, --Abandoned Zandalari Shadowgirdle
                { 3, 95685 }, --Amulet of the Primal Turtle
                { 4, 95766 }, --Bonemender Bracers
                { 5, 95631 }, --Bracers of Constant Implosion
                { 6, 95711 }, --Breath of the Hydra
                { 7, 95630 }, --Chestplate of Violent Detonation
                { 8, 95740 }, --Chilblain Spaulders
                { 9, 95765 }, --Clear-Mind Helm
                { 10, 95819 }, -- Grips of Slicing Electricity
                { 11, 95713 }, -- Hood of Smoldering Flesh
                { 12, 95641 }, -- Horridon's Last Gasp
                { 13, 95658 }, -- Horridon's Tusk Fragment
                { 14, 95712 }, -- Inscribed Bag of Hydra-Spawn
                { 15, 95739 }, -- Leggings of Pulsing Blood
                { 16, 95820 }, -- Leggings of the Violent Gale
                { 17, 95821 }, -- Lei Shen's Grounded Carapace
                { 18, 95738 }, -- Lifedrainer's Sordid Grip
                { 19, 95793 }, -- Passionfire Choker
                { 20, 95659 }, -- Petrified Eye of the Basilisk
                { 21, 95792 }, -- Robes of the Moon Lotus
                { 22, 95960 }, -- Scalehide Spurs
                { 23, 95684 }, -- Shell-Coated Wristplates
                { 24, 95686 }, -- Shellsplitter Greataxe
                { 25, 95794 }, -- Shield of Twinned Despair
                { 26, 95767 }, -- Spaulders of Primordial Growth
                { 27, 95632 }, -- Worldbreaker's Stormscythe
                { 101, 87550 },	-- Vithrak, Gaze of the Deadman
                { 102, 82817 },	-- Robes of Koegler
                { 103, 82818 },	-- Vellum-Ripper Gloves
                { 104, 82815 },	-- Bindburner Belt
                { 105, 82819 },	-- Bradbury's Entropic Legguards
                { 106, 82812 },	-- Pyretic Legguards
                { 107, 81564 },	-- Scorched Scarlet Key
                { 108, 81565 },	-- Temperature-Sensing Necklace
                { 109, 82816 },	-- Melted Hypnotic Blade
                { 110, 82813 },	-- Koegler's Ritual Knife
                { 111, 82814 },	-- Mograine's Immaculate Might
                { 113, 87268, [ATLASLOOT_IT_FILTERIGNORE] = true }, -- Codex of the Crusade
                { 115, 82470 }, -- Ancient Tome of Portal: Dalaran
                { 116, "INV_Box_01", nil, AL["Tier Token iLvl502"], nil, "Tier15CelestialTierTokens" },
                { 118, "c3414", [ATLASLOOT_IT_AMOUNT1] = "2/5" }, -- August Stone Shard
                { 119, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 121, "ac60897" },
            },
        },
        MOP_DUNGEON_HERO_AC_TABLE,
        MOP_CELESTIAL_HERO_AC_TABLE,
        MOP_GLORY_OF_THE_HERO_AC_TABLE,
    }
}

data["ScarletMonasteryMoP"] = {
    EncounterJournalID = 316,
    InstanceID = 1004,
    MapID = 6109,
    ContentType = DUNGEON_CONTENT,
    LoadDifficulty = HEROIC_DIFF,
    LevelRange = {90, 90, 90},
    items = {
        {	--SMThalnos
            EncounterJournalID = 688,
            -- [NORMAL_DIFF] = "AtlasLootClassic",
            [HEROIC_DIFF] = {
                { 1, 81571 },	-- Soulrender Greatcloak
                { 2, 81569 },	-- Forgotten Bloodmage Mantle
                { 3, 81570 },	-- Legguards of the Crimson Magus
                { 4, 81572 },	-- Bracers of the Fallen Crusader
                { 5, 81560 },	-- Signet of the Hidden Door
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 18, "ac6946" },
            },
            [CELESTIAL_DIFF] = {
                { 1, 81571 },	-- Soulrender Greatcloak
                { 2, 81569 },	-- Forgotten Bloodmage Mantle
                { 3, 81570 },	-- Legguards of the Crimson Magus
                { 4, 81572 },	-- Bracers of the Fallen Crusader
                { 5, 81560 },	-- Signet of the Hidden Door
                { 16, "c3414", [ATLASLOOT_IT_AMOUNT1] = 2 }, -- August Stone Shard
                { 17, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 19, "ac6946" },
            },
        },
        {	--SMKorloff
            EncounterJournalID = 671,
            -- [NORMAL_DIFF] = "AtlasLootClassic",
            [HEROIC_DIFF] = {
                { 1, 81575 },	-- Scorched Earth Cloak
                { 2, 81573 },	-- Korloff's Raiment
                { 3, 81574 },	-- Helm of Rising Flame
                { 4, 81561 },	-- Firefinger Ring
                { 5, 81576 },	-- Firestorm Greatstaff
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 18, "ac6928" },
            },
            [CELESTIAL_DIFF] = {
                { 1, 81575 },	-- Scorched Earth Cloak
                { 2, 81573 },	-- Korloff's Raiment
                { 3, 81574 },	-- Helm of Rising Flame
                { 4, 81561 },	-- Firefinger Ring
                { 5, 81576 },	-- Firestorm Greatstaff
                { 16, "c3414", [ATLASLOOT_IT_AMOUNT1] = 2 }, -- August Stone Shard
                { 17, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 19, "ac6928" },
            },
        },
        {	--SMWhitemane
            EncounterJournalID = 674,
            -- [NORMAL_DIFF] = "AtlasLootClassic",
            [HEROIC_DIFF] = {
                { 1, 87551 },	-- Helios, Durand's Soul of Purity
                { 2, 81692 },	-- Whitemane's Embroidered Chapeau
                { 3, 81689 },	-- Leggings of Hallowed Fire
                { 4, 81690 },	-- Incarnadine Scarlet Spaulders
                { 5, 81688 },	-- Dashing Strike Treads
                { 6, 81578 },	-- Crown of Holy Flame
                { 7, 81687 },	-- Waistplate of Imminent Resurrection
                { 8, 81562 },	-- Triune Signet
                { 9, 81265 },	-- Flashing Steel Talisman
                { 10, 81577 },	-- Lightbreaker Greatsword
                { 11, 81691 },	-- Greatstaff of Righteousness
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 18, "ac6761" },
                { 19, "ac6929" },
            },
            [CELESTIAL_DIFF] = {
                { 1, 95635 }, -- Al'set's Tormented Leggings
                { 2, 95688 }, -- Azure Shell Bracers
                { 3, 95687 }, -- Beakbreaker Greatcloak
                { 4, 95796 }, -- Bracers of the Midnight Comet
                { 5, 95715 }, -- Chain of Consuming Magic
                { 6, 95741 }, -- Deadly Glare Cape
                { 7, 95742 }, -- Durumu's Captive Eyeball
                { 8, 95860 }, -- Fyn's Flickering Dagger
                { 9, 95797 }, -- Girdle of Night and Day
                { 10, 95769 }, -- Gore-Soaked Gear
                { 11, 95768 }, -- Greatshield of the Gloaming
                { 12, 95770 }, -- Hand of the Dark Animus
                { 13, 95965 }, -- Home-Warding Slippers
                { 14, 95716 }, -- Ice-Scored Treads
                { 15, 95858 }, -- Invocation of the Dawn
                { 16, 95633 }, -- Jin'rokh's Soulcrystal
                { 17, 95634 }, -- Lightningweaver Gauntlets
                { 18, 95714 }, -- Links of the Bifurcated Tongue
                { 19, 95859 }, -- Miracoran, the Vehement Chord
                { 20, 95964 }, -- Necklace of the Terra-Cotta Invoker
                { 21, 95743 }, -- Ritual Dagger of the Mind's Eye
                { 22, 95661 }, -- Roots of Rampaging Earth
                { 23, 95963 }, -- Silentflame Sandals
                { 24, 95662 }, -- Spaulders of Dinomancy
                { 25, 95689 }, -- Stonegaze Hood
                { 26, 95795 }, -- Suen-Wo, Spire of the Falling Sun
                { 27, 95660 }, -- Venomlord's Totemic Wand
                { 101, 87551 },	-- Helios, Durand's Soul of Purity
                { 102, 81692 },	-- Whitemane's Embroidered Chapeau
                { 103, 81689 },	-- Leggings of Hallowed Fire
                { 104, 81690 },	-- Incarnadine Scarlet Spaulders
                { 105, 81688 },	-- Dashing Strike Treads
                { 106, 81578 },	-- Crown of Holy Flame
                { 107, 81687 },	-- Waistplate of Imminent Resurrection
                { 108, 81562 },	-- Triune Signet
                { 109, 81265 },	-- Flashing Steel Talisman
                { 110, 81577 },	-- Lightbreaker Greatsword
                { 111, 81691 },	-- Greatstaff of Righteousness
                { 116, "INV_Box_01", nil, AL["Tier Token iLvl502"], nil, "Tier15CelestialTierTokens" },
                { 118, "c3414", [ATLASLOOT_IT_AMOUNT1] = "2/5" }, -- August Stone Shard
                { 119, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 121, "ac60898" },
                { 122, "ac6929" },
            },
        },
        -- {	--HallowsEndHeadlessHorseman
        -- 	name = AL["Headless Horseman"] .. "(" .. AL["Hallow's End"] .. ")",
        -- 	ExtraList = true,
        -- 	-- [NORMAL_DIFF] = "AtlasLoot_Collections:HallowsEnd:1",
        -- },
        MOP_DUNGEON_HERO_AC_TABLE,
        MOP_CELESTIAL_HERO_AC_TABLE,
        MOP_GLORY_OF_THE_HERO_AC_TABLE,
    }
}

data["ScholomanceMoP"] = {
    EncounterJournalID = 246,
    InstanceID = 1007,
    MapID = 6066,
    ContentType = DUNGEON_CONTENT,
    LoadDifficulty = HEROIC_DIFF,
    LevelRange = {90, 90, 90},
    items = {
        {	--ScholoChillheart
            EncounterJournalID = 659,
            -- [NORMAL_DIFF] = "AtlasLoot_Classic",
            [HEROIC_DIFF] = {
                { 1, 82823 },	-- Icewrath Belt
                { 2, 82820 },	-- Shadow Puppet Bracers
                { 3, 82821 },	-- Breastplate of Wracking Souls
                { 4, 81566 },	-- Anarchist's Pendant
                { 5, 82822 },	-- Gravetouch Greatsword
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
            },
            [CELESTIAL_DIFF] = {
                { 1, 82823 },	-- Icewrath Belt
                { 2, 82820 },	-- Shadow Puppet Bracers
                { 3, 82821 },	-- Breastplate of Wracking Souls
                { 4, 81566 },	-- Anarchist's Pendant
                { 5, 82822 },	-- Gravetouch Greatsword
                { 16, "c3414", [ATLASLOOT_IT_AMOUNT1] = 2 }, -- August Stone Shard
                { 17, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
            },
        },
        {	--ScholoJandice
            EncounterJournalID = 663,
            -- [NORMAL_DIFF] = "AtlasLoot_Classic",
            [HEROIC_DIFF] = {
                { 1, 82850 },	-- Phantasmal Drape
                { 2, 82848 },	-- Barovian Ritual Hood
                { 3, 82851 },	-- Ghostwoven Legguards
                { 4, 82852 },	-- Wraithplate Treads
                { 5, 82847 },	-- Metanoia Shield
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 18, "ac6531" },
            },
            [CELESTIAL_DIFF] = {
                { 1, 82850 },	-- Phantasmal Drape
                { 2, 82848 },	-- Barovian Ritual Hood
                { 3, 82851 },	-- Ghostwoven Legguards
                { 4, 82852 },	-- Wraithplate Treads
                { 5, 82847 },	-- Metanoia Shield
                { 16, "c3414", [ATLASLOOT_IT_AMOUNT1] = 2 }, -- August Stone Shard
                { 17, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 19, "ac6531" },
            },
        },
        {	--ScholoRattlegore
            EncounterJournalID = 665,
            -- [NORMAL_DIFF] = "AtlasLoot_Classic",
            [HEROIC_DIFF] = {
                { 1, 82825 },	-- Deadwalker Bracers
                { 2, 82827 },	-- Rattling Gloves
                { 3, 82828 },	-- Bone Golem Boots
                { 4, 82824 },	-- Goresoaked Headreaper
                { 5, 82826 },	-- Necromantic Wand
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 18, "ac6394" },
            },
            [CELESTIAL_DIFF] = {
                { 1, 82825 },	-- Deadwalker Bracers
                { 2, 82827 },	-- Rattling Gloves
                { 3, 82828 },	-- Bone Golem Boots
                { 4, 82824 },	-- Goresoaked Headreaper
                { 5, 82826 },	-- Necromantic Wand
                { 16, "c3414", [ATLASLOOT_IT_AMOUNT1] = 2 }, -- August Stone Shard
                { 17, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 19, "ac6394" },
            },
        },
        {	--ScholoVoss
            EncounterJournalID = 666,
            -- [NORMAL_DIFF] = "AtlasLoot_Classic",
            [HEROIC_DIFF] = {
                { 1, 82854 },	-- Leggings of Unleashed Anguish
                { 2, 82853 },	-- Soulburner Crown
                { 3, 82855 },	-- Shivbreaker Vest
                { 4, 82856 },	-- Dark Blaze Gauntlets
                { 5, 81567 },	-- Necklace of the Dark Blaze
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
            },
            [CELESTIAL_DIFF] = {
                { 1, 82825 },	-- Deadwalker Bracers
                { 2, 82827 },	-- Rattling Gloves
                { 3, 82828 },	-- Bone Golem Boots
                { 4, 82824 },	-- Goresoaked Headreaper
                { 5, 82826 },	-- Necromantic Wand
                { 16, "c3414", [ATLASLOOT_IT_AMOUNT1] = 2 }, -- August Stone Shard
                { 17, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 19, "ac6394" },
            },
        },
        {	--ScholoGandling
            EncounterJournalID = 684,
            -- [NORMAL_DIFF] = "AtlasLoot_Classic",
            [HEROIC_DIFF] = {
                { 1, 82859 }, -- Headmaster's Will
                { 2, 82861 }, -- Incineration Belt
                { 3, 82858 }, -- Tombstone Gauntlets
                { 4, 82860 }, -- Gloves of Explosive Pain
                { 5, 82862 }, -- Shoulderguards of Painful Lessons
                { 6, 82857 }, -- Vigorsteel Spaulders
                { 7, 81268 }, -- Lessons of the Darkmaster
                { 8, 81266 }, -- Price of Progress
                { 9, 81267 }, -- Searing Words
                { 16, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 18, "ac6762" },
                { 19, "ac6821" },
            },
            [CELESTIAL_DIFF] = {
                { 1, 95664 }, -- Armplates of the Vanquished Abomination
                { 2, 95665 }, -- Bad Juju
                { 3, 95772 }, -- Cha-Ye's Essence of Brilliance
                { 4, 95773 }, -- Constantly Accelerating Cloak
                { 5, 95718 }, -- Cord of Cacophonous Cawing
                { 6, 95690 }, -- Crystal-Claw Gloves
                { 7, 95862 }, -- Darkwood Spiritstaff
                { 8, 95966 }, -- Deeproot Treads
                { 9, 95801 }, -- Fingers of the Night
                { 10, 95636 }, -- Fissure-Split Shoulderwraps
                { 11, 95799 }, -- Gaze of the Twins
                { 12, 95771 }, -- Hood of the Crimson Wake
                { 13, 95746 }, -- Iceshatter Gauntlets
                { 14, 95638 }, -- Jin'rokh's Dreamshard
                { 15, 95663 }, -- Legguards of Scintillating Scales
                { 16, 95717 }, -- Pinionfeather Greatcloak
                { 17, 95719 }, -- Robe of Midnight Down
                { 18, 95637 }, -- Robes of Static Bursts
                { 19, 95744 }, -- Sandals of the Starving Eye
                { 20, 95691 }, -- Shimmershell Cape
                { 21, 95967 }, -- Spiritbound Boots
                { 22, 97129 }, -- Tia-Tia, the Scything Star
                { 23, 95798 }, -- Tidal Force Treads
                { 24, 95692 }, -- Tortos' Discarded Shell
                { 25, 95968 }, -- Vaultwalker Sabatons
                { 26, 95745 }, -- Vein-Cover Bracers
                { 27, 95861 }, -- Zeeg's Ancient Kegsmasher
                { 101, 82859 }, -- Headmaster's Will
                { 102, 82861 }, -- Incineration Belt
                { 103, 82858 }, -- Tombstone Gauntlets
                { 104, 82860 }, -- Gloves of Explosive Pain
                { 105, 82862 }, -- Shoulderguards of Painful Lessons
                { 106, 82857 }, -- Vigorsteel Spaulders
                { 107, 81268 }, -- Lessons of the Darkmaster
                { 108, 81266 }, -- Price of Progress
                { 109, 81267 }, -- Searing Words
                { 116, "INV_Box_01", nil, AL["Tier Token iLvl502"], nil, "Tier15CelestialTierTokens" },
                { 118, "c3414", [ATLASLOOT_IT_AMOUNT1] = "2/5" }, -- August Stone Shard
                { 119, "c395", [ATLASLOOT_IT_AMOUNT1] = 120 }, -- Justice Points
                { 121, "ac60899" },
                { 122, "ac6821" },
            },
        },
        MOP_DUNGEON_HERO_AC_TABLE,
        MOP_CELESTIAL_HERO_AC_TABLE,
        MOP_GLORY_OF_THE_HERO_AC_TABLE,
    }
}

data["WorldBossesMoP"] = {
    --EncounterJournalID = 322,
    name = AL["World Bosses"],
    ContentType = RAID_CONTENT,
    items = {
        {	--ShaofAnger
            EncounterJournalID = 691,
            [NORMAL_DIFF] = {
                { 1, "ICON_spell_nature_starfall", nil, ALIL["DRUID"], ALIL["Balance"] },
                { 2, 85308 },	-- Eternal Blossom Gloves
                { 3, 85306 },	-- Eternal Blossom Leggings
                { 5, "ICON_ability_druid_catform", nil, ALIL["DRUID"], ALIL["Feral"] },
                { 6, 85312 },	-- Eternal Blossom Grips
                { 7, 85310 },	-- Eternal Blossom Legguards
                { 9, "ICON_spell_nature_healingtouch", nil, ALIL["DRUID"], ALIL["Restoration"] },
                { 10, 85358 },	-- Eternal Blossom Handwraps
                { 11, 85356 },	-- Eternal Blossom Legwraps
                { 13, "ICON_ability_racial_bearform", nil, ALIL["DRUID"], ALIL["Guardian"] },
                { 14, 85380 },	-- Eternal Blossom Handguards
                { 15, 85382 },	-- Eternal Blossom Breeches
                { 16, "ICON_spell_nature_starfall", nil, ALIL["DRUID"], ALIL["Balance"] },
                { 17, 84843 },	-- Malevolent Gladiator's Wyrmhide Gloves
                { 20, "ICON_ability_druid_catform", nil, ALIL["DRUID"], ALIL["Feral"] },
                { 21, 84832 },	-- Malevolent Gladiator's Dragonhide Gloves
                { 24, "ICON_spell_nature_healingtouch", nil, ALIL["DRUID"], ALIL["Restoration"] },
                { 25, 84833 },	-- Malevolent Gladiator's Kodohide Gloves
                { 101, "ICON_inv_weapon_bow_07", nil, ALIL["HUNTER"], nil },
                { 102, 85297 },	-- Yaungol Slayer's Gloves
                { 103, 85295 },	-- Yaungol Slayer's Legguards
                { 105, "ICON_inv_staff_13", nil, ALIL["MAGE"], nil },
                { 106, 85378 },	-- Gloves of the Burning Scroll
                { 107, 85376 },	-- Leggings of the Burning Scroll
                { 109, "ICON_inv_throwingknife_04", nil, ALIL["ROGUE"], nil },
                { 110, 85302 },	-- Gloves of the Thousandfold Blades
                { 111, 85300 },	-- Legguards of the Thousandfold Blades
                { 113, "ICON_spell_nature_drowsy", nil, ALIL["WARLOCK"], nil },
                { 114, 85369 },	-- Sha-Skin Gloves
                { 115, 85371 },	-- Sha-Skin Leggings
                { 116, "ICON_inv_weapon_bow_07", nil, ALIL["HUNTER"], nil },
                { 117, 84841 },	-- Malevolent Gladiator's Chain Gauntlets
                { 120, "ICON_inv_staff_13", nil, ALIL["MAGE"], nil },
                { 121, 84837 },	-- Malevolent Gladiator's Silk Handguards
                { 124, "ICON_inv_throwingknife_04", nil, ALIL["ROGUE"], nil },
                { 125, 84830 },	-- Malevolent Gladiator's Leather Gloves
                { 128, "ICON_spell_nature_drowsy", nil, ALIL["WARLOCK"], nil },
                { 129, 84842 },	-- Malevolent Gladiator's Felweave Handguards
                { 201, "ICON_spell_monk_mistweaver_spec", nil, ALIL["MONK"], ALIL["Mistweaver"] },
                { 202, 85389 },	-- Red Crane Handwraps
                { 203, 85391 },	-- Red Crane Legwraps
                { 205, "ICON_spell_monk_windwalker_spec", nil, ALIL["MONK"], ALIL["Windwalker"] },
                { 206, 85395 },	-- Red Crane Grips
                { 207, 85397 },	-- Red Crane Leggings
                { 209, "ICON_spell_monk_brewmaster_spec", nil, ALIL["MONK"], ALIL["Brewmaster"] },
                { 210, 85387 },	-- Red Crane Gauntlets
                { 211, 85385 },	-- Red Crane Legguards
                { 216, "ICON_spell_monk_mistweaver_spec", nil, ALIL["MONK"], ALIL["Mistweaver"] },
                { 217, 84836 },	-- Malevolent Gladiator's Copperskin Gloves
                { 220, "ICON_spell_monk_windwalker_spec", nil, ALIL["MONK"], ALIL["Windwalker"] },
                { 221, 84839 },	-- Malevolent Gladiator's Ironskin Gloves
                { 301, "ICON_Spell_Holy_HolyBolt", nil, ALIL["PALADIN"], ALIL["Holy"] },
                { 302, 85347 },	-- White Tiger Gloves
                { 303, 85345 },	-- White Tiger Greaves
                { 305, "ICON_Spell_Holy_AuraOfLight", nil, ALIL["PALADIN"], ALIL["Retribution"] },
                { 306, 85342 },	-- White Tiger Gauntlets
                { 307, 85340 },	-- White Tiger Legplates
                { 309, "ICON_spell_holy_devotionaura", nil, ALIL["PALADIN"], ALIL["Protection"] },
                { 310, 85322 },	-- White Tiger Handguards
                { 311, 85320 },	-- White Tiger Legguards
                { 316, "ICON_Spell_Holy_HolyBolt", nil, ALIL["PALADIN"], ALIL["Holy"] },
                { 317, 84831 },	-- Malevolent Gladiator's Ornamented Gloves
                { 320, "ICON_Spell_Holy_AuraOfLight", nil, ALIL["PALADIN"], ALIL["Retribution"] },
                { 321, 84834 },	-- Malevolent Gladiator's Scaled Gauntlets
                { 401, "ICON_spell_holy_guardianspirit", nil, ALIL["PRIEST"], ALIL["Discipline"] .. " / " .. ALIL["Holy"] },
                { 402, 85363 },	-- Guardian Serpent Handwraps
                { 403, 85361 },	-- Guardian Serpent Legwraps
                { 405, "ICON_spell_shadow_shadowwordpain", nil, ALIL["PRIEST"], ALIL["Shadow"] },
                { 406, 85364 },	-- Guardian Serpent Gloves
                { 407, 85366 },	-- Guardian Serpent Leggings
                { 416, "ICON_spell_holy_guardianspirit", nil, ALIL["PRIEST"], ALIL["Discipline"] .. " / " .. ALIL["Holy"] },
                { 417, 84846 },	-- Malevolent Gladiator's Mooncloth Gloves
                { 420, "ICON_spell_shadow_shadowwordpain", nil, ALIL["PRIEST"], ALIL["Shadow"] },
                { 421, 84838 },	-- Malevolent Gladiator's Satin Gloves
                { 501, "ICON_Spell_Nature_Lightning", nil, ALIL["SHAMAN"], ALIL["Elemental"] },
                { 502, 85290 },	-- Firebird's Gloves
                { 503, 85292 },	-- Firebird's Kilt
                { 505, "ICON_spell_nature_lightningshield", nil, ALIL["SHAMAN"], ALIL["Enhancement"] },
                { 506, 85287 },	-- Firebird's Grips
                { 507, 85285 },	-- Firebird's Legguards
                { 509, "ICON_spell_nature_magicimmunity", nil, ALIL["SHAMAN"], ALIL["Restoration"] },
                { 510, 85352 },	-- Firebird's Handwraps
                { 511, 85350 },	-- Firebird's Legwraps
                { 516, "ICON_Spell_Nature_Lightning", nil, ALIL["SHAMAN"], ALIL["Elemental"] },
                { 517, 84845 },	-- Malevolent Gladiator's Mail Gauntlets
                { 520, "ICON_spell_nature_lightningshield", nil, ALIL["SHAMAN"], ALIL["Enhancement"] },
                { 521, 84844 },	-- Malevolent Gladiator's Linked Gauntlets
                { 524, "ICON_spell_nature_magicimmunity", nil, ALIL["SHAMAN"], ALIL["Restoration"] },
                { 525, 84847 },	-- Malevolent Gladiator's Ringmail Gauntlets
                { 601, "ICON_spell_deathknight_frostpresence", nil, ALIL["DEATHKNIGHT"], ALIL["Frost"] .. " / " .. ALIL["Unholy"] },
                { 602, 85337 },	-- Gauntlets of the Lost Catacomb
                { 603, 85335 },	-- Greaves of the Lost Catacomb
                { 605, "ICON_spell_deathknight_bloodpresence", nil, ALIL["DEATHKNIGHT"], ALIL["Blood"] },
                { 606, 85317 },	-- Handguards of the Lost Catacomb
                { 607, 85315 },	-- Legguards of the Lost Catacomb
                { 609, "ICON_ability_warrior_innerrage", nil, ALIL["WARRIOR"], ALIL["Arms"] .. " / " .. ALIL["Fury"] },
                { 610, 85331 },	-- Gauntlets of Resounding Rings
                { 611, 85330 },	-- Legplates of Resounding Rings
                { 613, "ICON_ability_warrior_defensivestance", nil, ALIL["WARRIOR"], ALIL["Protection"] },
                { 614, 85327 },	-- Handguards of Resounding Rings
                { 615, 85325 },	-- Legguards of Resounding Rings
                { 616, "ICON_Spell_deathknight_classicon", nil, ALIL["DEATHKNIGHT"], nil },
                { 617, 84835 },	-- Malevolent Gladiator's Dreadplate Gauntlets
                { 624, "ICON_inv_sword_27", nil, ALIL["WARRIOR"], nil },
                { 625, 84840 },	-- Malevolent Gladiator's Plate Gauntlets
                { 701, 84977 },	-- Malevolent Gladiator's Cuffs of Accuracy
                { 702, 84955 },	-- Malevolent Gladiator's Cord of Accuracy
                { 703, 84815 },	-- Malevolent Gladiator's Treads of Alacrity
                { 705, 84979 },	-- Malevolent Gladiator's Cuffs of Meditation
                { 706, 84956 },	-- Malevolent Gladiator's Cord of Meditation
                { 707, 84816 },	-- Malevolent Gladiator's Treads of Meditation
                { 709, 84978 },	-- Malevolent Gladiator's Cuffs of Prowess
                { 710, 84954 },	-- Malevolent Gladiator's Cord of Cruelty
                { 711, 84814 },	-- Malevolent Gladiator's Treads of Cruelty
                { 716, 84973 },	-- Malevolent Gladiator's Armwraps of Accuracy
                { 717, 84948 },	-- Malevolent Gladiator's Waistband of Accuracy
                { 718, 84808 },	-- Malevolent Gladiator's Boots of Cruelty
                { 720, 84972 },	-- Malevolent Gladiator's Armwraps of Alacrity
                { 721, 84947 },	-- Malevolent Gladiator's Waistband of Cruelty
                { 722, 84809 },	-- Malevolent Gladiator's Boots of Alacrity
                { 724, 84982 },	-- Malevolent Gladiator's Bindings of Prowess
                { 725, 84960 },	-- Malevolent Gladiator's Belt of Cruelty
                { 726, 84819 },	-- Malevolent Gladiator's Footguards of Alacrity
                { 728, 84976 },	-- Malevolent Gladiator's Bindings of Meditation
                { 729, 84953 },	-- Malevolent Gladiator's Belt of Meditation
                { 730, 84813 },	-- Malevolent Gladiator's Footguards of Meditation
                { 801, 84984 },	-- Malevolent Gladiator's Armbands of Meditation
                { 802, 84946 },	-- Malevolent Gladiator's Waistguard of Meditation
                { 803, 84821 },	-- Malevolent Gladiator's Footguards of Meditation
                { 805, 84983 },	-- Malevolent Gladiator's Armbands of Prowess
                { 806, 84959 },	-- Malevolent Gladiator's Waistguard of Cruelty
                { 807, 84820 },	-- Malevolent Gladiator's Footguards of Alacrity
                { 809, 84980 },	-- Malevolent Gladiator's Wristguards of Alacrity
                { 810, 84958 },	-- Malevolent Gladiator's Links of Cruelty
                { 811, 84818 },	-- Malevolent Gladiator's Sabatons of Alacrity
                { 813, 84981 },	-- Malevolent Gladiator's Wristguards of Accuracy
                { 814, 84957 },	-- Malevolent Gladiator's Links of Accuracy
                { 815, 84817 },	-- Malevolent Gladiator's Sabatons of Cruelty
                { 816, 84975 },	-- Malevolent Gladiator's Bracers of Meditation
                { 817, 84952 },	-- Malevolent Gladiator's Clasp of Meditation
                { 818, 84812 },	-- Malevolent Gladiator's Greaves of Meditation
                { 820, 84985 },	-- Malevolent Gladiator's Armplates of Proficiency
                { 821, 84949 },	-- Malevolent Gladiator's Girdle of Accuracy
                { 822, 84810 },	-- Malevolent Gladiator's Warboots of Cruelty
                { 824, 84974 },	-- Malevolent Gladiator's Bracers of Prowess
                { 825, 84951 },	-- Malevolent Gladiator's Clasp of Cruelty
                { 826, 84811 },	-- Malevolent Gladiator's Greaves of Alacrity
                { 828, 84986 },	-- Malevolent Gladiator's Armplates of Alacrity
                { 829, 84950 },	-- Malevolent Gladiator's Girdle of Prowess
                { 830, 84822 },	-- Malevolent Gladiator's Warboots of Alacrity
                { 901, 84804 },	-- Malevolent Gladiator's Cape of Cruelty
                { 902, 84805 },	-- Malevolent Gladiator's Cape of Prowess
                { 903, 84807 },	-- Malevolent Gladiator's Cloak of Alacrity
                { 904, 84806 },	-- Malevolent Gladiator's Cloak of Prowess
                { 905, 84801 },	-- Malevolent Gladiator's Drape of Cruelty
                { 906, 84802 },	-- Malevolent Gladiator's Drape of Meditation
                { 907, 84803 },	-- Malevolent Gladiator's Drape of Prowess
                { 909, 84892 },	-- Malevolent Gladiator's Choker of Accuracy
                { 910, 84891 },	-- Malevolent Gladiator's Choker of Proficiency
                { 911, 84889 },	-- Malevolent Gladiator's Necklace of Proficiency
                { 912, 84890 },	-- Malevolent Gladiator's Necklace of Prowess
                { 913, 84886 },	-- Malevolent Gladiator's Pendant of Alacrity
                { 914, 84887 },	-- Malevolent Gladiator's Pendant of Cruelty
                { 915, 84888 },	-- Malevolent Gladiator's Pendant of Meditation
                { 916, 84824 },	-- Malevolent Gladiator's Band of Accuracy
                { 917, 84823 },	-- Malevolent Gladiator's Band of Cruelty
                { 918, 84825 },	-- Malevolent Gladiator's Band of Meditation
                { 919, 84827 },	-- Malevolent Gladiator's Ring of Accuracy
                { 920, 84826 },	-- Malevolent Gladiator's Ring of Cruelty
                { 921, 84829 },	-- Malevolent Gladiator's Signet of Accuracy
                { 922, 84828 },	-- Malevolent Gladiator's Signet of Cruelty
                { 1001, 89317 },	-- Claw of Anger
                { 1002, 90911 },	-- Furyheart Treads
                { 1003, 90913 },	-- Sandals of the Shadow
                { 1004, 90914 },	-- Boots of Raging Haze
                { 1005, 90908 },	-- Crushing Treads of Anger
                { 1006, 90907 },	-- Boots of Unbreakable Umbrage
                { 1007, 90906 };	-- Treads of Ardent Antagonism
                { 1008, 90912 },	-- Angerforged Stompers
                { 1009, 90909 };	-- Intemperate Greatboots
                { 1010, 90910 },	-- Mindfire Sollerets
                { 1016, 87771 },	-- Reins of the Heavenly Onyx Cloud Serpent
                { 1017, 90839 },	-- Cache of Sha-Touched Gold
                { 1019, "ac6480" },
            },
        },
        {	--SalyisWarband
            EncounterJournalID = 725,
            [NORMAL_DIFF] = {
                { 1, 90408 },	-- Free Spirit Hood
                { 2, 90409 },	-- Sky-Sear Cowl
                { 3, 90417 },	-- Robes of Blue Skies
                { 4, 90418 },	-- Robes of the Lightning Rider
                { 5, 90449 },	-- Belt of Detonation
                { 6, 90448 },	-- Cannonfire Cord
                { 7, 90439 },	-- Open Steppe Sandals
                { 8, 90440 },	-- Slippers of Fiery Retribution
                { 10, 90413 },	-- Crest of the Grand Warband
                { 11, 90412 },	-- Helm of Restoring Wind
                { 12, 90422 },	-- Armor of the Single Cloud
                { 13, 90421 },	-- Chain of Unsiezed Skies
                { 16, 90410 },	-- Cap of Wandering Pride
                { 17, 90411 },	-- Facemask of Unrepentant Banditry
                { 18, 90419 },	-- Fireproofed Chestguard
                { 19, 90420 },	-- Flameshot Wrap
                { 20, 90451 },	-- Cannoneer's Gunpowder Carrier
                { 21, 90450 },	-- Carrot-Holder Belt
                { 22, 90442 },	-- Flamefoot Tabi
                { 23, 90441 },	-- Stompdodger Boots
                { 25, 90453 },	-- Girdle of the Raging Rider
                { 26, 90452 },	-- Sparkmaker Girdle
                { 27, 90443 },	-- Burnmender Boots
                { 28, 90444 },	-- Treads of Gentle Nudges
                { 30, "ac6517" },
                { 101, 90416 },	-- Crown of Ranging Invasion
                { 102, 90415 },	-- Giantfoot Headguard
                { 103, 90414 },	-- Greathelm of the Monstrous Mushan
                { 104, 90425 },	-- Carapace of Crushed Conviction
                { 105, 90423 },	-- Chestguard of the Unbowed Back
                { 106, 90424 },	-- Ravaging Warrior's Chestplate
                { 107, 90456 },	-- Cord of Crazed Strength
                { 108, 90454 },	-- Girdle of the Galloping Giant
                { 109, 90455 },	-- Greatbelt of Livid Fury
                { 110, 90445 },	-- Firerider Treads
                { 111, 90446 },	-- Silverspur Warboots
                { 112, 90447 },	-- Stompers of Vigorous Stomping
                { 116, 90432 },	-- Hellrider's Choker
                { 117, 90433 },	-- Mushan Rider's Collar
                { 118, 90429 },	-- Necklace of Imbued Fury
                { 119, 90431 },	-- Saddlebinder Links
                { 120, 90430 },	-- Stomphowl Pendant
                { 122, 90436 },	-- Circle of Scaled Fury
                { 123, 90437 },	-- Hereditary Saurok Loop
                { 124, 90435 },	-- Ring of Wretched Flames
                { 125, 90438 },	-- Signet of the Bandit Lord
                { 126, 90434 },	-- Steaming Seal of Flame
                { 128, 89783,},	-- Son of Galleon's Saddle
                { 129, 90840 },	-- Marauder's Gleaming Sack of Gold
            },
        },
        {	--Nalak
            EncounterJournalID = 814,
            ContentPhaseMoP = 3,
            [NORMAL_DIFF] = {
                { 1, "ICON_spell_nature_starfall", nil, ALIL["DRUID"], ALIL["Balance"] },
                { 2, 95245 },	-- Gloves of the Haunted Forest
                { 3, 95247 },	-- Leggings of the Haunted Forest
                { 5, "ICON_ability_druid_catform", nil, ALIL["DRUID"], ALIL["Feral"] },
                { 6, 95236 },	-- Grips of the Haunted Forest
                { 7, 95238 },	-- Legguards of the Haunted Forest
                { 9, "ICON_spell_nature_healingtouch", nil, ALIL["DRUID"], ALIL["Restoration"] },
                { 10, 95240 },	-- Handwraps of the Haunted Forest
                { 11, 95242 },	-- Legwraps of the Haunted Forest
                { 13, "ICON_ability_racial_bearform", nil, ALIL["DRUID"], ALIL["Guardian"] },
                { 14, 95251 },	-- Handguards of the Haunted Forest
                { 15, 95253 },	-- Breeches of the Haunted Forest
                { 16, "ICON_spell_nature_starfall", nil, ALIL["DRUID"], ALIL["Balance"] },
                { 17, [ATLASLOOT_IT_ALLIANCE] = 91189, [ATLASLOOT_IT_HORDE] = 94412 },	-- Tyrannical Gladiator's Wyrmhide Gloves
                { 18, [ATLASLOOT_IT_ALLIANCE] = 91193, [ATLASLOOT_IT_HORDE] = 94483 },	-- Tyrannical Gladiator's Wyrmhide Legguards
                { 20, "ICON_ability_druid_catform", nil, ALIL["DRUID"], ALIL["Feral"] },
                { 21, [ATLASLOOT_IT_ALLIANCE] = 91157, [ATLASLOOT_IT_HORDE] = 94455 },	-- Tyrannical Gladiator's Dragonhide Gloves
                { 22, [ATLASLOOT_IT_ALLIANCE] = 91161, [ATLASLOOT_IT_HORDE] = 94368 },	-- Tyrannical Gladiator's Dragonhide Legguards
                { 24, "ICON_spell_nature_healingtouch", nil, ALIL["DRUID"], ALIL["Restoration"] },
                { 25, [ATLASLOOT_IT_ALLIANCE] = 91172, [ATLASLOOT_IT_HORDE] = 94371 },	-- Tyrannical Gladiator's Kodohide Gloves
                { 26, [ATLASLOOT_IT_ALLIANCE] = 91176, [ATLASLOOT_IT_HORDE] = 94477 },	-- Tyrannical Gladiator's Kodohide Legguards
                { 101, "ICON_inv_weapon_bow_07", nil, ALIL["HUNTER"], nil },
                { 102, 95256 },	-- Saurok Stalker's Gloves
                { 103, 95258 },	-- Saurok Stalker's Legguards
                { 105, "ICON_inv_staff_13", nil, ALIL["MAGE"], nil },
                { 106, 95260 },	-- Gloves of the Chromatic Hydra
                { 107, 95262 },	-- Leggings of the Chromatic Hydra
                { 109, "ICON_inv_throwingknife_04", nil, ALIL["ROGUE"], nil },
                { 110, 95306 },	-- Nine-Tailed Gloves
                { 111, 95308 },	-- Nine-Tailed Legguards
                { 113, "ICON_spell_nature_drowsy", nil, ALIL["WARLOCK"], nil },
                { 114, 95325 },	-- Gloves of the Thousandfold Hells
                { 115, 95327 },	-- Leggings of the Thousandfold Hells
                { 116, "ICON_inv_weapon_bow_07", nil, ALIL["HUNTER"], nil },
                { 117, [ATLASLOOT_IT_ALLIANCE] = 91224, [ATLASLOOT_IT_HORDE] = 94453 },	-- Tyrannical Gladiator's Chain Gauntlets
                { 118, [ATLASLOOT_IT_ALLIANCE] = 91228, [ATLASLOOT_IT_HORDE] = 94384 },	-- Tyrannical Gladiator's Chain Leggings
                { 120, "ICON_inv_staff_13", nil, ALIL["MAGE"], nil },
                { 121, [ATLASLOOT_IT_ALLIANCE] = 91232, [ATLASLOOT_IT_HORDE] = 94451 },	-- Tyrannical Gladiator's Silk Handguards
                { 122, [ATLASLOOT_IT_ALLIANCE] = 91236, [ATLASLOOT_IT_HORDE] = 94362 },	-- Tyrannical Gladiator's Silk Trousers
                { 124, "ICON_inv_throwingknife_04", nil, ALIL["ROGUE"], nil },
                { 125, [ATLASLOOT_IT_ALLIANCE] = 91342, [ATLASLOOT_IT_HORDE] = 94377 },	-- Tyrannical Gladiator's Leather Gloves
                { 126, [ATLASLOOT_IT_ALLIANCE] = 91346, [ATLASLOOT_IT_HORDE] = 94446 },	-- Tyrannical Gladiator's Leather Legguards
                { 128, "ICON_spell_nature_drowsy", nil, ALIL["WARLOCK"], nil },
                { 129, [ATLASLOOT_IT_ALLIANCE] = 91420, [ATLASLOOT_IT_HORDE] = 94441 },	-- Tyrannical Gladiator's Felweave Handguards
                { 130, [ATLASLOOT_IT_ALLIANCE] = 91424, [ATLASLOOT_IT_HORDE] = 94471 },	-- Tyrannical Gladiator's Felweave Trousers
                { 201, "ICON_spell_monk_mistweaver_spec", nil, ALIL["MONK"], ALIL["Mistweaver"] },
                { 202, 95270 },	-- Fire-Charm Handwraps
                { 203, 95272 },	-- Fire-Charm Legwraps
                { 205, "ICON_spell_monk_windwalker_spec", nil, ALIL["MONK"], ALIL["Windwalker"] },
                { 206, 95266 },	-- Fire-Charm Grips
                { 207, 95268 },	-- Fire-Charm Leggings
                { 209, "ICON_spell_monk_brewmaster_spec", nil, ALIL["MONK"], ALIL["Brewmaster"] },
                { 210, 95276 },	-- Fire-Charm Gauntlets
                { 211, 95278 },	-- Fire-Charm Legguards
                { 216, "ICON_spell_monk_mistweaver_spec", nil, ALIL["MONK"], ALIL["Mistweaver"] },
                { 217, [ATLASLOOT_IT_ALLIANCE] = 91257, [ATLASLOOT_IT_HORDE] = 94340 },	-- Tyrannical Gladiator's Copperskin Gloves
                { 218, [ATLASLOOT_IT_ALLIANCE] = 91261, [ATLASLOOT_IT_HORDE] = 94478 },	-- Tyrannical Gladiator's Copperskin Legguards
                { 220, "ICON_spell_monk_windwalker_spec", nil, ALIL["MONK"], ALIL["Windwalker"] },
                { 221, [ATLASLOOT_IT_ALLIANCE] = 91247, [ATLASLOOT_IT_HORDE] = 94391 },	-- Tyrannical Gladiator's Ironskin Gloves
                { 222, [ATLASLOOT_IT_ALLIANCE] = 91251, [ATLASLOOT_IT_HORDE] = 94370 },	-- Tyrannical Gladiator's Ironskin Legguards
                { 301, "ICON_Spell_Holy_HolyBolt", nil, ALIL["PALADIN"], ALIL["Holy"] },
                { 302, 95286 },	-- Lightning Emperor's Gloves
                { 303, 95288 },	-- Lightning Emperor's Greaves
                { 305, "ICON_Spell_Holy_AuraOfLight", nil, ALIL["PALADIN"], ALIL["Retribution"] },
                { 306, 95281 },	-- Lightning Emperor's Gauntlets
                { 307, 95283 },	-- Lightning Emperor's Legplates
                { 309, "ICON_spell_holy_devotionaura", nil, ALIL["PALADIN"], ALIL["Protection"] },
                { 310, 95291 },	-- Lightning Emperor's Handguards
                { 311, 95293 },	-- Lightning Emperor's Legguards
                { 316, "ICON_Spell_Holy_HolyBolt", nil, ALIL["PALADIN"], ALIL["Holy"] },
                { 317, [ATLASLOOT_IT_ALLIANCE] = 91289, [ATLASLOOT_IT_HORDE] = 94438 },	-- Tyrannical Gladiator's Ornamented Gloves
                { 318, [ATLASLOOT_IT_ALLIANCE] = 91293, [ATLASLOOT_IT_HORDE] = 94484 },	-- Tyrannical Gladiator's Ornamented Legplates
                { 320, "ICON_Spell_Holy_AuraOfLight", nil, ALIL["PALADIN"], ALIL["Retribution"] },
                { 321, [ATLASLOOT_IT_ALLIANCE] = 91269, [ATLASLOOT_IT_HORDE] = 94343 },	-- Tyrannical Gladiator's Scaled Gauntlets
                { 322, [ATLASLOOT_IT_ALLIANCE] = 91273, [ATLASLOOT_IT_HORDE] = 94496 },	-- Tyrannical Gladiator's Scaled Legguards
                { 401, "ICON_spell_holy_guardianspirit", nil, ALIL["PRIEST"], ALIL["Discipline"] .. " / " .. ALIL["Holy"] },
                { 402, 95295 },	-- Handwraps of the Exorcist
                { 403, 95297 },	-- Legwraps of the Exorcist
                { 405, "ICON_spell_shadow_shadowwordpain", nil, ALIL["PRIEST"], ALIL["Shadow"] },
                { 406, 95300 },	-- Gloves of the Exorcist
                { 407, 95302 },	-- Leggings of the Exorcist
                { 416, "ICON_spell_holy_guardianspirit", nil, ALIL["PRIEST"], ALIL["Discipline"] .. " / " .. ALIL["Holy"] },
                { 417, [ATLASLOOT_IT_ALLIANCE] = 91309, [ATLASLOOT_IT_HORDE] = 94328 },	-- Tyrannical Gladiator's Mooncloth Gloves
                { 418, [ATLASLOOT_IT_ALLIANCE] = 91313, [ATLASLOOT_IT_HORDE] = 94420 },	-- Tyrannical Gladiator's Mooncloth Leggings
                { 420, "ICON_spell_shadow_shadowwordpain", nil, ALIL["PRIEST"], ALIL["Shadow"] },
                { 421, [ATLASLOOT_IT_ALLIANCE] = 91319, [ATLASLOOT_IT_HORDE] = 94423 },	-- Tyrannical Gladiator's Satin Gloves
                { 422, [ATLASLOOT_IT_ALLIANCE] = 91323, [ATLASLOOT_IT_HORDE] = 94334 },	-- Tyrannical Gladiator's Satin Leggings
                { 501, "ICON_Spell_Nature_Lightning", nil, ALIL["SHAMAN"], ALIL["Elemental"] },
                { 502, 95321 },	-- Gloves of the Witch Doctor
                { 503, 95323 },	-- Kilt of the Witch Doctor
                { 505, "ICON_spell_nature_lightningshield", nil, ALIL["SHAMAN"], ALIL["Enhancement"] },
                { 506, 95316 },	-- Grips of the Witch Doctor
                { 507, 95318 },	-- Legguards of the Witch Doctor
                { 509, "ICON_spell_nature_magicimmunity", nil, ALIL["SHAMAN"], ALIL["Restoration"] },
                { 510, 95311 },	-- Handwraps of the Witch Doctor
                { 511, 95313 },	-- Legwraps of the Witch Doctor
                { 516, "ICON_Spell_Nature_Lightning", nil, ALIL["SHAMAN"], ALIL["Elemental"] },
                { 517, [ATLASLOOT_IT_ALLIANCE] = 91382, [ATLASLOOT_IT_HORDE] = 94408 },	-- Tyrannical Gladiator's Mail Gauntlets
                { 518, [ATLASLOOT_IT_ALLIANCE] = 91386, [ATLASLOOT_IT_HORDE] = 94497 },	-- Tyrannical Gladiator's Mail Leggings
                { 520, "ICON_spell_nature_lightningshield", nil, ALIL["SHAMAN"], ALIL["Enhancement"] },
                { 521, [ATLASLOOT_IT_ALLIANCE] = 91370, [ATLASLOOT_IT_HORDE] = 94458 },	-- Tyrannical Gladiator's Linked Gauntlets
                { 522, [ATLASLOOT_IT_ALLIANCE] = 91374, [ATLASLOOT_IT_HORDE] = 94494 },	-- Tyrannical Gladiator's Linked Leggings
                { 524, "ICON_spell_nature_magicimmunity", nil, ALIL["SHAMAN"], ALIL["Restoration"] },
                { 525, [ATLASLOOT_IT_ALLIANCE] = 91360, [ATLASLOOT_IT_HORDE] = 94490 },	-- Tyrannical Gladiator's Ringmail Gauntlets
                { 526, [ATLASLOOT_IT_ALLIANCE] = 91364, [ATLASLOOT_IT_HORDE] = 94435 },	-- Tyrannical Gladiator's Ringmail Leggings
                { 601, "ICON_spell_deathknight_frostpresence", nil, ALIL["DEATHKNIGHT"], ALIL["Frost"] .. " / " .. ALIL["Unholy"] },
                { 602, 95226 },	-- Gauntlets of the All-Consuming Maw
                { 603, 95228 },	-- Greaves of the All-Consuming Maw
                { 605, "ICON_spell_deathknight_bloodpresence", nil, ALIL["DEATHKNIGHT"], ALIL["Blood"] },
                { 606, 95231 },	-- Handguards of the All-Consuming Maw
                { 607, 95233 },	-- Legguards of the All-Consuming Maw
                { 609, "ICON_ability_warrior_innerrage", nil, ALIL["WARRIOR"], ALIL["Arms"] .. " / " .. ALIL["Fury"] },
                { 610, 95332 },	-- Gauntlets of the Last Mogu
                { 611, 95333 },	-- Legplates of the Last Mogu
                { 613, "ICON_ability_warrior_defensivestance", nil, ALIL["WARRIOR"], ALIL["Protection"] },
                { 614, 95336 },	-- Handguards of the Last Mogu
                { 615, 95338 },	-- Legguards of the Last Mogu
                { 616, "ICON_Spell_deathknight_classicon", nil, ALIL["DEATHKNIGHT"], nil },
                { 617, [ATLASLOOT_IT_ALLIANCE] = 91149, [ATLASLOOT_IT_HORDE] = 94364 },	-- Tyrannical Gladiator's Dreadplate Gauntlets
                { 618, [ATLASLOOT_IT_ALLIANCE] = 91153, [ATLASLOOT_IT_HORDE] = 94365 },	-- Tyrannical Gladiator's Dreadplate Legguards
                { 624, "ICON_inv_sword_27", nil, ALIL["WARRIOR"], nil },
                { 625, [ATLASLOOT_IT_ALLIANCE] = 91432, [ATLASLOOT_IT_HORDE] = 94331 },	-- Tyrannical Gladiator's Plate Gauntlets
                { 626, [ATLASLOOT_IT_ALLIANCE] = 91436, [ATLASLOOT_IT_HORDE] = 94448 },	-- Tyrannical Gladiator's Plate Legguards
                { 701, [ATLASLOOT_IT_ALLIANCE] = 91121, [ATLASLOOT_IT_HORDE] = 94403 },	-- Tyrannical Gladiator's Cuffs of Accuracy
                { 702, [ATLASLOOT_IT_ALLIANCE] = 91111, [ATLASLOOT_IT_HORDE] = 94376 },	-- Tyrannical Gladiator's Cord of Accuracy
                { 703, [ATLASLOOT_IT_ALLIANCE] = 91117, [ATLASLOOT_IT_HORDE] = 94333 },	-- Tyrannical Gladiator's Treads of Alacrity
                { 705, [ATLASLOOT_IT_ALLIANCE] = 91123, [ATLASLOOT_IT_HORDE] = 94380 },	-- Tyrannical Gladiator's Cuffs of Meditation
                { 706, [ATLASLOOT_IT_ALLIANCE] = 91113, [ATLASLOOT_IT_HORDE] = 94425 },	-- Tyrannical Gladiator's Cord of Meditation
                { 707, [ATLASLOOT_IT_ALLIANCE] = 91119, [ATLASLOOT_IT_HORDE] = 94468 },	-- Tyrannical Gladiator's Treads of Meditation
                { 709, [ATLASLOOT_IT_ALLIANCE] = 91122, [ATLASLOOT_IT_HORDE] = 94449 },	-- Tyrannical Gladiator's Cuffs of Prowess
                { 710, [ATLASLOOT_IT_ALLIANCE] = 91109, [ATLASLOOT_IT_HORDE] = 94400 },	-- Tyrannical Gladiator's Cord of Cruelty
                { 711, [ATLASLOOT_IT_ALLIANCE] = 91115, [ATLASLOOT_IT_HORDE] = 94402 },	-- Tyrannical Gladiator's Treads of Cruelty
                { 716, [ATLASLOOT_IT_ALLIANCE] = 91246, [ATLASLOOT_IT_HORDE] = 94427 },	-- Tyrannical Gladiator's Armwraps of Accuracy
                { 717, [ATLASLOOT_IT_ALLIANCE] = 91335, [ATLASLOOT_IT_HORDE] = 94424 },	-- Tyrannical Gladiator's Waistband of Accuracy
                { 718, [ATLASLOOT_IT_ALLIANCE] = 91337, [ATLASLOOT_IT_HORDE] = 94374 },	-- Tyrannical Gladiator's Boots of Cruelty
                { 720, [ATLASLOOT_IT_ALLIANCE] = 91339, [ATLASLOOT_IT_HORDE] = 94470 },	-- Tyrannical Gladiator's Armwraps of Alacrity
                { 721, [ATLASLOOT_IT_ALLIANCE] = 91242, [ATLASLOOT_IT_HORDE] = 94360 },	-- Tyrannical Gladiator's Waistband of Cruelty
                { 722, [ATLASLOOT_IT_ALLIANCE] = 91244, [ATLASLOOT_IT_HORDE] = 94432 },	-- Tyrannical Gladiator's Boots of Alacrity
                { 724, [ATLASLOOT_IT_ALLIANCE] = 91188, [ATLASLOOT_IT_HORDE] = 94439 },	-- Tyrannical Gladiator's Bindings of Prowess
                { 725, [ATLASLOOT_IT_ALLIANCE] = 91184, [ATLASLOOT_IT_HORDE] = 94410 },	-- Tyrannical Gladiator's Belt of Cruelty
                { 726, [ATLASLOOT_IT_ALLIANCE] = 91186, [ATLASLOOT_IT_HORDE] = 94344 },	-- Tyrannical Gladiator's Footguards of Alacrity
                { 728, [ATLASLOOT_IT_ALLIANCE] = 91171, [ATLASLOOT_IT_HORDE] = 94407 },	-- Tyrannical Gladiator's Bindings of Meditation
                { 729, [ATLASLOOT_IT_ALLIANCE] = 91167, [ATLASLOOT_IT_HORDE] = 94491 },	-- Tyrannical Gladiator's Belt of Meditation
                { 730, [ATLASLOOT_IT_ALLIANCE] = 91169, [ATLASLOOT_IT_HORDE] = 94476 },	-- Tyrannical Gladiator's Footguards of Meditation
                { 801, [ATLASLOOT_IT_ALLIANCE] = 91357, [ATLASLOOT_IT_HORDE] = 94337 },	-- Tyrannical Gladiator's Armbands of Meditation
                { 802, [ATLASLOOT_IT_ALLIANCE] = 91350, [ATLASLOOT_IT_HORDE] = 94382 },	-- Tyrannical Gladiator's Waistguard of Meditation
                { 803, [ATLASLOOT_IT_ALLIANCE] = 91354, [ATLASLOOT_IT_HORDE] = 94336 },	-- Tyrannical Gladiator's Footguards of Meditation
                { 805, [ATLASLOOT_IT_ALLIANCE] = 91356, [ATLASLOOT_IT_HORDE] = 94379 },	-- Tyrannical Gladiator's Armbands of Prowess
                { 806, [ATLASLOOT_IT_ALLIANCE] = 91378, [ATLASLOOT_IT_HORDE] = 94393 },	-- Tyrannical Gladiator's Waistguard of Cruelty
                { 807, [ATLASLOOT_IT_ALLIANCE] = 91352, [ATLASLOOT_IT_HORDE] = 94378 },	-- Tyrannical Gladiator's Footguards of Alacrity
                { 809, [ATLASLOOT_IT_ALLIANCE] = 91220, [ATLASLOOT_IT_HORDE] = 94404 },	-- Tyrannical Gladiator's Wristguards of Alacrity
                { 810, [ATLASLOOT_IT_ALLIANCE] = 91212, [ATLASLOOT_IT_HORDE] = 94330 },	-- Tyrannical Gladiator's Links of Cruelty
                { 811, [ATLASLOOT_IT_ALLIANCE] = 91218, [ATLASLOOT_IT_HORDE] = 94359 },	-- Tyrannical Gladiator's Sabatons of Alacrity
                { 813, [ATLASLOOT_IT_ALLIANCE] = 91221, [ATLASLOOT_IT_HORDE] = 94469 },	-- Tyrannical Gladiator's Wristguards of Accuracy
                { 814, [ATLASLOOT_IT_ALLIANCE] = 91214, [ATLASLOOT_IT_HORDE] = 94358 },	-- Tyrannical Gladiator's Links of Accuracy
                { 815, [ATLASLOOT_IT_ALLIANCE] = 91216, [ATLASLOOT_IT_HORDE] = 94445 },	-- Tyrannical Gladiator's Sabatons of Cruelty
                { 816, [ATLASLOOT_IT_ALLIANCE] = 91286, [ATLASLOOT_IT_HORDE] = 94481 },	-- Tyrannical Gladiator's Bracers of Meditation
                { 817, [ATLASLOOT_IT_ALLIANCE] = 91279, [ATLASLOOT_IT_HORDE] = 94464 },	-- Tyrannical Gladiator's Clasp of Meditation
                { 818, [ATLASLOOT_IT_ALLIANCE] = 91283, [ATLASLOOT_IT_HORDE] = 94352 },	-- Tyrannical Gladiator's Greaves of Meditation
                { 820, [ATLASLOOT_IT_ALLIANCE] = 91305, [ATLASLOOT_IT_HORDE] = 94418 },	-- Tyrannical Gladiator's Armplates of Proficiency
                { 821, [ATLASLOOT_IT_ALLIANCE] = 91297, [ATLASLOOT_IT_HORDE] = 94353 },	-- Tyrannical Gladiator's Girdle of Accuracy
                { 822, [ATLASLOOT_IT_ALLIANCE] = 91301, [ATLASLOOT_IT_HORDE] = 94414 },	-- Tyrannical Gladiator's Warboots of Cruelty
                { 824, [ATLASLOOT_IT_ALLIANCE] = 91285, [ATLASLOOT_IT_HORDE] = 94411 },	-- Tyrannical Gladiator's Bracers of Prowess
                { 825, [ATLASLOOT_IT_ALLIANCE] = 91277, [ATLASLOOT_IT_HORDE] = 94480 },	-- Tyrannical Gladiator's Clasp of Cruelty
                { 826, [ATLASLOOT_IT_ALLIANCE] = 91281, [ATLASLOOT_IT_HORDE] = 94351 },	-- Tyrannical Gladiator's Greaves of Alacrity
                { 828, [ATLASLOOT_IT_ALLIANCE] = 91306, [ATLASLOOT_IT_HORDE] = 94487 },	-- Tyrannical Gladiator's Armplates of Alacrity
                { 829, [ATLASLOOT_IT_ALLIANCE] = 91299, [ATLASLOOT_IT_HORDE] = 94440 },	-- Tyrannical Gladiator's Girdle of Prowess
                { 830, [ATLASLOOT_IT_ALLIANCE] = 91303, [ATLASLOOT_IT_HORDE] = 94461 },	-- Tyrannical Gladiator's Warboots of Alacrity
                { 901, [ATLASLOOT_IT_ALLIANCE] = 91100, [ATLASLOOT_IT_HORDE] = 94421 },	-- Tyrannical Gladiator's Cape of Cruelty
                { 902, [ATLASLOOT_IT_ALLIANCE] = 91101, [ATLASLOOT_IT_HORDE] = 94355 },	-- Tyrannical Gladiator's Cape of Prowess
                { 903, [ATLASLOOT_IT_ALLIANCE] = 91411, [ATLASLOOT_IT_HORDE] = 94485 },	-- Tyrannical Gladiator's Cloak of Alacrity
                { 904, [ATLASLOOT_IT_ALLIANCE] = 91412, [ATLASLOOT_IT_HORDE] = 94486 },	-- Tyrannical Gladiator's Cloak of Prowess
                { 905, [ATLASLOOT_IT_ALLIANCE] = 91124, [ATLASLOOT_IT_HORDE] = 94383 },	-- Tyrannical Gladiator's Drape of Cruelty
                { 906, [ATLASLOOT_IT_ALLIANCE] = 91126, [ATLASLOOT_IT_HORDE] = 94472 },	-- Tyrannical Gladiator's Drape of Meditation
                { 907, [ATLASLOOT_IT_ALLIANCE] = 91125, [ATLASLOOT_IT_HORDE] = 94488 },	-- Tyrannical Gladiator's Drape of Prowess
                { 909, [ATLASLOOT_IT_ALLIANCE] = 91414, [ATLASLOOT_IT_HORDE] = 94354 },	-- Tyrannical Gladiator's Choker of Accuracy
                { 910, [ATLASLOOT_IT_ALLIANCE] = 91413, [ATLASLOOT_IT_HORDE] = 94465 },	-- Tyrannical Gladiator's Choker of Proficiency
                { 911, [ATLASLOOT_IT_ALLIANCE] = 91102, [ATLASLOOT_IT_HORDE] = 94394 },	-- Tyrannical Gladiator's Necklace of Proficiency
                { 912, [ATLASLOOT_IT_ALLIANCE] = 91103, [ATLASLOOT_IT_HORDE] = 94395 },	-- Tyrannical Gladiator's Necklace of Prowess
                { 913, [ATLASLOOT_IT_ALLIANCE] = 91136, [ATLASLOOT_IT_HORDE] = 94473 },	-- Tyrannical Gladiator's Pendant of Alacrity
                { 914, [ATLASLOOT_IT_ALLIANCE] = 91135, [ATLASLOOT_IT_HORDE] = 94489 },	-- Tyrannical Gladiator's Pendant of Cruelty
                { 915, [ATLASLOOT_IT_ALLIANCE] = 91137, [ATLASLOOT_IT_HORDE] = 94452 },	-- Tyrannical Gladiator's Pendant of Meditation
                { 916, [ATLASLOOT_IT_ALLIANCE] = 91139, [ATLASLOOT_IT_HORDE] = 94363 },	-- Tyrannical Gladiator's Band of Accuracy
                { 917, [ATLASLOOT_IT_ALLIANCE] = 91138, [ATLASLOOT_IT_HORDE] = 94390 },	-- Tyrannical Gladiator's Band of Cruelty
                { 918, [ATLASLOOT_IT_ALLIANCE] = 91140, [ATLASLOOT_IT_HORDE] = 94474 },	-- Tyrannical Gladiator's Band of Meditation
                { 919, [ATLASLOOT_IT_ALLIANCE] = 91106, [ATLASLOOT_IT_HORDE] = 94399 },	-- Tyrannical Gladiator's Ring of Accuracy
                { 920, [ATLASLOOT_IT_ALLIANCE] = 91105, [ATLASLOOT_IT_HORDE] = 94357 },	-- Tyrannical Gladiator's Ring of Cruelty
                { 921, [ATLASLOOT_IT_ALLIANCE] = 91417, [ATLASLOOT_IT_HORDE] = 94462 },	-- Tyrannical Gladiator's Signet of Accuracy
                { 922, [ATLASLOOT_IT_ALLIANCE] = 91416, [ATLASLOOT_IT_HORDE] = 94417 },	-- Tyrannical Gladiator's Signet of Cruelty
                { 924, 95057 },	-- Reins of the Thundering Cobalt Cloud Serpent
                { 925, 95602, [ATLASLOOT_IT_FILTERIGNORE] = true },	-- Stormtouched Cache
                { 927, "ac8028" },
            },
        },
        {	--Oondasta
            EncounterJournalID = 826,
            ContentPhaseMoP = 3,
            [NORMAL_DIFF] = {
                { 1, 95182 },	-- Robes of Zalmoxes
                { 2, 95183 },	-- Waistband of Elder Falcarius
                { 3, 95194 },	-- Gloves of Tyranomancy
                { 4, 95193 },	-- Gloves of Varsoon the Greater
                { 5, 95184 },	-- Girdle of Dimorphodontics
                { 6, 95185 },	-- Terrorful Weave
                { 8, 95147 },	-- Fancifully Frilled Tunic
                { 9, 95148 },	-- Vest of the Bordomorono
                { 10, 95196 },	-- Gloves of Gastric Rumbling
                { 11, 95195 },	-- Gloves of Unliving Fossil
                { 12, 95186 },	-- Belt of Crushed Dreams
                { 13, 95187 },	-- Girdle of the Derrodoccus
                { 16, 95149 },	-- Gorgoraptor Scale Chest
                { 17, 95150 },	-- Mail of the Mosschopper
                { 18, 95200 },	-- Orndo Mando's Gloves
                { 19, 95197 },	-- Therapsid Scale Gloves
                { 20, 95188 },	-- Belt of the Arch Avimimus
                { 21, 95189 },	-- Belt of the Dying Diemetradon
                { 23, "ac8123" },
                { 101, 95152 },	-- Breastplate of the Iguanocolossus
                { 102, 95151 },	-- Scorched Spiritfire Drape
                { 103, 95153 },	-- Tyrant King Battleplate
                { 104, 95199 },	-- Carnotaur Battlegloves
                { 105, 95201 },	-- Skullsmashing Gauntlets
                { 106, 95198 },	-- Vulcanodon Gauntlets
                { 107, 95192 },	-- Belt of the Tyrannotitan
                { 108, 95191 },	-- Voolar's Bloodied Belt
                { 109, 95190 },	-- Waistband of Furious Stomping
                { 111, 94228 },	-- Reins of the Cobalt Primordial Direhorn
                { 112, 95601, [ATLASLOOT_IT_FILTERIGNORE] = true },	-- Shiny Pile of Refuse
                { 113, 94295, [ATLASLOOT_IT_FILTERIGNORE] = true },	-- Primal Egg
                { 114, 94288, [ATLASLOOT_IT_FILTERIGNORE] = true },	-- Giant Dinosaur Bone
                { 116, 95181 },	-- Amulet of the Titanorex
                { 117, 95177 },	-- Choker of Stygimolochy
                { 118, 95178 },	-- Lootraptor's Amulet
                { 119, 95179 },	-- Necklace of the Hazillosaurus
                { 120, 95180 },	-- Overcompensating Chain of the Alpha Male
                { 122, 95165 },	-- Achillobator Ring
                { 123, 95164 },	-- Eye of Oondasta
                { 124, 95166 },	-- Forzarra's Last Meal
                { 125, 95167 },	-- Ring of King Kangrom
                { 126, 95163 },	-- Ring of Shamuru
            },
        },
        {	--Ordos
            EncounterJournalID = 861,
            ContentPhaseMoP = 5,
            [NORMAL_DIFF] = {
                { 1, 105810 },	-- Buc-Zakai Burning Hood
                { 2, 105808 },	-- Damien's Ice-Vein Mask
                { 3, 105795 },	-- Bo He Me's Deathwind Mantle
                { 4, 105797 },	-- Shay-Nii's Popping Shoulderpads
                { 5, 105774 },	-- Catia's Flowing Robes
                { 6, 105773 },	-- Ulmaas' Robes of Crushing Magma
                { 7, 105789 },	-- Bjam's Blasting Bracers
                { 8, 105788 },	-- Paululum's Doodled Wraps
                { 9, 105778 },	-- Derevka's Gleaming Girdle
                { 10, 105781 },	-- Venruki's Venerable Sash
                { 11, 105757 },	-- Shipley's Shady Silks
                { 16, 105806 },	-- Circlet of the Panser
                { 17, 105803 },	-- Stickney's Grey-Shade Hood
                { 18, 105798 },	-- Flame Healer's Shoulderguards
                { 19, 105801 },	-- Spaulders of Dominating Dreams
                { 20, 105768 },	-- Pamela's Muuscat Wrap
                { 21, 105770 },	-- Zoo-Per's Superior Chestguard
                { 22, 105793 },	-- Bracers of Simmering Fury
                { 23, 105787 },	-- Burnseal Bracers
                { 24, 105782 },	-- Belt of Glowing Embers
                { 25, 105780 },	-- Windflame Girdle
                { 26, 105758 },	-- Arielle's Ancient Legwraps
                { 27, 105760 },	-- Hamlet's Wind-Whipped Leggings
                { 29, "ac8533" },
                { 101, 105809 },	-- Crest of Burning Deeds
                { 102, 105811 },	-- Olivia's Graceful Gaze
                { 103, 105800 },	-- Firearrow Shoulderpads
                { 104, 105799 },	-- Fleshsmoke Chain Shoulders
                { 105, 105771 },	-- Chestguard of Pyrrhic Immolation
                { 106, 105772 },	-- Moonhee's Mean Vest
                { 107, 105792 },	-- Bowflight Wristguard
                { 108, 105790 },	-- Firetotem Bracers
                { 109, 105784 },	-- Binkenstein's Burnished Belt
                { 110, 105779 },	-- Light Kindler Waistguard
                { 111, 105754 },	-- Desirae's Dashing Leggings
                { 112, 105755 },	-- Moshne's Keen Kilt
                { 116, 105804 },	-- Aladya's Spiritfire Greathelm
                { 117, 105805 },	-- Dominik's Casque of Raging Flame
                { 118, 105807 },	-- Magdalena's Murderous Crown
                { 119, 105796 },	-- Rossi's Rosin-Soaked Shoulderplates
                { 120, 105794 },	-- Starry Spaulders of Durability
                { 121, 105802 },	-- Yaungol Deathcult Shoulderguards
                { 122, 105775 },	-- Gleaming Eye Spellplate
                { 123, 105767 },	-- Hoodrych's Bloodied Chestplate
                { 124, 105769 },	-- Omegal's Crushing Carapace
                { 125, 105791 },	-- Bracers of Unquestioning Belief
                { 126, 105786 },	-- Ordosian Cultist's Bracers
                { 127, 105785 },	-- Vanguard's Burly Bracers
                { 201, 105776 },	-- Belt of the Burning Soul
                { 202, 105783 },	-- Greatbelt of the Crendor
                { 203, 105777 },	-- Remnar's Ruinous Girdle
                { 204, 105759 },	-- Magmaplates of Jian Wu Xi Feng
                { 205, 105761 },	-- Partik's Purified Legplates
                { 206, 105756 },	-- Poxleitner's Leggings of Lights
                { 208, 104273, [ATLASLOOT_IT_FILTERIGNORE] = true },	-- Flame-Scarred Cache of Offerings
                { 216, 105766 },	-- Anafielle's Spiked Choker
                { 217, 105765 },	-- Bladeforger Necklace
                { 218, 105763 },	-- Penate's Perilous Pendant
                { 219, 105764 },	-- Rising New Moon Talisman
                { 220, 105762 },	-- Smoldering Eye
            },
        },
        {	--TheAugustCelestials
            EncounterJournalID = 857,
            ContentPhaseMoP = 5,
            name = ALIL["The August Celestials"],
            [NORMAL_DIFF] = {
                { 1, "ICON_spell_nature_starfall", nil, ALIL["DRUID"], ALIL["Balance"] },
                { 2, 99174 },	-- Gloves of the Shattered Vale
                { 3, 99176 },	-- Leggings of the Shattered Vale
                { 5, "ICON_ability_druid_catform", nil, ALIL["DRUID"], ALIL["Feral"] },
                { 6, 99181 },	-- Grips of the Shattered Vale
                { 7, 99183 },	-- Legguards of the Shattered Vale
                { 9, "ICON_spell_nature_healingtouch", nil, ALIL["DRUID"], ALIL["Restoration"] },
                { 10, 99185 },	-- Handwraps of the Shattered Vale
                { 11, 99171 },	-- Legwraps of the Shattered Vale
                { 13, "ICON_ability_racial_bearform", nil, ALIL["DRUID"], ALIL["Guardian"] },
                { 14, 99163 },	-- Handguards of the Shattered Vale
                { 15, 99165 },	-- Breeches of the Shattered Vale
                { 16, "ICON_spell_nature_starfall", nil, ALIL["DRUID"], ALIL["Balance"] },
                { 17, [ATLASLOOT_IT_ALLIANCE] = 102696, [ATLASLOOT_IT_HORDE] = 103398 },	-- Prideful Gladiator's Wyrmhide Gloves
                { 18, [ATLASLOOT_IT_ALLIANCE] = 102767, [ATLASLOOT_IT_HORDE] = 103400 },	-- Prideful Gladiator's Wyrmhide Legguards
                { 20, "ICON_ability_druid_catform", nil, ALIL["DRUID"], ALIL["Feral"] },
                { 21, [ATLASLOOT_IT_ALLIANCE] = 102739, [ATLASLOOT_IT_HORDE] = 103381 },	-- Prideful Gladiator's Dragonhide Gloves
                { 22, [ATLASLOOT_IT_ALLIANCE] = 102654, [ATLASLOOT_IT_HORDE] = 103383 },	-- Prideful Gladiator's Dragonhide Legguards
                { 24, "ICON_spell_nature_healingtouch", nil, ALIL["DRUID"], ALIL["Restoration"] },
                { 25, [ATLASLOOT_IT_ALLIANCE] = 102657, [ATLASLOOT_IT_HORDE] = 103389 },	-- Prideful Gladiator's Kodohide Gloves
                { 26, [ATLASLOOT_IT_ALLIANCE] = 102761, [ATLASLOOT_IT_HORDE] = 103391 },	-- Prideful Gladiator's Kodohide Legguards
                { 101, "ICON_inv_weapon_bow_07", nil, ALIL["HUNTER"], nil },
                { 102, 99168 },	-- Gloves of the Unblinking Vigil
                { 103, 99158 },	-- Legguards of the Unblinking Vigil
                { 105, "ICON_inv_staff_13", nil, ALIL["MAGE"], nil },
                { 106, 99160 },	-- Chronomancer Gloves
                { 107, 99162 },	-- Chronomancer Leggings
                { 109, "ICON_inv_throwingknife_04", nil, ALIL["ROGUE"], nil },
                { 110, 99113 },	-- Gloves of the Barbed Assassin
                { 111, 99115 },	-- Legguards of the Barbed Assassin
                { 113, "ICON_spell_nature_drowsy", nil, ALIL["WARLOCK"], nil },
                { 114, 99096 },	-- Gloves of the Horned Nightmare
                { 115, 99098 },	-- Leggings of the Horned Nightmare
                { 116, "ICON_inv_weapon_bow_07", nil, ALIL["HUNTER"], nil },
                { 117, [ATLASLOOT_IT_ALLIANCE] = 102737, [ATLASLOOT_IT_HORDE] = 103417 },	-- Prideful Gladiator's Chain Gauntlets
                { 118, [ATLASLOOT_IT_ALLIANCE] = 102670, [ATLASLOOT_IT_HORDE] = 103419 },	-- Prideful Gladiator's Chain Leggings
                { 120, "ICON_inv_staff_13", nil, ALIL["MAGE"], nil },
                { 121, [ATLASLOOT_IT_ALLIANCE] = 102735, [ATLASLOOT_IT_HORDE] = 103421 },	-- Prideful Gladiator's Silk Handguards
                { 122, [ATLASLOOT_IT_ALLIANCE] = 102648, [ATLASLOOT_IT_HORDE] = 103423 },	-- Prideful Gladiator's Silk Trousers
                { 124, "ICON_inv_throwingknife_04", nil, ALIL["ROGUE"], nil },
                { 125, [ATLASLOOT_IT_ALLIANCE] = 102663, [ATLASLOOT_IT_HORDE] = 103476 },	-- Prideful Gladiator's Leather Gloves
                { 126, [ATLASLOOT_IT_ALLIANCE] = 102730, [ATLASLOOT_IT_HORDE] = 103478 },	-- Prideful Gladiator's Leather Legguards
                { 128, "ICON_spell_nature_drowsy", nil, ALIL["WARLOCK"], nil },
                { 129, [ATLASLOOT_IT_ALLIANCE] = 102725, [ATLASLOOT_IT_HORDE] = 103520 },	-- Prideful Gladiator's Felweave Handguards
                { 130, [ATLASLOOT_IT_ALLIANCE] = 102755, [ATLASLOOT_IT_HORDE] = 103522 },	-- Prideful Gladiator's Felweave Trousers
                { 201, "ICON_spell_monk_mistweaver_spec", nil, ALIL["MONK"], ALIL["Mistweaver"] },
                { 202, 99147 },	-- Handwraps of Seven Sacred Seals
                { 203, 99149 },	-- Legwraps of Seven Sacred Seals
                { 205, "ICON_spell_monk_windwalker_spec", nil, ALIL["MONK"], ALIL["Windwalker"] },
                { 206, 99155 },	-- Grips of Seven Sacred Seals
                { 207, 99145 },	-- Leggings of Seven Sacred Seals
                { 209, "ICON_spell_monk_brewmaster_spec", nil, ALIL["MONK"], ALIL["Brewmaster"] },
                { 210, 99141 },	-- Gauntlets of Seven Sacred Seals
                { 211, 99143 },	-- Legguards of Seven Sacred Seals
                { 216, "ICON_spell_monk_mistweaver_spec", nil, ALIL["MONK"], ALIL["Mistweaver"] },
                { 217, [ATLASLOOT_IT_ALLIANCE] = 102627, [ATLASLOOT_IT_HORDE] = 103434 },	-- Prideful Gladiator's Copperskin Gloves
                { 218, [ATLASLOOT_IT_ALLIANCE] = 102762, [ATLASLOOT_IT_HORDE] = 103436 },	-- Prideful Gladiator's Copperskin Legguards
                { 220, "ICON_spell_monk_windwalker_spec", nil, ALIL["MONK"], ALIL["Windwalker"] },
                { 221, [ATLASLOOT_IT_ALLIANCE] = 102675, [ATLASLOOT_IT_HORDE] = 103429 },	-- Prideful Gladiator's Ironskin Gloves
                { 222, [ATLASLOOT_IT_ALLIANCE] = 102656, [ATLASLOOT_IT_HORDE] = 103431 },	-- Prideful Gladiator's Ironskin Legguards
                { 301, "ICON_Spell_Holy_HolyBolt", nil, ALIL["PALADIN"], ALIL["Holy"] },
                { 302, 99134 },	-- Gloves of Winged Triumph
                { 303, 99124 },	-- Greaves of Winged Triumph
                { 305, "ICON_Spell_Holy_AuraOfLight", nil, ALIL["PALADIN"], ALIL["Retribution"] },
                { 306, 99137 },	-- Gauntlets of Winged Triumph
                { 307, 99139 },	-- Legplates of Winged Triumph
                { 309, "ICON_spell_holy_devotionaura", nil, ALIL["PALADIN"], ALIL["Protection"] },
                { 310, 99127 },	-- Handguards of Winged Triumph
                { 311, 99129 },	-- Legguards of Winged Triumph
                { 316, "ICON_Spell_Holy_HolyBolt", nil, ALIL["PALADIN"], ALIL["Holy"] },
                { 317, [ATLASLOOT_IT_ALLIANCE] = 102722, [ATLASLOOT_IT_HORDE] = 103451 },	-- Prideful Gladiator's Ornamented Gloves
                { 318, [ATLASLOOT_IT_ALLIANCE] = 102768, [ATLASLOOT_IT_HORDE] = 103453 },	-- Prideful Gladiator's Ornamented Legplates
                { 320, "ICON_Spell_Holy_AuraOfLight", nil, ALIL["PALADIN"], ALIL["Retribution"] },
                { 321, [ATLASLOOT_IT_ALLIANCE] = 102630, [ATLASLOOT_IT_HORDE] = 103440 },	-- Prideful Gladiator's Scaled Gauntlets
                { 322, [ATLASLOOT_IT_ALLIANCE] = 102780, [ATLASLOOT_IT_HORDE] = 103442 },	-- Prideful Gladiator's Scaled Legguards
                { 401, "ICON_spell_holy_guardianspirit", nil, ALIL["PRIEST"], ALIL["Discipline"] .. " / " .. ALIL["Holy"] },
                { 402, 99131 },	-- Handwraps of the Ternion Glory
                { 403, 99118 },	-- Legwraps of the Ternion Glory
                { 405, "ICON_spell_shadow_shadowwordpain", nil, ALIL["PRIEST"], ALIL["Shadow"] },
                { 406, 99121 },	-- Gloves of the Ternion Glory
                { 407, 99123 },	-- Leggings of the Ternion Glory
                { 416, "ICON_spell_holy_guardianspirit", nil, ALIL["PRIEST"], ALIL["Discipline"] .. " / " .. ALIL["Holy"] },
                { 417, [ATLASLOOT_IT_ALLIANCE] = 102615, [ATLASLOOT_IT_HORDE] = 103462 },	-- Prideful Gladiator's Mooncloth Gloves
                { 418, [ATLASLOOT_IT_ALLIANCE] = 102704, [ATLASLOOT_IT_HORDE] = 103464 },	-- Prideful Gladiator's Mooncloth Leggings
                { 420, "ICON_spell_shadow_shadowwordpain", nil, ALIL["PRIEST"], ALIL["Shadow"] },
                { 421, [ATLASLOOT_IT_ALLIANCE] = 102707, [ATLASLOOT_IT_HORDE] = 103467 },	-- Prideful Gladiator's Satin Gloves
                { 422, [ATLASLOOT_IT_ALLIANCE] = 102621, [ATLASLOOT_IT_HORDE] = 103469 },	-- Prideful Gladiator's Satin Leggings
                { 501, "ICON_Spell_Nature_Lightning", nil, ALIL["SHAMAN"], ALIL["Elemental"] },
                { 502, 99092 },	-- Gloves of Celestial Harmony
                { 503, 99094 },	-- Kilt of Celestial Harmony
                { 505, "ICON_spell_nature_lightningshield", nil, ALIL["SHAMAN"], ALIL["Enhancement"] },
                { 506, 99102 },	-- Grips of Celestial Harmony
                { 507, 99104 },	-- Legguards of Celestial Harmony
                { 509, "ICON_spell_nature_magicimmunity", nil, ALIL["SHAMAN"], ALIL["Restoration"] },
                { 510, 99108 },	-- Handwraps of Celestial Harmony
                { 511, 99099 },	-- Legwraps of Celestial Harmony
                { 516, "ICON_Spell_Nature_Lightning", nil, ALIL["SHAMAN"], ALIL["Elemental"] },
                { 517, [ATLASLOOT_IT_ALLIANCE] = 102692, [ATLASLOOT_IT_HORDE] = 103497 },	-- Prideful Gladiator's Mail Gauntlets
                { 518, [ATLASLOOT_IT_ALLIANCE] = 102781, [ATLASLOOT_IT_HORDE] = 103499 },	-- Prideful Gladiator's Mail Leggings
                { 520, "ICON_spell_nature_lightningshield", nil, ALIL["SHAMAN"], ALIL["Enhancement"] },
                { 521, [ATLASLOOT_IT_ALLIANCE] = 102742, [ATLASLOOT_IT_HORDE] = 103491 },	-- Prideful Gladiator's Linked Gauntlets
                { 522, [ATLASLOOT_IT_ALLIANCE] = 102778, [ATLASLOOT_IT_HORDE] = 103493 },	-- Prideful Gladiator's Linked Leggings
                { 524, "ICON_spell_nature_magicimmunity", nil, ALIL["SHAMAN"], ALIL["Restoration"] },
                { 525, [ATLASLOOT_IT_ALLIANCE] = 102774, [ATLASLOOT_IT_HORDE] = 103486 },	-- Prideful Gladiator's Ringmail Gauntlets
                { 526, [ATLASLOOT_IT_ALLIANCE] = 102719, [ATLASLOOT_IT_HORDE] = 103488 },	-- Prideful Gladiator's Ringmail Leggings
                { 601, "ICON_spell_deathknight_frostpresence", nil, ALIL["DEATHKNIGHT"], ALIL["Frost"] .. " / " .. ALIL["Unholy"] },
                { 602, 99193 },	-- Gauntlets of Cyclopean Dread
                { 603, 99186 },	-- Greaves of Cyclopean Dread
                { 605, "ICON_spell_deathknight_bloodpresence", nil, ALIL["DEATHKNIGHT"], ALIL["Blood"] },
                { 606, 99189 },	-- Handguards of Cyclopean Dread
                { 607, 99191 },	-- Legguards of Cyclopean Dread
                { 609, "ICON_ability_warrior_innerrage", nil, ALIL["WARRIOR"], ALIL["Arms"] .. " / " .. ALIL["Fury"] },
                { 610, 99198 },	-- Gauntlets of the Prehistoric Marauder
                { 611, 99199 },	-- Legplates of the Prehistoric Marauder
                { 613, "ICON_ability_warrior_defensivestance", nil, ALIL["WARRIOR"], ALIL["Protection"] },
                { 614, 99202 },	-- Handguards of the Prehistoric Marauder
                { 615, 99195 },	-- Legguards of the Prehistoric Marauder
                { 616, "ICON_Spell_deathknight_classicon", nil, ALIL["DEATHKNIGHT"], nil },
                { 617, [ATLASLOOT_IT_ALLIANCE] = 103005, [ATLASLOOT_IT_HORDE] = 103377 },	-- Prideful Gladiator's Dreadplate Gauntlets
                { 618, [ATLASLOOT_IT_ALLIANCE] = 102651, [ATLASLOOT_IT_HORDE] = 103379 },	-- Prideful Gladiator's Dreadplate Legguards
                { 624, "ICON_inv_sword_27", nil, ALIL["WARRIOR"], nil },
                { 625, [ATLASLOOT_IT_ALLIANCE] = 102618, [ATLASLOOT_IT_HORDE] = 103526 },	-- Prideful Gladiator's Plate Gauntlets
                { 626, [ATLASLOOT_IT_ALLIANCE] = 102732, [ATLASLOOT_IT_HORDE] = 103528 },	-- Prideful Gladiator's Plate Legguards
                { 701, [ATLASLOOT_IT_ALLIANCE] = 102687, [ATLASLOOT_IT_HORDE] = 103357 },	-- Prideful Gladiator's Cuffs of Accuracy
                { 702, [ATLASLOOT_IT_ALLIANCE] = 102662, [ATLASLOOT_IT_HORDE] = 103352 },	-- Prideful Gladiator's Cord of Accuracy
                { 703, [ATLASLOOT_IT_ALLIANCE] = 102620, [ATLASLOOT_IT_HORDE] = 103355 },	-- Prideful Gladiator's Treads of Alacrity
                { 705, [ATLASLOOT_IT_ALLIANCE] = 102666, [ATLASLOOT_IT_HORDE] = 103359 },	-- Prideful Gladiator's Cuffs of Meditation
                { 706, [ATLASLOOT_IT_ALLIANCE] = 102709, [ATLASLOOT_IT_HORDE] = 103353 },	-- Prideful Gladiator's Cord of Meditation
                { 707, [ATLASLOOT_IT_ALLIANCE] = 102752, [ATLASLOOT_IT_HORDE] = 103356 },	-- Prideful Gladiator's Treads of Meditation
                { 709, [ATLASLOOT_IT_ALLIANCE] = 102733, [ATLASLOOT_IT_HORDE] = 103358 },	-- Prideful Gladiator's Cuffs of Prowess
                { 710, [ATLASLOOT_IT_ALLIANCE] = 102684, [ATLASLOOT_IT_HORDE] = 103351 },	-- Prideful Gladiator's Cord of Cruelty
                { 711, [ATLASLOOT_IT_ALLIANCE] = 102686, [ATLASLOOT_IT_HORDE] = 103354 },	-- Prideful Gladiator's Treads of Cruelty
                { 716, [ATLASLOOT_IT_ALLIANCE] = 102711, [ATLASLOOT_IT_HORDE] = 103428 },	-- Prideful Gladiator's Armwraps of Accuracy
                { 717, [ATLASLOOT_IT_ALLIANCE] = 102708, [ATLASLOOT_IT_HORDE] = 103472 },	-- Prideful Gladiator's Waistband of Accuracy
                { 718, [ATLASLOOT_IT_ALLIANCE] = 102660, [ATLASLOOT_IT_HORDE] = 103473 },	-- Prideful Gladiator's Boots of Cruelty
                { 720, [ATLASLOOT_IT_ALLIANCE] = 102754, [ATLASLOOT_IT_HORDE] = 103474 },	-- Prideful Gladiator's Armwraps of Alacrity
                { 721, [ATLASLOOT_IT_ALLIANCE] = 102647, [ATLASLOOT_IT_HORDE] = 103426 },	-- Prideful Gladiator's Waistband of Cruelty
                { 722, [ATLASLOOT_IT_ALLIANCE] = 102716, [ATLASLOOT_IT_HORDE] = 103427 },	-- Prideful Gladiator's Boots of Alacrity
                { 724, [ATLASLOOT_IT_ALLIANCE] = 102723, [ATLASLOOT_IT_HORDE] = 103397 },	-- Prideful Gladiator's Bindings of Prowess
                { 725, [ATLASLOOT_IT_ALLIANCE] = 102694, [ATLASLOOT_IT_HORDE] = 103395 },	-- Prideful Gladiator's Belt of Cruelty
                { 726, [ATLASLOOT_IT_ALLIANCE] = 102631, [ATLASLOOT_IT_HORDE] = 103396 },	-- Prideful Gladiator's Footguards of Alacrity
                { 728, [ATLASLOOT_IT_ALLIANCE] = 102691, [ATLASLOOT_IT_HORDE] = 103388 },	-- Prideful Gladiator's Bindings of Meditation
                { 729, [ATLASLOOT_IT_ALLIANCE] = 102775, [ATLASLOOT_IT_HORDE] = 103386 },	-- Prideful Gladiator's Belt of Meditation
                { 730, [ATLASLOOT_IT_ALLIANCE] = 102760, [ATLASLOOT_IT_HORDE] = 102623 },	-- Prideful Gladiator's Footguards of Meditation
                { 801, [ATLASLOOT_IT_ALLIANCE] = 102624, [ATLASLOOT_IT_HORDE] = 103484 },	-- Prideful Gladiator's Armbands of Meditation
                { 802, [ATLASLOOT_IT_ALLIANCE] = 102668, [ATLASLOOT_IT_HORDE] = 103480 },	-- Prideful Gladiator's Waistguard of Meditation
                { 803, [ATLASLOOT_IT_ALLIANCE] = 102623, [ATLASLOOT_IT_HORDE] = 103482 },	-- Prideful Gladiator's Footguards of Meditation
                { 805, [ATLASLOOT_IT_ALLIANCE] = 102665, [ATLASLOOT_IT_HORDE] = 103483 },	-- Prideful Gladiator's Armbands of Prowess
                { 806, [ATLASLOOT_IT_ALLIANCE] = 102677, [ATLASLOOT_IT_HORDE] = 103495 },	-- Prideful Gladiator's Waistguard of Cruelty
                { 807, [ATLASLOOT_IT_ALLIANCE] = 102664, [ATLASLOOT_IT_HORDE] = 103481 },	-- Prideful Gladiator's Footguards of Alacrity
                { 809, [ATLASLOOT_IT_ALLIANCE] = 102688, [ATLASLOOT_IT_HORDE] = 103414 },	-- Prideful Gladiator's Wristguards of Alacrity
                { 810, [ATLASLOOT_IT_ALLIANCE] = 102617, [ATLASLOOT_IT_HORDE] = 103410 },	-- Prideful Gladiator's Links of Cruelty
                { 811, [ATLASLOOT_IT_ALLIANCE] = 102646, [ATLASLOOT_IT_HORDE] = 103413 },	-- Prideful Gladiator's Sabatons of Alacrity
                { 813, [ATLASLOOT_IT_ALLIANCE] = 102753, [ATLASLOOT_IT_HORDE] = 103415 },	-- Prideful Gladiator's Wristguards of Accuracy
                { 814, [ATLASLOOT_IT_ALLIANCE] = 102645, [ATLASLOOT_IT_HORDE] = 103411 },	-- Prideful Gladiator's Links of Accuracy
                { 815, [ATLASLOOT_IT_ALLIANCE] = 102729, [ATLASLOOT_IT_HORDE] = 103412 },	-- Prideful Gladiator's Sabatons of Cruelty
                { 816, [ATLASLOOT_IT_ALLIANCE] = 102765, [ATLASLOOT_IT_HORDE] = 103449 },	-- Prideful Gladiator's Bracers of Meditation
                { 817, [ATLASLOOT_IT_ALLIANCE] = 102748, [ATLASLOOT_IT_HORDE] = 103445 },	-- Prideful Gladiator's Clasp of Meditation
                { 818, [ATLASLOOT_IT_ALLIANCE] = 102639, [ATLASLOOT_IT_HORDE] = 103447 },	-- Prideful Gladiator's Greaves of Meditation
                { 820, [ATLASLOOT_IT_ALLIANCE] = 102702, [ATLASLOOT_IT_HORDE] = 103459 },	-- Prideful Gladiator's Armplates of Proficiency
                { 821, [ATLASLOOT_IT_ALLIANCE] = 102640, [ATLASLOOT_IT_HORDE] = 103455 },	-- Prideful Gladiator's Girdle of Accuracy
                { 822, [ATLASLOOT_IT_ALLIANCE] = 102698, [ATLASLOOT_IT_HORDE] = 103457 },	-- Prideful Gladiator's Warboots of Cruelty
                { 824, [ATLASLOOT_IT_ALLIANCE] = 102695, [ATLASLOOT_IT_HORDE] = 103448 },	-- Prideful Gladiator's Bracers of Prowess
                { 825, [ATLASLOOT_IT_ALLIANCE] = 102764, [ATLASLOOT_IT_HORDE] = 103444 },	-- Prideful Gladiator's Clasp of Cruelty
                { 826, [ATLASLOOT_IT_ALLIANCE] = 102638, [ATLASLOOT_IT_HORDE] = 103446 },	-- Prideful Gladiator's Greaves of Alacrity
                { 828, [ATLASLOOT_IT_ALLIANCE] = 102771, [ATLASLOOT_IT_HORDE] = 103460 },	-- Prideful Gladiator's Armplates of Alacrity
                { 829, [ATLASLOOT_IT_ALLIANCE] = 102724, [ATLASLOOT_IT_HORDE] = 103456 },	-- Prideful Gladiator's Girdle of Prowess
                { 830, [ATLASLOOT_IT_ALLIANCE] = 102745, [ATLASLOOT_IT_HORDE] = 103458 },	-- Prideful Gladiator's Warboots of Alacrity
                { 901, [ATLASLOOT_IT_ALLIANCE] = 102705, [ATLASLOOT_IT_HORDE] = 103343 },	-- Prideful Gladiator's Cape of Cruelty
                { 902, [ATLASLOOT_IT_ALLIANCE] = 102642, [ATLASLOOT_IT_HORDE] = 103344 },	-- Prideful Gladiator's Cape of Prowess
                { 903, [ATLASLOOT_IT_ALLIANCE] = 102769, [ATLASLOOT_IT_HORDE] = 103512 },	-- Prideful Gladiator's Cloak of Alacrity
                { 904, [ATLASLOOT_IT_ALLIANCE] = 102770, [ATLASLOOT_IT_HORDE] = 103513 },	-- Prideful Gladiator's Cloak of Prowess
                { 905, [ATLASLOOT_IT_ALLIANCE] = 102669, [ATLASLOOT_IT_HORDE] = 103360 },	-- Prideful Gladiator's Drape of Cruelty
                { 906, [ATLASLOOT_IT_ALLIANCE] = 102756, [ATLASLOOT_IT_HORDE] = 103362 },	-- Prideful Gladiator's Drape of Meditation
                { 907, [ATLASLOOT_IT_ALLIANCE] = 102772, [ATLASLOOT_IT_HORDE] = 103361 },	-- Prideful Gladiator's Drape of Prowess
                { 909, [ATLASLOOT_IT_ALLIANCE] = 102641, [ATLASLOOT_IT_HORDE] = 103515 },	-- Prideful Gladiator's Choker of Accuracy
                { 910, [ATLASLOOT_IT_ALLIANCE] = 102749, [ATLASLOOT_IT_HORDE] = 103514 },	-- Prideful Gladiator's Choker of Proficiency
                { 911, [ATLASLOOT_IT_ALLIANCE] = 102678, [ATLASLOOT_IT_HORDE] = 103345 },	-- Prideful Gladiator's Necklace of Proficiency
                { 912, [ATLASLOOT_IT_ALLIANCE] = 102679, [ATLASLOOT_IT_HORDE] = 103346 },	-- Prideful Gladiator's Necklace of Prowess
                { 913, [ATLASLOOT_IT_ALLIANCE] = 102757, [ATLASLOOT_IT_HORDE] = 103368 },	-- Prideful Gladiator's Pendant of Alacrity
                { 914, [ATLASLOOT_IT_ALLIANCE] = 102773, [ATLASLOOT_IT_HORDE] = 103367 },	-- Prideful Gladiator's Pendant of Cruelty
                { 915, [ATLASLOOT_IT_ALLIANCE] = 102736, [ATLASLOOT_IT_HORDE] = 103369 },	-- Prideful Gladiator's Pendant of Meditation
                { 916, [ATLASLOOT_IT_ALLIANCE] = 102649, [ATLASLOOT_IT_HORDE] = 103371 },	-- Prideful Gladiator's Band of Accuracy
                { 917, [ATLASLOOT_IT_ALLIANCE] = 102674, [ATLASLOOT_IT_HORDE] = 103370 },	-- Prideful Gladiator's Band of Cruelty
                { 918, [ATLASLOOT_IT_ALLIANCE] = 102758, [ATLASLOOT_IT_HORDE] = 103372 },	-- Prideful Gladiator's Band of Meditation
                { 919, [ATLASLOOT_IT_ALLIANCE] = 102683, [ATLASLOOT_IT_HORDE] = 103349 },	-- Prideful Gladiator's Ring of Accuracy
                { 920, [ATLASLOOT_IT_ALLIANCE] = 102644, [ATLASLOOT_IT_HORDE] = 103348 },	-- Prideful Gladiator's Ring of Cruelty
                { 921, [ATLASLOOT_IT_ALLIANCE] = 102746, [ATLASLOOT_IT_HORDE] = 103518 },	-- Prideful Gladiator's Signet of Accuracy
                { 922, [ATLASLOOT_IT_ALLIANCE] = 102701, [ATLASLOOT_IT_HORDE] = 103517 },	-- Prideful Gladiator's Signet of Cruelty
                { 924, 104272, [ATLASLOOT_IT_FILTERIGNORE] = true },	-- Celestial Treasure Box
                { 926, "ac8535" },
            },
        },
        T14_SET,
    }
}

data["MoguShanVaults"] = {
    EncounterJournalID = 317,
    InstanceID = 1008,
    MapID = 6125,
    ContentType = RAID_CONTENT,
    items = {
        {	--MSVTheStoneGuard
            EncounterJournalID = 679,
            [NORMAL_DIFF] = {
                { 1, 85979 },	-- Cape of Three Lanterns
                { 2, 89768 },	-- Claws of Amethyst
                { 3, 89767 },	-- Ruby-Linked Girdle
                { 4, 85978 },	-- Jade Dust Leggings
                { 5, 85977 },	-- Stonebound Cinch
                { 6, 85926 },	-- Stoneflesh Leggings
                { 7, 85976 },	-- Sixteen-Fanged Crown
                { 8, 89766 },	-- Stonefang Chestguard
                { 9, 85923 },	-- Stonemaw Armguards
                { 10, 86134 },	-- Star-Stealer Waistguard
                { 11, 85975 },	-- Heavenly Jade Greatboots
                { 12, 85925 },	-- Jasper Clawfeet
                { 16, 85922 },	-- Beads of the Mogu'shi
                { 18, 85924 },	-- Dagger of the Seven Stars
                { 20, "ac6823" },
            },
            [HEROIC_DIFF] = {
                { 1, 87018 },	-- Cape of Three Lanterns
                { 2, 89931 },	-- Claws of Amethyst
                { 3, 89930 },	-- Ruby-Linked Girdle
                { 4, 87017 },	-- Jade Dust Leggings
                { 5, 87019 },	-- Stonebound Cinch
                { 6, 87013 },	-- Stoneflesh Leggings
                { 7, 87020 },	-- Sixteen-Fanged Crown
                { 8, 89929 },	-- Stonefang Chestguard
                { 9, 87014 },	-- Stonemaw Armguards
                { 10, 87060 },	-- Star-Stealer Waistguard
                { 11, 87021 },	-- Heavenly Jade Greatboots
                { 12, 87015 },	-- Jasper Clawfeet
                { 16, 87016 },	-- Beads of the Mogu'shi
                { 18, 87012 },	-- Dagger of the Seven Stars
                { 20, "ac6719" },
                { 21, "ac6823" },
            },
        },
        {	--MSVFeng
            EncounterJournalID = 689,
            [NORMAL_DIFF] = {
                { 1, 86082 },	-- Arrow Breaking Windcloak
                { 2, 85985 },	-- Cloak of Peacock Feathers
                { 3, 85990 },	-- Imperial Ghostbinder's Robes
                { 4, 85989 },	-- Hood of Cursed Dreams
                { 5, 85982 },	-- Tomb Raider's Girdle
                { 6, 85987 },	-- Chain of Shadow
                { 7, 85980 },	-- Wildfire Worldwalkers
                { 8, 85984 },	-- Nullification Greathelm
                { 9, 85983 },	-- Bracers of Six Oxen
                { 10, 85988 },	-- Legplates of Sagacious Shadows
                { 16, 85986 },	-- Amulet of Seven Curses
                { 17, 89803 },	-- Feng's Ring of Dreams
                { 18, 89802 },	-- Feng's Seal of Binding
                { 20, 89424 },	-- Fan of Fiery Winds
                { 22, "ac6674" },
            },
            [HEROIC_DIFF] = {
                { 1, 87044 },	-- Arrow Breaking Windcloak
                { 2, 87026 },	-- Cloak of Peacock Feathers
                { 3, 87027 },	-- Imperial Ghostbinder's Robes
                { 4, 87029 },	-- Hood of Cursed Dreams
                { 5, 87022 },	-- Tomb Raider's Girdle
                { 6, 87030 },	-- Chain of Shadow
                { 7, 87023 },	-- Wildfire Worldwalkers
                { 8, 87024 },	-- Nullification Greathelm
                { 9, 87025 },	-- Bracers of Six Oxen
                { 10, 87031 },	-- Legplates of Sagacious Shadows
                { 16, 87028 },	-- Amulet of Seven Curses
                { 17, 89933 },	-- Feng's Ring of Dreams
                { 18, 89932 },	-- Feng's Seal of Binding
                { 20, 89425 },	-- Fan of Fiery Winds
                { 22, "ac6720" },
                { 23, "ac6674" },
            },
        },
        {	--MSVGarajal
            EncounterJournalID = 682,
            [NORMAL_DIFF] = {
                { 1, 86041 },	-- Shadowsummoner Spaulders
                { 2, 85997 },	-- Sandals of the Severed Soul
                { 3, 85995 },	-- Netherrealm Shoulderpads
                { 4, 86039 },	-- Spaulders of the Divided Mind
                { 5, 85993 },	-- Fetters of Death
                { 6, 86040 },	-- Leggings of Imprisoned Will
                { 7, 86027 },	-- Bindings of Ancient Spirits
                { 8, 89817 },	-- Bonded Soul Bracers
                { 9, 85992 },	-- Sollerets of Spirit Splitting
                { 16, 85991 },	-- Soulgrasp Choker
                { 17, 86038 },	-- Circuit of the Frail Soul
                { 19, 85994 },	-- Gara'kal, Fist of the Spiritbinder
                { 20, 85996 },	-- Eye of the Ancient Spirit
                { 22, "ac7056" },
            },
            [HEROIC_DIFF] = {
                { 1, 87038 },	-- Shadowsummoner Spaulders
                { 2, 87037 },	-- Sandals of the Severed Soul
                { 3, 87033 },	-- Netherrealm Shoulderpads
                { 4, 87041 },	-- Spaulders of the Divided Mind
                { 5, 87034 },	-- Fetters of Death
                { 6, 87042 },	-- Leggings of Imprisoned Will
                { 7, 87043 },	-- Bindings of Ancient Spirits
                { 8, 89934 },	-- Bonded Soul Bracers
                { 9, 87035 },	-- Sollerets of Spirit Splitting
                { 16, 87036 },	-- Soulgrasp Choker
                { 17, 87040 },	-- Circuit of the Frail Soul
                { 19, 87032 },	-- Gara'kal, Fist of the Spiritbinder
                { 20, 87039 },	-- Eye of the Ancient Spirit
                { 22, "ac6721" },
                { 23, "ac7056" },
            },
        },
        {	--MSVSpiritKings
            EncounterJournalID = 687,
            [NORMAL_DIFF] = {
                { 1, 86082 },	-- Arrow Breaking Windcloak
                { 2, 89819 },	-- Mindshard Drape
                { 3, 86129 },	-- Hood of Blind Eyes
                { 4, 86128 },	-- Undying Shadow Grips
                { 5, 86127 },	-- Bracers of Dark Thoughts
                { 6, 89818 },	-- Bracers of Violent Meditation
                { 7, 86081 },	-- Subetai's Pillaging Leggings
                { 8, 86084 },	-- Meng's Treads of Insanity
                { 9, 86080 },	-- Shoulderguards of the Unflanked
                { 10, 86076 },	-- Breastplate of the Kings' Guard
                { 11, 86086 },	-- Girdle of Delirious Visions
                { 16, 86047 },	-- Amulet of the Hidden Kings
                { 17, 86083 },	-- Zian's Choker of Coalesced Shadow
                { 19, 86071 },	-- Screaming Tiger, Qiang's Unbreakable Polearm
                { 20, 86075 },	-- Steelskin, Qiang's Impervious Shield
                { 22, "ac6687" },
            },
            [HEROIC_DIFF] = {
                { 1, 87044 },	-- Arrow Breaking Windcloak
                { 2, 89936 },	-- Mindshard Drape
                { 3, 87051 },	-- Hood of Blind Eyes
                { 4, 87052 },	-- Undying Shadow Grips
                { 5, 87054 },	-- Bracers of Dark Thoughts
                { 6, 89935 },	-- Bracers of Violent Meditation
                { 7, 87047 },	-- Subetai's Pillaging Leggings
                { 8, 87055 },	-- Meng's Treads of Insanity
                { 9, 87049 },	-- Shoulderguards of the Unflanked
                { 10, 87048 },	-- Breastplate of the Kings' Guard
                { 11, 87056 },	-- Girdle of Delirious Visions
                { 16, 87045 },	-- Amulet of the Hidden Kings
                { 17, 87053 },	-- Zian's Choker of Coalesced Shadow
                { 19, 87046 },	-- Screaming Tiger, Qiang's Unbreakable Polearm
                { 20, 87050 },	-- Steelskin, Qiang's Impervious Shield
                { 22, "ac6722" },
                { 23, "ac6687" },
            },
        },
        {	--MSVElegon
            EncounterJournalID = 726,
            [NORMAL_DIFF] = {
                { 1, 89822 },	-- Galaxyfire Girdle
                { 2, 86139 },	-- Orbital Belt
                { 3, 86136 },	-- Chestguard of Total Annihilation
                { 4, 86138 },	-- Phasewalker Striders
                { 5, 86141 },	-- Shoulders of Empyreal Focus
                { 6, 89821 },	-- Crown of Keening Stars
                { 7, 86135 },	-- Starcrusher Gauntlets
                { 9, 87777, "mount", [ATLASLOOT_IT_FILTERIGNORE] = true },	-- Reins of the Astral Cloud Serpent
                { 16, 89824 },	-- Band of Bursting Novas
                { 17, 86132 },	-- Bottle of Infinite Stars
                { 18, 86133 },	-- Light of the Cosmos
                { 19, 86131 },	-- Vial of Dragon's Blood
                { 21, 86130 },	-- Elegion, the Fanged Crescent
                { 22, 86140 },	-- Starshatter
                { 23, 86137 },	-- Torch of the Celestial Spark
                { 25, "ac6686" },
            },
            [HEROIC_DIFF] = {
                { 1, 89938 },	-- Galaxyfire Girdle
                { 2, 87064 },	-- Orbital Belt
                { 3, 87058 },	-- Chestguard of Total Annihilation
                { 4, 87067 },	-- Phasewalker Striders
                { 5, 87068 },	-- Shoulders of Empyreal Focus
                { 6, 89939 },	-- Crown of Keening Stars
                { 7, 87059 },	-- Starcrusher Gauntlets
                { 9, 87777, [ATLASLOOT_IT_FILTERIGNORE] = true },	-- Reins of the Astral Cloud Serpent
                { 16, 89937 },	-- Band of Bursting Novas
                { 17, 87057 },	-- Bottle of Infinite Stars
                { 18, 87065 },	-- Light of the Cosmos
                { 19, 87063 },	-- Vial of Dragon's Blood
                { 21, 87062 },	-- Elegion, the Fanged Crescent
                { 22, 87061 },	-- Starshatter
                { 23, 87066 },	-- Torch of the Celestial Spark
                { 25, "ac6723" },
                { 26, "ac6686" },
            },
        },
        {	--MSVWilloftheEmperor
            EncounterJournalID = 677,
            [NORMAL_DIFF] = {
                { 1, 86151 },	-- Hood of Focused Energy
                { 2, 86146 },	-- Crown of Opportunistic Strikes
                { 3, 86150 },	-- Magnetized Leggings
                { 4, 89820 },	-- Dreadeye Gaze
                { 5, 89825 },	-- Enameled Grips of Solemnity
                { 6, 87827 },	-- Grips of Terra Cotta
                { 7, 86149 },	-- Spaulders of the Emperor's Rage
                { 8, 89823 },	-- Chestguard of Eternal Vigilance
                { 9, 86145 },	-- Jang-xi's Devastating Legplates
                { 16, 86152 },	-- Worldwaker Cachabon
                { 17, 86144 },	-- Lei Shin's Final Orders
                { 18, 86147 },	-- Qin-xi's Polarizing Seal
                { 20, 86148 },	-- Tihan, Scepter of the Sleeping Emperor
                { 21, 86142 },	-- Fang Kung, Spark of Titans
                { 23, "ac6455" },
            },
            [HEROIC_DIFF] = {
                { 1, 87073 },	-- Hood of Focused Energy
                { 2, 87070 },	-- Crown of Opportunistic Strikes
                { 3, 87077 },	-- Magnetized Leggings
                { 4, 89940 },	-- Dreadeye Gaze
                { 5, 89942 },	-- Enameled Grips of Solemnity
                { 6, 87825 },	-- Grips of Terra Cotta
                { 7, 87078 },	-- Spaulders of the Emperor's Rage
                { 8, 89941 },	-- Chestguard of Eternal Vigilance
                { 9, 87071 },	-- Jang-xi's Devastating Legplates
                { 16, 87076 },	-- Worldwaker Cachabon
                { 17, 87072 },	-- Lei Shin's Final Orders
                { 18, 87075 },	-- Qin-xi's Polarizing Seal
                { 20, 87074 },	-- Tihan, Scepter of the Sleeping Emperor
                { 21, 87069 },	-- Fang Kung, Spark of Titans
                { 23, "ac6724" },
                { 24, "ac6455" },
            },
        },
        {	--MoguShanVaultsTrash
            name = AL["Trash Mobs"],
            ExtraList = true,
            [NORMAL_DIFF] = {
                { 1, 86043 },	-- Jade Bandit Figurine
                { 2, 86042 },	-- Jade Charioteer Figurine
                { 3, 86045 },	-- Jade Courtesan Figurine
                { 4, 86044 },	-- Jade Magistrate Figurine
                { 5, 86046 },	-- Jade Warlord Figurine
            },
        },
        PATTERNS_ILVL_496,
        MOP_RAID1_AC_TABLE,
    }
}

data["HeartofFear"] = {
    EncounterJournalID = 330,
    InstanceID = 1009,
    MapID = 6297,
    ContentType = RAID_CONTENT,
    items = {
        {	--HoFZorlok
            EncounterJournalID = 745,
            [NORMAL_DIFF] = {
                { 1, 86154 },	-- Hisek's Chrysanthemum Cape
                { 2, 86157 },	-- Attenuating Bracers
                { 3, 86161 },	-- Gloves of Grasping Claws
                { 4, 89829 },	-- Scent-Soaked Sandals
                { 5, 86159 },	-- Gauntlets of Undesired Gifts
                { 6, 86153 },	-- Boots of the Still Breath
                { 7, 86160 },	-- Mail of Screaming Secrets
                { 8, 87824 },	-- Zor'lok's Fizzing Chestguard
                { 9, 86158 },	-- Chestplate of the Forbidden Tower
                { 10, 89826 },	-- Warbelt of Sealed Pods
                { 11, 86203 },	-- Articulated Legplates
                { 16, 89827 },	-- Pheromone-Coated Choker
                { 17, 86156 },	-- Fragment of Fear Made Flesh
                { 18, 86155 },	-- Vizier's Ruby Signet
                { 20, "ac6937" },
            },
            [HEROIC_DIFF] = {
                { 1, 86945 },	-- Hisek's Chrysanthemum Cape
                { 2, 86948 },	-- Attenuating Bracers
                { 3, 86947 },	-- Gloves of Grasping Claws
                { 4, 89918 },	-- Scent-Soaked Sandals
                { 5, 86950 },	-- Gauntlets of Undesired Gifts
                { 6, 86943 },	-- Boots of the Still Breath
                { 7, 86951 },	-- Mail of Screaming Secrets
                { 8, 87822 },	-- Zor'lok's Fizzing Chestguard
                { 9, 86952 },	-- Chestplate of the Forbidden Tower
                { 10, 89919 },	-- Warbelt of Sealed Pods
                { 11, 86944 },	-- Articulated Legplates
                { 16, 89917 },	-- Pheromone-Coated Choker
                { 17, 86949 },	-- Fragment of Fear Made Flesh
                { 18, 86946 },	-- Vizier's Ruby Signet
                { 20, "ac6725" },
                { 21, "ac6937" },
            },
        },
        {	--HoFTayak
            EncounterJournalID = 744,
            [NORMAL_DIFF] = {
                { 1, 86169 },	-- Drape of Gathering Clouds
                { 2, 86170 },	-- Twisting Wind Bracers
                { 3, 86167 },	-- Boots of the Blowing Wind
                { 4, 89831 },	-- Hood of Stilled Winds
                { 5, 86163 },	-- Bracers of Unseen Strikes
                { 6, 86168 },	-- Bracers of Tempestuous Fury
                { 7, 90738 },	-- Kaz'tik's Stormseizer Gauntlets
                { 8, 89830 },	-- Sword Dancer's Leggings
                { 9, 89828 },	-- Pauldrons of the Broken Blade
                { 10, 86165 },	-- Windblade Talons
                { 11, 86164 },	-- Waistplate of Overwhelming Assault
                { 16, 86166 },	-- Choker of the Unleashed Storm
                { 17, 86162 },	-- Ring of the Bladed Tempest
                { 19, 86171 },	-- Tornado-Summoning Censer
                { 21, "ac6936" },
            },
            [HEROIC_DIFF] = {
                { 1, 86961 },	-- Drape of Gathering Clouds
                { 2, 86958 },	-- Twisting Wind Bracers
                { 3, 86959 },	-- Boots of the Blowing Wind
                { 4, 89922 },	-- Hood of Stilled Winds
                { 5, 86954 },	-- Bracers of Unseen Strikes
                { 6, 86962 },	-- Bracers of Tempestuous Fury
                { 7, 90740 },	-- Kaz'tik's Stormseizer Gauntlets
                { 8, 89920 },	-- Sword Dancer's Leggings
                { 9, 89921 },	-- Pauldrons of the Broken Blade
                { 10, 86956 },	-- Windblade Talons
                { 11, 86955 },	-- Waistplate of Overwhelming Assault
                { 16, 86953 },	-- Choker of the Unleashed Storm
                { 17, 86957 },	-- Ring of the Bladed Tempest
                { 19, 86960 },	-- Tornado-Summoning Censer
                { 21, "ac6726" },
                { 22, "ac6936" },
            },
        },
        {	--HoFGaralon
            EncounterJournalID = 713,
            [NORMAL_DIFF] = {
                { 1, 86173 },	-- Legbreaker Greatcloak
                { 2, 86182 },	-- Stormwake Mistcloak
                { 3, 86181 },	-- Xaril's Hood of Intoxicating Vapors
                { 4, 89833 },	-- Shoulders of Foaming Fluids
                { 5, 86178 },	-- Sandals of the Unbidden
                { 6, 86180 },	-- Robes of Eighty Lights
                { 7, 86176 },	-- Bonebreaker Gauntlets
                { 8, 89834 },	-- Vestments of Steaming Ichor
                { 9, 86175 },	-- Grips of the Leviathan
                { 10, 86174 },	-- Garalon's Hollow Skull
                { 11, 89832 },	-- Garalon's Graven Carapace
                { 12, 86179 },	-- Grasps of Panic
                { 16, 86177 },	-- Necklace of Congealed Weaknesses
                { 17, 86172 },	-- Ring of the Shattered Shell
                { 19, "ac6553" },
            },
            [HEROIC_DIFF] = {
                { 1, 86963 },	-- Legbreaker Greatcloak
                { 2, 86971 },	-- Stormwake Mistcloak
                { 3, 86970 },	-- Xaril's Hood of Intoxicating Vapors
                { 4, 89924 },	-- Shoulders of Foaming Fluids
                { 5, 86969 },	-- Sandals of the Unbidden
                { 6, 86972 },	-- Robes of Eighty Lights
                { 7, 86964 },	-- Bonebreaker Gauntlets
                { 8, 89925 },	-- Vestments of Steaming Ichor
                { 9, 86965 },	-- Grips of the Leviathan
                { 10, 86966 },	-- Garalon's Hollow Skull
                { 11, 89923 },	-- Garalon's Graven Carapace
                { 12, 86973 },	-- Grasps of Panic
                { 16, 86967 },	-- Necklace of Congealed Weaknesses
                { 17, 86968 },	-- Ring of the Shattered Shell
                { 19, "ac6727" },
                { 20, "ac6553" },
            },
        },
        {	--HoFMeljarak
            EncounterJournalID = 741,
            [NORMAL_DIFF] = {
                { 1, 86202 },	-- Cloak of Raining Blades
                { 2, 86513 },	-- Robes of Torn Nightmares
                { 3, 86514 },	-- Clutches of Dying Hope
                { 4, 86204 },	-- Wingslasher Pauldrons
                { 5, 86201 },	-- Impaling Treads
                { 16, 89240 },	-- Gauntlets of the Shadowy Conqueror
                { 17, 89241 },	-- Gauntlets of the Shadowy Protector
                { 18, 89242 },	-- Gauntlets of the Shadowy Vanquisher
                { 20, 86205 },	-- Korven's Amber-Sealed Beetle
                { 21, 86200 },	-- Painful Thorned Ring
                { 23, "ac6683" },
            },
            [HEROIC_DIFF] = {
                { 1, 86980 },	-- Cloak of Raining Blades
                { 2, 86975 },	-- Robes of Torn Nightmares
                { 3, 86977 },	-- Clutches of Dying Hope
                { 4, 86978 },	-- Wingslasher Pauldrons
                { 5, 86979 },	-- Impaling Treads
                { 16, 89256 },	-- Gauntlets of the Shadowy Conqueror
                { 17, 89257 },	-- Gauntlets of the Shadowy Protector
                { 18, 89255 },	-- Gauntlets of the Shadowy Vanquisher
                { 20, 86976 },	-- Korven's Amber-Sealed Beetle
                { 21, 86974 },	-- Painful Thorned Ring
                { 23, "ac6728" },
                { 24, "ac6683" },
            },
        },
        {	--HoFUnsok
            EncounterJournalID = 737,
            [NORMAL_DIFF] = {
                { 1, 86210 },	-- Belt of Malleable Amber
                { 2, 86212 },	-- Treads of Deadly Secretions
                { 3, 86214 },	-- Monstrous Stompers
                { 4, 86213 },	-- Shoulderpads of Misshapen Life
                { 6, 86211 },	-- Seal of the Profane
                { 16, 89243 },	-- Leggings of the Shadowy Conqueror
                { 17, 89244 },	-- Leggings of the Shadowy Protector
                { 18, 89245 },	-- Leggings of the Shadowy Vanquisher
                { 20, 86217 },	-- Un'sok's Amber Scalpel
                { 21, 86219 },	-- Scimitar of Seven Stars
                { 23, "ac6518" },
            },
            [HEROIC_DIFF] = {
                { 1, 86981 },	-- Belt of Malleable Amber
                { 2, 86984 },	-- Treads of Deadly Secretions
                { 3, 86985 },	-- Monstrous Stompers
                { 4, 86986 },	-- Shoulderpads of Misshapen Life
                { 6, 86982 },	-- Seal of the Profane
                { 16, 89253 },	-- Leggings of the Shadowy Conqueror
                { 17, 89254 },	-- Leggings of the Shadowy Protector
                { 18, 89252 },	-- Leggings of the Shadowy Vanquisher
                { 20, 86983 },	-- Un'sok's Amber Scalpel
                { 21, 86987 },	-- Scimitar of Seven Stars
                { 23, "ac6729" },
                { 24, "ac6518" },
            },
        },
        {	--HoFShekzeer
            EncounterJournalID = 743,
            [NORMAL_DIFF] = {
                { 1, 86229 },	-- Leggings of Shadow Infestation
                { 2, 89836 },	-- Shadow Heart Spaulders
                { 3, 86228 },	-- Crown of the Doomed Empress
                { 4, 89835 },	-- Hood of Dark Dreams
                { 5, 89837 },	-- Legplates of Regal Reinforcement
                { 7, 86226 },	-- Claws of Shek'zeer
                { 8, 86227 },	-- Kri'tak, Imperial Scepter of the Swarm
                { 16, 89237 },	-- Chest of the Shadowy Conqueror
                { 17, 89238 },	-- Chest of the Shadowy Protector
                { 18, 89239 },	-- Chest of the Shadowy Vanquisher
                { 20, "ac6922" },
            },
            [HEROIC_DIFF] = {
                { 1, 86989 },	-- Leggings of Shadow Infestation
                { 2, 89926 },	-- Shadow Heart Spaulders
                { 3, 86991 },	-- Crown of the Doomed Empress
                { 4, 89927 },	-- Hood of Dark Dreams
                { 5, 89928 },	-- Legplates of Regal Reinforcement
                { 7, 86988 },	-- Claws of Shek'zeer
                { 8, 86990 },	-- Kri'tak, Imperial Scepter of the Swarm
                { 16, 89250 },	-- Chest of the Shadowy Conqueror
                { 17, 89251 },	-- Chest of the Shadowy Protector
                { 18, 89249 },	-- Chest of the Shadowy Vanquisher
                { 20, "ac6730" },
                { 21, "ac6922" },
            },
        },
        {	--HoFTrash
            name = AL["Trash Mobs"],
            ExtraList = true,
            [NORMAL_DIFF] = {
                { 1, 86192 },	-- Darting Damselfly Cuffs
                { 2, 86186 },	-- Gleaming Moth Cuffs
                { 3, 86183 },	-- Shining Cicada Bracers
                { 4, 86187 },	-- Pearlescent Butterfly Wristbands
                { 5, 86185 },	-- Smooth Beetle Wristbands
                { 6, 86189 },	-- Jagged Hornet Bracers
                { 7, 86184 },	-- Luminescent Firefly Wristguards
                { 8, 86188 },	-- Inlaid Cricket Bracers
                { 9, 86191 },	-- Plated Locust Bracers
                { 10, 86190 },	-- Serrated Wasp Bracers
            },
        },
        PATTERNS_ILVL_496,
        T14_SET,
        MOP_RAID1_AC_TABLE,
    }
}

data["TerraceofEndlessSpring"] = {
    EncounterJournalID = 320,
    InstanceID = 996,
    MapID = 6067,
    ContentType = RAID_CONTENT,
    items = {
        {	--ToESProtectors
            EncounterJournalID = 683,
            [NORMAL_DIFF] = {
                { 1, 86316, 90526 },	-- Cloak of Overwhelming Corruption
                { 2, 86317, 90524 },	-- Cuffs of the Corrupted Waters
                { 3, 86320, 90528 },	-- Asani's Uncleansed Sandals
                { 4, 89841, 90518 },	-- Legguards of Failing Purification
                { 5, 89885, 90519 },	-- Waterborne Shoulderguards
                { 6, 86319, 90529 },	-- Lightning Prisoner's Boots
                { 7, 86318, 90530 },	-- Casque of Expelled Corruption
                { 8, 86230, 90520 },	-- Bracers of Defiled Earth
                { 9, 86232, 90521 },	-- Deepwater Greatboots
                { 16, 86234, 90523 },	-- Kaolan's Withering Necklace
                { 17, 86233, 90522 },	-- Shackle of Eversparks
                { 18, 86231, 90517 },	-- Regail's Band of the Endless
                { 19, 86315, 90525 },	-- Watersoul Signet
                { 21, 86390, 90527 },	-- Regail's Crackling Dagger
                { 23, "ac6717" },
            },
            [HEROIC_DIFF] = {
                { 1, 87150, 90512 },	-- Cloak of Overwhelming Corruption
                { 2, 87149, 90510 },	-- Cuffs of the Corrupted Waters
                { 3, 87153, 90514 },	-- Asani's Uncleansed Sandals
                { 4, 89943, 90504 },	-- Legguards of Failing Purification
                { 5, 89944, 90505 },	-- Waterborne Shoulderguards
                { 6, 87154, 90515 },	-- Lightning Prisoner's Boots
                { 7, 87155, 90516 },	-- Casque of Expelled Corruption
                { 8, 87145, 90506 },	-- Bracers of Defiled Earth
                { 9, 87146, 90507 },	-- Deepwater Greatboots
                { 16, 87148, 90509 },	-- Kaolan's Withering Necklace
                { 17, 87147, 90508 },	-- Shackle of Eversparks
                { 18, 87144, 90503 },	-- Regail's Band of the Endless
                { 19, 87151, 90511 },	-- Watersoul Signet
                { 21, 87152, 90513 },	-- Regail's Crackling Dagger
                { 23, "ac6731" },
                { 24, "ac6717" },
            },
        },
        {	--ToESTsulong
            EncounterJournalID = 742,
            [NORMAL_DIFF] = {
                { 1, 86325 },	-- Daybreak Drape
                { 2, 89883 },	-- Shoulderpads of Twisted Fate
                { 3, 86326 },	-- Belt of Embodied Terror
                { 4, 86337 },	-- Healer's Belt of Final Winter
                { 5, 86338 },	-- Invoker's Belt of Final Winter
                { 6, 86339 },	-- Sorcerer's Belt of Final Winter
                { 7, 86330 },	-- Sandals of the Blackest Night
                { 8, 89842 },	-- Gauntlets of the Shadow's Caress
                { 9, 86341 },	-- Stalker's Cord of Eternal Autumn
                { 10, 86340 },	-- Weaver's Cord of Eternal Autumn
                { 11, 89884 },	-- Fear-Blackened Leggings
                { 12, 86324 },	-- Sunwrought Mail Hauberk
                { 13, 86342 },	-- Binder's Chain of Unending Summer
                { 14, 86343 },	-- Ranger's Chain of Unending Summer
                { 15, 89843 },	-- Grasps of Serpentine Might
                { 16, 86383 },	-- Mender's Girdle of Endless Spring
                { 17, 86385 },	-- Patroller's Girdle of Endless Spring
                { 18, 86384 },	-- Protector's Girdle of Endless Spring
                { 19, 86329 },	-- Sollerets of Instability
                { 21, 86322 },	-- Dread Shadow Ring
                { 22, 86327 },	-- Spirits of the Sun
                { 23, 86323 },	-- Stuff of Nightmares
                { 25, 86328 },	-- Loshan, Terror Incarnate
                { 26, 86321 },	-- Gao-Rei, Staff of the Legendary Protector
                { 28, "ac6933" },
            },
            [HEROIC_DIFF] = {
                { 1, 87159 },	-- Daybreak Drape
                { 2, 89947 },	-- Shoulderpads of Twisted Fate
                { 3, 87161 },	-- Belt of Embodied Terror
                { 4, 87178 },	-- Healer's Belt of Final Winter
                { 5, 87177 },	-- Invoker's Belt of Final Winter
                { 6, 87179 },	-- Sorcerer's Belt of Final Winter
                { 7, 87162 },	-- Sandals of the Blackest Night
                { 8, 89945 },	-- Gauntlets of the Shadow's Caress
                { 9, 87180 },	-- Stalker's Cord of Eternal Autumn
                { 10, 87181 },	-- Weaver's Cord of Eternal Autumn
                { 11, 89948 },	-- Fear-Blackened Leggings
                { 12, 87157 },	-- Sunwrought Mail Hauberk
                { 13, 87183 },	-- Binder's Chain of Unending Summer
                { 14, 87182 },	-- Ranger's Chain of Unending Summer
                { 15, 89946 },	-- Grasps of Serpentine Might
                { 16, 87184 },	-- Mender's Girdle of Endless Spring
                { 17, 87186 },	-- Patroller's Girdle of Endless Spring
                { 18, 87185 },	-- Protector's Girdle of Endless Spring
                { 19, 87165 },	-- Sollerets of Instability
                { 21, 87158 },	-- Dread Shadow Ring
                { 22, 87163 },	-- Spirits of the Sun
                { 23, 87160 },	-- Stuff of Nightmares
                { 25, 87164 },	-- Loshan, Terror Incarnate
                { 26, 87156 },	-- Gao-Rei, Staff of the Legendary Protector
                { 28, "ac6732" },
                { 29, "ac6933" },
            },
        },
        {	--ToESLeiShi
            EncounterJournalID = 729,
            [NORMAL_DIFF] = {
                { 1, 86334 },	-- Robes of the Unknown Fear
                { 2, 86337 },	-- Healer's Belt of Final Winter
                { 3, 86338 },	-- Invoker's Belt of Final Winter
                { 4, 86339 },	-- Sorcerer's Belt of Final Winter
                { 5, 86341 },	-- Stalker's Cord of Eternal Autumn
                { 6, 86340 },	-- Weaver's Cord of Eternal Autumn
                { 7, 86342 },	-- Binder's Chain of Unending Summer
                { 8, 86343 },	-- Ranger's Chain of Unending Summer
                { 9, 86333 },	-- Cuirass of the Animated Protector
                { 10, 86383 },	-- Mender's Girdle of Endless Spring
                { 11, 86385 },	-- Patroller's Girdle of Endless Spring
                { 12, 86384 },	-- Protector's Girdle of Endless Spring
                { 16, 89246 },	-- Shoulders of the Shadowy Conqueror
                { 17, 89247 },	-- Shoulders of the Shadowy Protector
                { 18, 89248 },	-- Shoulders of the Shadowy Vanquisher
                { 20, 86336 },	-- Darkmist Vortex
                { 21, 86332 },	-- Terror in the Mists
                { 23, 86391 },	-- Spiritsever
                { 24, 86335 },	-- Jin'ya, Orb of the Waterspeaker
                { 25, 86331 },	-- Taoren, the Soul Burner
                { 27, "ac6824" },
            },
            [HEROIC_DIFF] = {
                { 1, 87169 },	-- Robes of the Unknown Fear
                { 2, 87178 },	-- Healer's Belt of Final Winter
                { 3, 87177 },	-- Invoker's Belt of Final Winter
                { 4, 87179 },	-- Sorcerer's Belt of Final Winter
                { 5, 87180 },	-- Stalker's Cord of Eternal Autumn
                { 6, 87181 },	-- Weaver's Cord of Eternal Autumn
                { 7, 87183 },	-- Binder's Chain of Unending Summer
                { 8, 87182 },	-- Ranger's Chain of Unending Summer
                { 9, 87171 },	-- Cuirass of the Animated Protector
                { 10, 87184 },	-- Mender's Girdle of Endless Spring
                { 11, 87186 },	-- Patroller's Girdle of Endless Spring
                { 12, 87185 },	-- Protector's Girdle of Endless Spring
                { 16, 89262 },	-- Shoulders of the Shadowy Conqueror
                { 17, 89263 },	-- Shoulders of the Shadowy Protector
                { 18, 89261 },	-- Shoulders of the Shadowy Vanquisher
                { 20, 87172 },	-- Darkmist Vortex
                { 21, 87167 },	-- Terror in the Mists
                { 23, 87166 },	-- Spiritsever
                { 24, 87170 },	-- Jin'ya, Orb of the Waterspeaker
                { 25, 87168 },	-- Taoren, the Soul Burner
                { 27, "ac6733" },
                { 28, "ac6824" },
            },
        },
        {	--ToESShaofFear
            EncounterJournalID = 709,
            [NORMAL_DIFF] = {
                { 1, 89887 },	-- Robes of Pinioned Eyes
                { 2, 86389 },	-- Dreadwoven Leggings of Failure
                { 3, 89886 },	-- Wrap of Instant Petrification
                { 4, 89839 },	-- Shadowgrip Girdle
                { 6, 86388 },	-- Essence of Terror
                { 8, 86387 },	-- Kilrak, Jaws of Terror
                { 9, 86386 },	-- Shin'ka, Execution of Dominion
                { 11, 87210, [ATLASLOOT_IT_FILTERIGNORE] = true },	-- Chimera of Fear
                { 16, 89235 },	-- Helm of the Shadowy Conqueror
                { 17, 89236 },	-- Helm of the Shadowy Protector
                { 18, 89234 },	-- Helm of the Shadowy Vanquisher
                { 20, "ac6926" },
                { 21, "ac6825" },
            },
            [HEROIC_DIFF] = {
                { 1, 89949 },	-- Robes of Pinioned Eyes
                { 2, 87174 },	-- Dreadwoven Leggings of Failure
                { 3, 89950 },	-- Wrap of Instant Petrification
                { 4, 89951 },	-- Shadowgrip Girdle
                { 6, 87175 },	-- Essence of Terror
                { 8, 87173 },	-- Kilrak, Jaws of Terror
                { 9, 87176 },	-- Shin'ka, Execution of Dominion
                { 11, 87210, [ATLASLOOT_IT_FILTERIGNORE] = true },	-- Chimera of Fear
                { 16, 89259 },	-- Helm of the Shadowy Conqueror
                { 17, 89260 },	-- Helm of the Shadowy Protector
                { 18, 89258 },	-- Helm of the Shadowy Vanquisher
                { 20, "ac6734" },
                { 21, "ac6926" },
                { 22, "ac6825" },
            },
        },
        PATTERNS_ILVL_496,
        T14_SET,
        MOP_RAID1_AC_TABLE,
    }
}

data["ThroneofThunder"] = {
    EncounterJournalID = 362,
    InstanceID = 1098,
    MapID = 6622,
    ContentType = RAID_CONTENT,
    ContentPhaseMoP = 3,
    items = {
        {	--ToTJinrokh
            EncounterJournalID = 827,
            ContentPhaseMoP = 3,
            [NORMAL_DIFF] = {
                { 1, 94735, 96011 },	-- Drape of Booming Nights
                { 2, 94733, 96008 },	-- Fissure-Split Shoulderwraps
                { 3, 94731, 96009 },	-- Robes of Static Bursts
                { 4, 94737, 96006 },	-- Lightningweaver Gauntlets
                { 5, 94739, 96007 },	-- Al'set's Tormented Leggings
                { 6, 94724, 95998 },	-- Lightning-Eye Hood
                { 7, 94732, 96014 },	-- Infinitely Conducting Bracers
                { 8, 94725, 96000 },	-- Static-Shot Shoulderguards
                { 9, 94728, 95999 },	-- Spearman's Jingling Leggings
                { 10, 94736, 96015 },	-- Ghostbinder Greatboots
                { 11, 94723, 96002 },	-- Chestplate of Violent Detonation
                { 12, 94734, 96016 },	-- Ionized Yojamban Carapace
                { 13, 94727, 96003 },	-- Bracers of Constant Implosion
                { 14, 94726, 96001 },	-- Cloudbreaker Greatbelt
                { 16, 94738, 96010 },	-- Jin'rokh's Dreamshard
                { 17, 94729, 96005 },	-- Jin'rokh's Soulcrystal
                { 18, 95510, 95996 },	-- Sign of the Bloodied God
                { 19, 94512, 95997 },	-- Renataki's Soul Charm
                { 21, 94730, 96012 },	-- Soulblade of the Breaking Storm
                { 22, 94722, 96004 },	-- Worldbreaker's Stormscythe
                { 24, "ac8094" },
            },
            [HEROIC_DIFF] = {
                { 1, 96383, 96755 },	-- Drape of Booming Nights
                { 2, 96380, 96752 },	-- Fissure-Split Shoulderwraps
                { 3, 96381, 96753 },	-- Robes of Static Bursts
                { 4, 96378, 96750 },	-- Lightningweaver Gauntlets
                { 5, 96379, 96751 },	-- Al'set's Tormented Leggings
                { 6, 96370, 96742 },	-- Lightning-Eye Hood
                { 7, 96386, 96758 },	-- Infinitely Conducting Bracers
                { 8, 96372, 96744 },	-- Static-Shot Shoulderguards
                { 9, 96371, 96743 },	-- Spearman's Jingling Leggings
                { 10, 96387, 96759 },	-- Ghostbinder Greatboots
                { 11, 96374, 96746 },	-- Chestplate of Violent Detonation
                { 12, 96388, 96760 },	-- Ionized Yojamban Carapace
                { 13, 96375, 96747 },	-- Bracers of Constant Implosion
                { 14, 96373, 96745 },	-- Cloudbreaker Greatbelt
                { 16, 96382, 96754 },	-- Jin'rokh's Dreamshard
                { 17, 96377, 96749 },	-- Jin'rokh's Soulcrystal
                { 18, 96368, 96740 },	-- Sign of the Bloodied God
                { 19, 96369, 96741 },	-- Renataki's Soul Charm
                { 21, 96384, 96756 },	-- Soulblade of the Breaking Storm
                { 22, 96376, 96748 },	-- Worldbreaker's Stormscythe
                { 24, "ac8056" },
                { 25, "ac8094" },
            },
        },
        {	--ToTHorridon
            EncounterJournalID = 819,
            ContentPhaseMoP = 3,
            [NORMAL_DIFF] = {
                { 1, 94745, 96025 },	-- Horn-Rimmed Doomcloak
                { 2, 94748, 96017 },	-- Wastewalker's Sandblasted Drape
                { 3, 94752, 96027 },	-- Flamecaster's Burning Crown
                { 4, 94750, 96028 },	-- Vaccinator's Armwraps
                { 5, 94753, 96034 },	-- Spaulders of Dinomancy
                { 6, 94743, 96020 },	-- Bindings of Multiplicative Strikes
                { 7, 94756, 96033 },	-- Roots of Rampaging Earth
                { 8, 94741, 96021 },	-- Sul'lithuz Sandmail
                { 9, 94975, 96035 },	-- Legguards of Scintillating Scales
                { 10, 94744, 96024 },	-- Puncture-Proof Greathelm
                { 11, 94751, 96036 },	-- Armplates of the Vanquished Abomination
                { 12, 94742, 96022 },	-- Frozen Warlord's Bracers
                { 13, 94747, 96023 },	-- Bloodlord's Bloodsoaked Legplates
                { 16, 94754, 96030 },	-- Horridon's Tusk Fragment
                { 17, 94746, 96018 },	-- Talisman of Living Poison
                { 18, 95514, 96031 },	-- Petrified Eye of the Basilisk
                { 19, 94514, 96013 },	-- Horridon's Last Gasp
                { 20, 94526, 96026 },	-- Spark of Zandalar
                { 22, 94749, 96029 },	-- Dinomancer's Spiritbinding Spire
                { 23, 94740, 96019 },	-- Jalak's Maelstrom Staff
                { 24, 94755, 96032 },	-- Venomlord's Totemic Wand
                { 26, 93666, "mount" },	-- Spawn of Horridon
                { 27, 94574, "pet1200" }, -- Pygmy Direhorn
                { 29, "ac8038" },
            },
            [HEROIC_DIFF] = {
                { 1, 96397, 96769 },	-- Horn-Rimmed Doomcloak
                { 2, 96389, 96761 },	-- Wastewalker's Sandblasted Drape
                { 3, 96399, 96771 },	-- Flamecaster's Burning Crown
                { 4, 96400, 96772 },	-- Vaccinator's Armwraps
                { 5, 96406, 96778 },	-- Spaulders of Dinomancy
                { 6, 96392, 96764 },	-- Bindings of Multiplicative Strikes
                { 7, 96405, 96777 },	-- Roots of Rampaging Earth
                { 8, 96393, 96765 },	-- Sul'lithuz Sandmail
                { 9, 96407, 96779 },	-- Legguards of Scintillating Scales
                { 10, 96396, 96768 },	-- Puncture-Proof Greathelm
                { 11, 96408, 96780 },	-- Armplates of the Vanquished Abomination
                { 12, 96394, 96766 },	-- Frozen Warlord's Bracers
                { 13, 96395, 96767 },	-- Bloodlord's Bloodsoaked Legplates
                { 16, 96402, 96774 },	-- Horridon's Tusk Fragment
                { 17, 96390, 96762 },	-- Talisman of Living Poison
                { 18, 96403, 96775 },	-- Petrified Eye of the Basilisk
                { 19, 96385, 96757 },	-- Horridon's Last Gasp
                { 20, 96398, 96770 },	-- Spark of Zandalar
                { 22, 96401, 96773 },	-- Dinomancer's Spiritbinding Spire
                { 23, 96391, 96763 },	-- Jalak's Maelstrom Staff
                { 24, 96404, 96776 },	-- Venomlord's Totemic Wand
                { 26, 93666, "mount" },	-- Spawn of Horridon
                { 27, 94574, "pet1200" }, -- Pygmy Direhorn
                { 29, "ac8057" },
                { 30, "ac8038" },
            },
        },
        {	--ToTCouncil
            EncounterJournalID = 816,
            ContentPhaseMoP = 3,
            [NORMAL_DIFF] = {
                { 1, 94761, 96040 },	-- Zandalari Robes of the Final Rite
                { 2, 94762, 96039 },	-- Mar'li's Bloodstained Sandals
                { 3, 94765, 96043 },	-- Robes of Treacherous Ground
                { 4, 94763, 96044 },	-- Gaze of Gara'jal
                { 5, 94767, 96045 },	-- Loa-Ridden Bracers
                { 6, 94764, 96046 },	-- Overloaded Bladebreaker Cuirass
                { 8, 94766, 96048 },	-- Talisman of Angry Spirits
                { 9, 94523, 96037 },	-- Bad Juju
                { 10, 94516, 96049 },	-- Fortitude of the Zandalari
                { 11, 94513, 96041 },	-- Wushoolay's Final Choice
                { 16, 95575 },	-- Gauntlets of the Crackling Conqueror
                { 17, 95580 },	-- Gauntlets of the Crackling Protector
                { 18, 95570 },	-- Gauntlets of the Crackling Vanquisher
                { 20, 94760, 96042 },	-- Amun-Thoth, Sul's Spiritrending Talons
                { 21, 94759, 96038 },	-- Kura-Kura, Kazra'jin's Skullcleaver
                { 22, 94758, 96047 },	-- Zerat, Malakk's Soulburning Greatsword
                { 24, "ac8073" },
            },
            [HEROIC_DIFF] = {
                { 1, 96412, 96784 },	-- Zandalari Robes of the Final Rite
                { 2, 96411, 96783 },	-- Mar'li's Bloodstained Sandals
                { 3, 96415, 96787 },	-- Robes of Treacherous Ground
                { 4, 96416, 96788 },	-- Gaze of Gara'jal
                { 5, 96417, 96789 },	-- Loa-Ridden Bracers
                { 6, 96418, 96790 },	-- Overloaded Bladebreaker Cuirass
                { 8, 96420, 96792 },	-- Talisman of Angry Spirits
                { 9, 96409, 96781 },	-- Bad Juju
                { 10, 96421, 96793 },	-- Fortitude of the Zandalari
                { 11, 96413, 96785 },	-- Wushoolay's Final Choice
                { 16, 96600 },	-- Gauntlets of the Crackling Conqueror
                { 17, 96601 },	-- Gauntlets of the Crackling Protector
                { 18, 96599 },	-- Gauntlets of the Crackling Vanquisher
                { 20, 96414, 96786 },	-- Amun-Thoth, Sul's Spiritrending Talons
                { 21, 96410, 96782 },	-- Kura-Kura, Kazra'jin's Skullcleaver
                { 22, 96419, 96791 },	-- Zerat, Malakk's Soulburning Greatsword
                { 24, "ac8058" },
                { 25, "ac8073" },
            },
        },
        {	--ToTTortos
            EncounterJournalID = 825,
            ContentPhaseMoP = 3,
            [NORMAL_DIFF] = {
                { 1, 94774, 96059 },	-- Beakbreaker Greatcloak
                { 2, 94785, 96063 },	-- Shimmershell Cape
                { 3, 94782, 96061 },	-- Stonegaze Hood
                { 4, 94781, 96060 },	-- Azure Shell Bracers
                { 5, 94780, 96062 },	-- Crystal-Claw Gloves
                { 6, 94779, 96066 },	-- Robes of Concussive Shocks
                { 7, 94770, 96051 },	-- Rockfall Ribwraps
                { 8, 94786, 96065 },	-- Vampire Bat-Hide Bracers
                { 9, 94777, 96052 },	-- Grips of Vampiric Cruelty
                { 10, 94783, 96067 },	-- Spaulders of Quaking Fear
                { 11, 94775, 96053 },	-- Beady-Eye Bracers
                { 12, 94772, 96054 },	-- Quakestompers
                { 13, 94773, 96055 },	-- Shoulderguards of Centripetal Destruction
                { 14, 94771, 96056 },	-- Shell-Coated Wristplates
                { 15, 94787, 96069 },	-- Tortos' Shellseizers
                { 16, 94784, 96068 },	-- Refreshing Abalone Girdle
                { 18, 94776, 96057 },	-- Amulet of the Primal Turtle
                { 20, 94768, 96058 },	-- Shellsplitter Greataxe
                { 21, 94769, 96050 },	-- Shattered Tortoiseshell Longbow
                { 22, 94778, 96064 },	-- Tortos' Discarded Shell
                { 24, 98132 },	-- Shado-Pan Geyser Gun
                { 26, "ac8077" },
            },
            [HEROIC_DIFF] = {
                { 1, 96431, 96803 },	-- Beakbreaker Greatcloak
                { 2, 96435, 96807 },	-- Shimmershell Cape
                { 3, 96433, 96805 },	-- Stonegaze Hood
                { 4, 96432, 96804 },	-- Azure Shell Bracers
                { 5, 96434, 96806 },	-- Crystal-Claw Gloves
                { 6, 96438, 96810 },	-- Robes of Concussive Shocks
                { 7, 96423, 96795 },	-- Rockfall Ribwraps
                { 8, 96437, 96809 },	-- Vampire Bat-Hide Bracers
                { 9, 96424, 96796 },	-- Grips of Vampiric Cruelty
                { 10, 96439, 96811 },	-- Spaulders of Quaking Fear
                { 11, 96425, 96797 },	-- Beady-Eye Bracers
                { 12, 96426, 96798 },	-- Quakestompers
                { 13, 96427, 96799 },	-- Shoulderguards of Centripetal Destruction
                { 14, 96428, 96800 },	-- Shell-Coated Wristplates
                { 15, 96441, 96813 },	-- Tortos' Shellseizers
                { 16, 96440, 96812 },	-- Refreshing Abalone Girdle
                { 18, 96429, 96801 },	-- Amulet of the Primal Turtle
                { 20, 96430, 96802 },	-- Shellsplitter Greataxe
                { 21, 96422, 96794 },	-- Shattered Tortoiseshell Longbow
                { 22, 96436, 96808 },	-- Tortos' Discarded Shell
                { 24, 98132 },	-- Shado-Pan Geyser Gun
                { 26, "ac8059" },
                { 27, "ac8077" },
            },
        },
        {	--ToTMegaera
            EncounterJournalID = 821,
            ContentPhaseMoP = 3,
            [NORMAL_DIFF] = {
                { 1, 94801, 96079 },	-- Gleaming-Eye Shoulderpads
                { 2, 94804, 96080 },	-- Frostborn Wristwraps
                { 3, 94799, 96078 },	-- Sandals of Arcane Fury
                { 4, 94800, 96085 },	-- Hood of Smoldering Flesh
                { 5, 94791, 96072 },	-- Poisonblood Bladeshoulders
                { 6, 94797, 96087 },	-- Chain of Consuming Magic
                { 7, 94790, 96073 },	-- Grips of Cinderflesh
                { 8, 94802, 96086 },	-- Links of the Bifurcated Tongue
                { 9, 94789, 96075 },	-- Rot-Proof Greatplate
                { 10, 94792, 96074 },	-- Plated Toothbreaker Girdle
                { 11, 94798, 96088 },	-- Ice-Scored Treads
                { 16, 94793, 96077 },	-- Hydraskull Choker
                { 17, 94803, 96081 },	-- Megaera's Shining Eye
                { 18, 94794, 96071 },	-- Quadra-Head Brooch
                { 19, 94795, 96076 },	-- Spinescale Seal
                { 20, 94521, 96083 },	-- Breath of the Hydra
                { 21, 94520, 96084 },	-- Inscribed Bag of Hydra-Spawn
                { 23, 94788, 96070 },	-- Megaera's Poisoned Fang
                { 24, 94796, 96082 },	-- Fetish of the Hydra
                { 26, "ac8082" },
            },
            [HEROIC_DIFF] = {
                { 1, 96451, 96823 },	-- Gleaming-Eye Shoulderpads
                { 2, 96452, 96824 },	-- Frostborn Wristwraps
                { 3, 96450, 96822 },	-- Sandals of Arcane Fury
                { 4, 96457, 96829 },	-- Hood of Smoldering Flesh
                { 5, 96444, 96816 },	-- Poisonblood Bladeshoulders
                { 6, 96459, 96831 },	-- Chain of Consuming Magic
                { 7, 96445, 96817 },	-- Grips of Cinderflesh
                { 8, 96458, 96830 },	-- Links of the Bifurcated Tongue
                { 9, 96447, 96819 },	-- Rot-Proof Greatplate
                { 10, 96446, 96818 },	-- Plated Toothbreaker Girdle
                { 11, 96460, 96832 },	-- Ice-Scored Treads
                { 16, 96449, 96821 },	-- Hydraskull Choker
                { 17, 96453, 96825 },	-- Megaera's Shining Eye
                { 18, 96443, 96815 },	-- Quadra-Head Brooch
                { 19, 96448, 96820 },	-- Spinescale Seal
                { 20, 96455, 96827 },	-- Breath of the Hydra
                { 21, 96456, 96828 },	-- Inscribed Bag of Hydra-Spawn
                { 23, 96442, 96814 },	-- Megaera's Poisoned Fang
                { 24, 96454, 96826 },	-- Fetish of the Hydra
                { 26, "ac8060" },
                { 27, "ac8082" },
            },
        },
        {	--ToTJiKun
            EncounterJournalID = 828,
            ContentPhaseMoP = 3,
            [NORMAL_DIFF] = {
                { 1, 94812, 96089 },	-- Pinionfeather Greatcloak
                { 2, 94806, 96091 },	-- Robe of Midnight Down
                { 3, 94813, 96090 },	-- Cord of Cacophonous Cawing
                { 4, 94811, 96093 },	-- Featherflight Belt
                { 5, 94808, 96094 },	-- Grasp of the Ruthless Mother
                { 6, 94809, 96095 },	-- Crown of Potentiated Birth
                { 7, 94810, 96096 },	-- Talonrender Chestplate
                { 8, 94807, 96097 },	-- Egg-Shard Grips
                { 10, 95059, "mount" },	-- Clutch of Ji-Kun
                { 11, 94835, "pet1202" },	-- Ji-Kun Hatchling
                { 16, 95576 },	-- Leggings of the Crackling Conqueror
                { 17, 95581 },	-- Leggings of the Crackling Protector
                { 18, 95572 },	-- Leggings of the Crackling Vanquisher
                { 20, 94515, 96098 },	-- Fabled Feather of Ji-Kun
                { 21, 94527, 96099 },	-- Ji-Kun's Rising Winds
                { 23, 94805, 96092 },	-- Giorgio's Caduceus of Pure Moods
                { 25, "ac8097" },
            },
            [HEROIC_DIFF] = {
                { 1, 96461, 96833 },	-- Pinionfeather Greatcloak
                { 2, 96463, 96835 },	-- Robe of Midnight Down
                { 3, 96462, 96834 },	-- Cord of Cacophonous Cawing
                { 4, 96465, 96837 },	-- Featherflight Belt
                { 5, 96466, 96838 },	-- Grasp of the Ruthless Mother
                { 6, 96467, 96839 },	-- Crown of Potentiated Birth
                { 7, 96468, 96840 },	-- Talonrender Chestplate
                { 8, 96469, 96841 },	-- Egg-Shard Grips
                { 10, 95059, "mount" },	-- Clutch of Ji-Kun
                { 11, 94835, "pet1202" },	-- Ji-Kun Hatchling
                { 16, 96632 },	-- Leggings of the Crackling Conqueror
                { 17, 96633 },	-- Leggings of the Crackling Protector
                { 18, 96631 },	-- Leggings of the Crackling Vanquisher
                { 20, 96470, 96842 },	-- Fabled Feather of Ji-Kun
                { 21, 96471, 96843 },	-- Ji-Kun's Rising Winds
                { 23, 96464, 96836 },	-- Giorgio's Caduceus of Pure Moods
                { 25, "ac8061" },
                { 26, "ac8097" },
            },
        },
        {	--ToTDurumu
            EncounterJournalID = 818,
            ContentPhaseMoP = 3,
            [NORMAL_DIFF] = {
                { 1, 94929, 96113 },	-- Deadly Glare Cape
                { 2, 94822, 96108 },	-- Reinforced Mirror-Sheen Cloak
                { 3, 94928, 96112 },	-- Chilblain Spaulders
                { 4, 94925, 96110 },	-- Lifedrainer's Sordid Grip
                { 5, 94923, 96111 },	-- Leggings of Pulsing Blood
                { 6, 94816, 96101 },	-- Crimson Bloom Legguards
                { 7, 94927, 96116 },	-- Sandals of the Starving Eye
                { 8, 94818, 96103 },	-- Aberrant Chestguard of Torment
                { 9, 94926, 96117 },	-- Vein-Cover Bracers
                { 10, 94819, 96102 },	-- Links of the Disintegrator
                { 11, 94820, 96104 },	-- Caustic Spike Bracers
                { 12, 94821, 96107 },	-- Artery Rippers
                { 13, 94924, 96118 },	-- Iceshatter Gauntlets
                { 14, 94930, 96119 },	-- Legplates of Re-Emergence
                { 15, 94815, 96105 },	-- Legplates of the Dark Parasite
                { 16, 94817, 96106 },	-- Treads of the Blind Eye
                { 18, 94931, 96114 },	-- Durumu's Captive Eyeball
                { 19, 95511, 96109 },	-- Durumu's Severed Tentacle
                { 21, 94922, 96115 },	-- Ritual Dagger of the Mind's Eye
                { 22, 94814, 96100 },	-- Durumu's Baleful Gaze
                { 24, "ac8098" },
            },
            [HEROIC_DIFF] = {
                { 1, 96485, 96857 },	-- Deadly Glare Cape
                { 2, 96480, 96852 },	-- Reinforced Mirror-Sheen Cloak
                { 3, 96484, 96856 },	-- Chilblain Spaulders
                { 4, 96482, 96854 },	-- Lifedrainer's Sordid Grip
                { 5, 96483, 96855 },	-- Leggings of Pulsing Blood
                { 6, 96473, 96845 },	-- Crimson Bloom Legguards
                { 7, 96488, 96860 },	-- Sandals of the Starving Eye
                { 8, 96475, 96847 },	-- Aberrant Chestguard of Torment
                { 9, 96489, 96861 },	-- Vein-Cover Bracers
                { 10, 96474, 96846 },	-- Links of the Disintegrator
                { 11, 96476, 96848 },	-- Caustic Spike Bracers
                { 12, 96479, 96851 },	-- Artery Rippers
                { 13, 96490, 96862 },	-- Iceshatter Gauntlets
                { 14, 96491, 96863 },	-- Legplates of Re-Emergence
                { 15, 96477, 96849 },	-- Legplates of the Dark Parasite
                { 16, 96478, 96850 },	-- Treads of the Blind Eye
                { 18, 96486, 96858 },	-- Durumu's Captive Eyeball
                { 19, 96481, 96853 },	-- Durumu's Severed Tentacle
                { 21, 96487, 96859 },	-- Ritual Dagger of the Mind's Eye
                { 22, 96472, 96844 },	-- Durumu's Baleful Gaze
                { 24, "ac8062" },
                { 25, "ac8098" },
            },
        },
        {	--ToTPrimordius
            EncounterJournalID = 820,
            ContentPhaseMoP = 3,
            [NORMAL_DIFF] = {
                { 1, 94942, 96127 },	-- Hydra-Scale Bloodcloak
                { 2, 94951, 96131 },	-- Robes of Mutagenic Blood
                { 3, 94948, 96134 },	-- Bracers of Fragile Bone
                { 4, 94947, 96132 },	-- Helix-Breaker Gloves
                { 5, 94953, 96133 },	-- Leggings of Ebon Veins
                { 6, 94939, 96121 },	-- Gloves of Cushioned Air
                { 7, 94946, 96136 },	-- Leggings of the Malformed Sapling
                { 8, 94949, 96137 },	-- Clear-Mind Helm
                { 9, 94940, 96122 },	-- Bracers of Mutagenic Fervor
                { 10, 94943, 96123 },	-- Synapse-String Handguards
                { 11, 94941, 96126 },	-- Metabolically Boosted Shoulderplates
                { 12, 94950, 96139 },	-- Spaulders of Primordial Growth
                { 13, 94952, 96138 },	-- Bonemender Bracers
                { 14, 94938, 96124 },	-- Pathogenic Gauntlets
                { 15, 94944, 96125 },	-- Black Blood Legplates
                { 16, 95513, 96128 },	-- Band of the Scaled Tyrant
                { 17, 94519, 96129 },	-- Primordius' Talisman of Rage
                { 18, 94525, 96135 },	-- Stolen Relic of Zuldazar
                { 19, 94522, 96120 },	-- Talisman of Bloodlust
                { 21, 94937, 96130 },	-- Acid-Spine Bonemace
                { 22, 94945, 96140 },	-- Greatshield of the Gloaming
                { 24, 97959, "pet1243" }, -- Living Fluid
                { 25, 97960, "pet1244" },	-- Dark Quivering Blob
                { 27, "ac8037" },
            },
            [HEROIC_DIFF] = {
                { 1, 96499, 96871 },	-- Hydra-Scale Bloodcloak
                { 2, 96503, 96875 },	-- Robes of Mutagenic Blood
                { 3, 96506, 96878 },	-- Bracers of Fragile Bone
                { 4, 96504, 96876 },	-- Helix-Breaker Gloves
                { 5, 96505, 96877 },	-- Leggings of Ebon Veins
                { 6, 96493, 96865 },	-- Gloves of Cushioned Air
                { 7, 96508, 96880 },	-- Leggings of the Malformed Sapling
                { 8, 96509, 96881 },	-- Clear-Mind Helm
                { 9, 96494, 96866 },	-- Bracers of Mutagenic Fervor
                { 10, 96495, 96867 },	-- Synapse-String Handguards
                { 11, 96498, 96870 },	-- Metabolically Boosted Shoulderplates
                { 12, 96511, 96883 },	-- Spaulders of Primordial Growth
                { 13, 96510, 96882 },	-- Bonemender Bracers
                { 14, 96496, 96868 },	-- Pathogenic Gauntlets
                { 15, 96497, 96869 },	-- Black Blood Legplates
                { 16, 96500, 96872 },	-- Band of the Scaled Tyrant
                { 17, 96501, 96873 },	-- Primordius' Talisman of Rage
                { 18, 96507, 96879 },	-- Stolen Relic of Zuldazar
                { 19, 96492, 96864 },	-- Talisman of Bloodlust
                { 21, 96502, 96874 },	-- Acid-Spine Bonemace
                { 22, 96512, 96884 },	-- Greatshield of the Gloaming
                { 24, 97959, "pet1243" }, -- Living Fluid
                { 25, 97960, "pet1244" },	-- Dark Quivering Blob
                { 27, "ac8063" },
                { 28, "ac8037" },
            },
        },
        {	--ToTDarkAnimus
            EncounterJournalID = 824,
            ContentPhaseMoP = 3,
            [NORMAL_DIFF] = {
                { 1, 94960, 96145 },	-- Constantly Accelerating Cloak
                { 2, 94959, 96143 },	-- Hood of the Crimson Wake
                { 3, 94957, 96148 },	-- Anima-Ringed Fingers
                { 4, 94962, 96147 },	-- Worldbinder Leggings
                { 5, 94958, 96150 },	-- Crown of the Golden Golem
                { 6, 94956, 96149 },	-- Matter-Swapped Legplates
                { 8, 94961, 96141 },	-- Gore-Soaked Gear
                { 9, 94531, 96144 },	-- Cha-Ye's Essence of Brilliance
                { 10, 94518, 96151 },	-- Delicate Vial of the Sanguinaire
                { 16, 95574 },	-- Chest of the Crackling Conqueror
                { 17, 95579 },	-- Chest of the Crackling Protector
                { 18, 95569 },	-- Chest of the Crackling Vanquisher
                { 20, 94955, 96146 },	-- Athame of the Sanguine Ritual
                { 21, 94954, 96142 },	-- Hand of the Dark Animus
                { 23, 94152, "pet1183" },	-- Son of Animus
                { 25, "ac8081" },
            },
            [HEROIC_DIFF] = {
                { 1, 96517, 96889 },	-- Constantly Accelerating Cloak
                { 2, 96515, 96887 },	-- Hood of the Crimson Wake
                { 3, 96520, 96892 },	-- Anima-Ringed Fingers
                { 4, 96519, 96891 },	-- Worldbinder Leggings
                { 5, 96522, 96894 },	-- Crown of the Golden Golem
                { 6, 96521, 96893 },	-- Matter-Swapped Legplates
                { 8, 96513, 96885 },	-- Gore-Soaked Gear
                { 9, 96516, 96888 },	-- Cha-Ye's Essence of Brilliance
                { 10, 96523, 96895 },	-- Delicate Vial of the Sanguinaire
                { 16, 96567 },	-- Chest of the Crackling Conqueror
                { 17, 96568 },	-- Chest of the Crackling Protector
                { 18, 96566 },	-- Chest of the Crackling Vanquisher
                { 20, 96518, 96890 },	-- Athame of the Sanguine Ritual
                { 21, 96514, 96886 },	-- Hand of the Dark Animus
                { 23, 94152, "pet1183" },	-- Son of Animus
                { 25, "ac8064" },
                { 26, "ac8081" },
            },
        },
        {	--ToTIronQon
            EncounterJournalID = 817,
            ContentPhaseMoP = 3,
            [NORMAL_DIFF] = {
                { 1, 94970, 96154 },	-- Quet'zal's Crackling Cord
                { 2, 94966, 96155 },	-- Saddle-Scarred Leggings
                { 3, 94968, 96156 },	-- Dam'ren's Frozen Footguards
                { 4, 94967, 96159 },	-- Spurs of the Storm Cavalry
                { 5, 94969, 96160 },	-- Ro'shak's Molten Chain
                { 6, 94972, 96161 },	-- Rein-Binder's Fists
                { 8, 95512, 96157 },	-- Ro'shak's Remembrance
                { 16, 95578 },	-- Shoulders of the Crackling Conqueror
                { 17, 95583 },	-- Shoulders of the Crackling Protector
                { 18, 95573 },	-- Shoulders of the Crackling Vanquisher
                { 20, 94971, 96152 },	-- Iron Qon's Boot Knife
                { 21, 94964, 96162 },	-- Qon's Flaming Scimitar
                { 22, 94963, 96153 },	-- Voice of the Quilen
                { 23, 94965, 96158 },	-- Orb of Arcing Lightning
                { 25, "ac8087" },
            },
            [HEROIC_DIFF] = {
                { 1, 96526, 96898 },	-- Quet'zal's Crackling Cord
                { 2, 96527, 96899 },	-- Saddle-Scarred Leggings
                { 3, 96528, 96900 },	-- Dam'ren's Frozen Footguards
                { 4, 96531, 96903 },	-- Spurs of the Storm Cavalry
                { 5, 96532, 96904 },	-- Ro'shak's Molten Chain
                { 6, 96533, 96905 },	-- Rein-Binder's Fists
                { 8, 96529, 96901 },	-- Ro'shak's Remembrance
                { 16, 96700 },	-- Shoulders of the Crackling Conqueror
                { 17, 96701 },	-- Shoulders of the Crackling Protector
                { 18, 96699 },	-- Shoulders of the Crackling Vanquisher
                { 20, 96524, 96896 },	-- Iron Qon's Boot Knife
                { 21, 96534, 96906 },	-- Qon's Flaming Scimitar
                { 22, 96525, 96897 },	-- Voice of the Quilen
                { 23, 96530, 96902 },	-- Orb of Arcing Lightning
                { 25, "ac8065" },
                { 26, "ac8087" },
            },
        },
        {	--ToTTwinConsorts
            EncounterJournalID = 829,
            ContentPhaseMoP = 3,
            [NORMAL_DIFF] = {
                { 1, 94977, 96164 },	-- Robes of the Moon Lotus
                { 2, 94979, 96168 },	-- Bracers of the Midnight Comet
                { 3, 94978, 96169 },	-- Girdle of Night and Day
                { 4, 94757, 96173 },	-- Fingers of the Night
                { 5, 94976, 96170 },	-- Tidal Force Treads
                { 7, 94981, 96172 },	-- Moonjade Necklace
                { 8, 94980, 96165 },	-- Passionfire Choker
                { 9, 94529, 96171 },	-- Gaze of the Twins
                { 16, 95577 },	-- Helm of the Crackling Conqueror
                { 17, 95582 },	-- Helm of the Crackling Protector
                { 18, 95571 },	-- Helm of the Crackling Vanquisher
                { 20, 94974, 96167 },	-- Suen-Wo, Spire of the Falling Sun
                { 21, 94973, 96163 },	-- Wu-Lai, Bladed Fan of the Consorts
                { 22, 95515, 96166 },	-- Shield of Twinned Despair
                { 24, "ac8086" },
            },
            [HEROIC_DIFF] = {
                { 1, 96536, 96908 },	-- Robes of the Moon Lotus
                { 2, 96540, 96912 },	-- Bracers of the Midnight Comet
                { 3, 96541, 96913 },	-- Girdle of Night and Day
                { 4, 96545, 96917 },	-- Fingers of the Night
                { 5, 96542, 96914 },	-- Tidal Force Treads
                { 7, 96544, 96916 },	-- Moonjade Necklace
                { 8, 96537, 96909 },	-- Passionfire Choker
                { 9, 96543, 96915 },	-- Gaze of the Twins
                { 16, 96624 },	-- Helm of the Crackling Conqueror
                { 17, 96625 },	-- Helm of the Crackling Protector
                { 18, 96623 },	-- Helm of the Crackling Vanquisher
                { 20, 96539, 96911 },	-- Suen-Wo, Spire of the Falling Sun
                { 21, 96535, 96907 },	-- Wu-Lai, Bladed Fan of the Consorts
                { 22, 96538, 96910 },	-- Shield of Twinned Despair
                { 24, "ac8066" },
                { 25, "ac8086" },
            },
        },
        {	--ToTLeiShen
            EncounterJournalID = 832,
            ContentPhaseMoP = 3,
            [NORMAL_DIFF] = {
                { 1, 94993, 96185 },	-- Gloves of the Maimed Vizier
                { 2, 94990, 96184 },	-- Legwraps of Cardinality
                { 3, 94987, 96176 },	-- Fusion Slasher Chestguard
                { 4, 94991, 96191 },	-- Grips of Slicing Electricity
                { 5, 94986, 96177 },	-- Conduit-Breaker Chain Leggings
                { 6, 94992, 96192 },	-- Leggings of the Violent Gale
                { 7, 94984, 96178 },	-- Doomed Crown of Lei Shen
                { 8, 94989, 96193 },	-- Lei Shen's Grounded Carapace
                { 9, 95535, 96179 },	-- Legplates of the Lightning Throne
                { 10, 94985, 96180 },	-- Legplates of Whipping Ionization
                { 12, 94867, [ATLASLOOT_IT_FILTERIGNORE] = true },	-- Heart of the Thunder King
                { 16, 94994, 96188 },	-- Soul Prism of Lei Shen
                { 17, 94530, 96189 },	-- Lightning-Imbued Chalice
                { 18, 94532, 96174 },	-- Rune of Re-Origination
                { 19, 94528, 96183 },	-- Soul Barrier
                { 20, 94524, 96186 },	-- Unerring Vision of Lei Shen
                { 22, 94983, 96175 },	-- Shan-Dun, Breaker of Hope
                { 23, 94988, 96187 },	-- Torall, Rod of the Shattered Throne
                { 24, 94982, 96181 },	-- Uroe, Harbinger of Terror
                { 25, 95472, 96182 },	-- Ultimate Protection of the Emperor
                { 26, 95473, 96190 },	-- Lei Shen's Orb of Command
                { 28, "ac8090" },
            },
            [HEROIC_DIFF] = {
                { 1, 96557, 96929 },	-- Gloves of the Maimed Vizier
                { 2, 96556, 96928 },	-- Legwraps of Cardinality
                { 3, 96548, 96920 },	-- Fusion Slasher Chestguard
                { 4, 96563, 96935 },	-- Grips of Slicing Electricity
                { 5, 96549, 96921 },	-- Conduit-Breaker Chain Leggings
                { 6, 96564, 96936 },	-- Leggings of the Violent Gale
                { 7, 96550, 96922 },	-- Doomed Crown of Lei Shen
                { 8, 96565, 96937 },	-- Lei Shen's Grounded Carapace
                { 9, 96551, 96923 },	-- Legplates of the Lightning Throne
                { 10, 96552, 96924 },	-- Legplates of Whipping Ionization
                { 12, 94867, [ATLASLOOT_IT_FILTERIGNORE] = true },	-- Heart of the Thunder King
                { 16, 96560, 96932 },	-- Soul Prism of Lei Shen
                { 17, 96561, 96933 },	-- Lightning-Imbued Chalice
                { 18, 96546, 96918 },	-- Rune of Re-Origination
                { 19, 96555, 96927 },	-- Soul Barrier
                { 20, 96558, 96930 },	-- Unerring Vision of Lei Shen
                { 22, 96547, 96919 },	-- Shan-Dun, Breaker of Hope
                { 23, 96559, 96931 },	-- Torall, Rod of the Shattered Throne
                { 24, 96553, 96925 },	-- Uroe, Harbinger of Terror
                { 25, 96554, 96926 },	-- Ultimate Protection of the Emperor
                { 26, 96562, 96934 },	-- Lei Shen's Orb of Command
                { 28, "ac8067" },
                { 29, "ac8090" },
            },
        },
        {	--ToTRaden
            EncounterJournalID = 831,
            ContentPhaseMoP = 3,
            [HEROIC_DIFF] = {
                { 1, 95013 },	-- Black Night Thundercloak
                { 2, 95015 },	-- Grey Wind Mistcloak
                { 3, 95014 },	-- Red Sky Cloudcloak
                { 4, 95016 },	-- White Snow Skycloak
                { 5, 95017 },	-- Yellow Dawn Lightningcloak
                { 6, 95040 },	-- Robes of Nova
                { 7, 95039 },	-- Starburner Robes
                { 8, 94995 },	-- Detonation Cord
                { 9, 94996 },	-- Vita-Binder Wrap
                { 10, 95030 },	-- Leggings of the Discarded Warning
                { 11, 95031 },	-- Legguards of Surreal Visions
                { 12, 95004 },	-- Starwalker Sandals
                { 13, 95005 },	-- Treads of Delicate Fascia
                { 14, 95033 },	-- Chestguard of Coruscating Blades
                { 15, 95032 },	-- Robes of Contagious Time
                { 16, 94998 },	-- Strap of Murderous Strikes
                { 17, 94997 },	-- Worldbender Waistband
                { 18, 95028 },	-- Cosmicfire Legwraps
                { 19, 95029 },	-- Kilt of Perpetual Genuflection
                { 20, 95006 },	-- Roots of Pain
                { 21, 95007 },	-- Twist-Toe Tabi
                { 22, 95035 },	-- Chains of Counted Souls
                { 23, 95034 },	-- Scales of Shaped Flesh
                { 24, 95000 },	-- Jingling Fetishgirdle
                { 25, 94999 },	-- Longdraw Chain Belt
                { 26, 95027 },	-- Legguards of Awaked Repair
                { 27, 95026 },	-- Sparkstring Chain Leggings
                { 28, 95009 },	-- Treads of the Sanguine Volley
                { 29, 95008 },	-- World-Mote Sabatons
                { 101, 95038 },	-- Carapace of the Core
                { 102, 95036 },	-- Nova-Binder Breastplate
                { 103, 95037 },	-- Planet-Birthed Cuirass
                { 104, 95001 },	-- Bubbling Anima Belt
                { 105, 95002 },	-- Cracklesnap Clasp
                { 106, 95003 },	-- Flare-Forged Greatbelt
                { 107, 95025 },	-- Archaic Protector's Legguards
                { 108, 95023 },	-- Legplates of Lightning Blood
                { 109, 95024 },	-- Time-Lost Greaves
                { 110, 95010 },	-- Hypersensitive Sollerets
                { 111, 95011 },	-- Lightning-Walker Clawfeet
                { 112, 95012 },	-- Sabatons of the Superior Being
                { 116, 95020 },	-- Ra-den's Contemplative Loop
                { 117, 95018 },	-- Ra-den's Evolving Signet
                { 118, 95022 },	-- Ra-den's Ruinous Ring
                { 119, 95019 },	-- Ra-den's Summoning Band
                { 120, 95021 },	-- Ra-den's Swift Seal
                { 122, "ac8068" },
            },
        },
        {	--ToTShared
            name = AL["Shared Boss Loot"],
            ExtraList = true,
            ContentPhaseMoP = 3,
            [NORMAL_DIFF] = {
                { 1, 95061, 96235 },	-- Lost Shoulders of Fire
                { 2, 95067, 96237 },	-- Lost Shoulders of Fluidity
                { 3, 95066, 96236 },	-- Lost Shoulders of Healing
                { 4, 95065, 96240 },	-- Forgotten Mantle of the Moon
                { 5, 95062, 96241 },	-- Forgotten Mantle of the Sun
                { 6, 95060, 96242 },	-- Abandoned Spaulders of Arrowflight
                { 7, 95064, 96243 },	-- Abandoned Spaulders of Renewal
                { 8, 95068, 96246 },	-- Reconstructed Bloody Shoulderplates
                { 9, 95063, 96245 },	-- Reconstructed Furious Shoulderplates
                { 10, 95069, 96244 },	-- Reconstructed Holy Shoulderplates
                { 16, 95498, 96249 },	-- Bo-Ris, Horror in the Night
                { 17, 95507, 96234 },	-- Darkwood Spiritstaff
                { 18, 95502, 96248 },	-- Do-tharak, the Swordbreaker
                { 19, 95501, 96232 },	-- Fyn's Flickering Dagger
                { 20, 95505, 96247 },	-- Greatsword of Frozen Hells
                { 21, 95499, 96230 },	-- Invocation of the Dawn
                { 22, 95500, 96239 },	-- Jerthud, Graceful Hand of the Savior
                { 23, 95503, 96231 },	-- Miracoran, the Vehement Chord
                { 24, 95506, 96238 },	-- Nadagast's Exsanguinator
                { 25, 97126, 97128 },	-- Tia-Tia, the Scything Star
                { 26, 95504, 96233 },	-- Zeeg's Ancient Kegsmasher
                { 27, 95516, 96250 },	-- Visage of the Doomed
            },
            [HEROIC_DIFF] = {
                { 1, 96607, 96979 },	-- Lost Shoulders of Fire
                { 2, 96609, 96981 },	-- Lost Shoulders of Fluidity
                { 3, 96608, 96980 },	-- Lost Shoulders of Healing
                { 4, 96612, 96984 },	-- Forgotten Mantle of the Moon
                { 5, 96613, 96985 },	-- Forgotten Mantle of the Sun
                { 6, 96614, 96986 },	-- Abandoned Spaulders of Arrowflight
                { 7, 96615, 96987 },	-- Abandoned Spaulders of Renewal
                { 8, 96618, 96990 },	-- Reconstructed Bloody Shoulderplates
                { 9, 96617, 96989 },	-- Reconstructed Furious Shoulderplates
                { 10, 96616, 96988 },	-- Reconstructed Holy Shoulderplates
                { 16, 96621, 96993 },	-- Bo-Ris, Horror in the Night
                { 17, 96606, 96978 },	-- Darkwood Spiritstaff
                { 18, 96620, 96992 },	-- Do-tharak, the Swordbreaker
                { 19, 96604, 96976 },	-- Fyn's Flickering Dagger
                { 20, 96619, 96991 },	-- Greatsword of Frozen Hells
                { 21, 96602, 96974 },	-- Invocation of the Dawn
                { 22, 96611, 96983 },	-- Jerthud, Graceful Hand of the Savior
                { 23, 96603, 96975 },	-- Miracoran, the Vehement Chord
                { 24, 96610, 96982 },	-- Nadagast's Exsanguinator
                { 25, 97127, 97130 },	-- Tia-Tia, the Scything Star
                { 26, 96605, 96977 },	-- Zeeg's Ancient Kegsmasher
                { 27, 96622, 96994 },	-- Visage of the Doomed
            },
        },
        {	--ToTTrash
            name = AL["Trash Mobs"],
            ExtraList = true,
            ContentPhaseMoP = 3,
            [NORMAL_DIFF] = {
                { 1, 95207, 96333 },	-- Abandoned Zandalari Firecord
                { 2, 95208, 96334 },	-- Abandoned Zandalari Shadowgirdle
                { 3, 95224, 96337 },	-- Home-Warding Slippers
                { 4, 95223, 96335 },	-- Silentflame Sandals
                { 5, 95210, 96343 },	-- Abandoned Zandalari Moonstrap
                { 6, 95209, 96342 },	-- Abandoned Zandalari Silentbelt
                { 7, 95221, 96338 },	-- Deeproot Treads
                { 8, 95219, 96331 },	-- Spiderweb Tabi
                { 9, 95211, 96344 },	-- Abandoned Zandalari Arrowlinks
                { 10, 95212, 96345 },	-- Abandoned Zandalari Waterchain
                { 11, 95220, 96332 },	-- Scalehide Spurs
                { 12, 95222, 96339 },	-- Spiritbound Boots
                { 13, 95215, 96348 },	-- Abandoned Zandalari Bucklebreaker
                { 14, 95214, 96347 },	-- Abandoned Zandalari Goreplate
                { 15, 95213, 96346 },	-- Abandoned Zandalari Greatbelt
                { 16, 95218, 96351 },	-- Columnbreaker Stompers
                { 17, 95217, 96350 },	-- Locksmasher Greaves
                { 18, 95216, 96340 },	-- Vaultwalker Sabatons
                { 20, 95202, 96330 },	-- Necklace of the Terra-Cotta Archer
                { 21, 95203, 96336 },	-- Necklace of the Terra-Cotta Invoker
                { 22, 95204, 96341 },	-- Necklace of the Terra-Cotta Mender
                { 23, 95206, 96352 },	-- Necklace of the Terra-Cotta Protector
                { 24, 95205, 96349 },	-- Necklace of the Terra-Cotta Vanquisher
                { 26, 94125, "pet1177" },	-- Living Sandling
                { 28, 98136 },	-- Gastropod Shell
            },
        },
        T15_SET,
        MOP_RAID2_AC_TABLE,
    }
}

data["SiegeofOrgrimmar"] = {
    EncounterJournalID = 369,
    InstanceID = 1136,
    ContentPhaseMoP = 5,
    MapID = 6738,
    ContentType = RAID_CONTENT,
    items = {
        {	--SoOImmerseus
            EncounterJournalID = 852,
            ContentPhaseMoP = 5,
            npcId = 71543,
            [CELESTIAL_DIFF] = {
                { 1, 104923 }, -- Cloak of Misguided Power
                { 2, 104922 }, -- Hood of Swirling Senses
                { 3, 104921 }, -- Ichor-Dripping Shoulderpads
                { 4, 104920 }, -- Bolt-Burster Grips
                { 5, 104911 }, -- Hood of Blackened Tears
                { 6, 104927 }, -- Bracers of Purified Spirit
                { 7, 104926 }, -- Salt Water Sandals
                { 8, 104928 }, -- Soul-Soaked Gloves
                { 9, 104912 }, -- Puddle Punishers
                { 10, 104918 }, -- Pauldrons of Violent Eruption
                { 11, 104914 }, -- Chestplate of Congealed Corrosion
                { 12, 104917 }, -- Bracers of Sordid Sleep
                { 13, 104913 }, -- Bubble-Burst Bracers
                { 14, 104915 }, -- Corruption-Rotted Gauntlets
                { 15, 104929 }, -- Greatbelt of Living Waters
                { 16, 104916 }, -- Treads of Unchained Hate
                { 17, 104930 }, -- Waterwalker Greatboots
                { 19, 104909 }, -- Immerseus' Crystalline Eye
                { 20, 104925 }, -- Seal of Eternal Sorrow
                { 21, 104924 }, -- Purified Bindings of Immerseus
                { 23, 104919 }, -- Encapsulated Essence of Immerseus
                { 24, 104910 }, -- Trident of Corrupted Waters
            },
            [NORMAL_DIFF] = {
                { 1, 103751 }, -- Hood of Swirling Senses
                { 2, 103755 }, -- Ichor-Dripping Shoulderpads
                { 3, 103752 }, -- Bolt-Burster Grips
                { 4, 103728 }, -- Hood of Blackened Tears
                { 5, 103757 }, -- Bracers of Purified Spirit
                { 6, 103760 }, -- Salt Water Sandals
                { 7, 103763 }, -- Soul-Soaked Gloves
                { 8, 103730 }, -- Puddle Punishers
                { 9, 103747 }, -- Pauldrons of Violent Eruption
                { 10, 103736 }, -- Chestplate of Congealed Corrosion
                { 11, 103741 }, -- Bracers of Sordid Sleep
                { 12, 103738 }, -- Bubble-Burst Bracers
                { 13, 103733 }, -- Corruption-Rotted Gauntlets
                { 14, 103966 }, -- Greatbelt of Living Waters
                { 16, 103744 }, -- Treads of Unchained Hate
                { 17, 103766 }, -- Waterwalker Greatboots
                { 19, 103749 }, -- Immerseus' Crystalline Eye
                { 20, 103771 }, -- Seal of Eternal Sorrow
                { 21, 102293 }, -- Purified Bindings of Immerseus
                { 23, 103727 }, -- Encapsulated Essence of Immerseus
                { 24, 103726 }, -- Trident of Corrupted Waters
                { 26, "ac8536" },
            },
            [HEROIC_DIFF] = {
                { 1, 104424 }, -- Hood of Swirling Senses
                { 2, 104423 }, -- Ichor-Dripping Shoulderpads
                { 3, 104422 }, -- Bolt-Burster Grips
                { 4, 104413 }, -- Hood of Blackened Tears
                { 5, 104429 }, -- Bracers of Purified Spirit
                { 6, 104428 }, -- Salt Water Sandals
                { 7, 104430 }, -- Soul-Soaked Gloves
                { 8, 104414 }, -- Puddle Punishers
                { 9, 104420 }, -- Pauldrons of Violent Eruption
                { 10, 104416 }, -- Chestplate of Congealed Corrosion
                { 11, 104419 }, -- Bracers of Sordid Sleep
                { 12, 104415 }, -- Bubble-Burst Bracers
                { 13, 104417 }, -- Corruption-Rotted Gauntlets
                { 14, 104431 }, -- Greatbelt of Living Waters
                { 16, 104418 }, -- Treads of Unchained Hate
                { 17, 104432 }, -- Waterwalker Greatboots
                { 19, 104411 }, -- Immerseus' Crystalline Eye
                { 20, 104427 }, -- Seal of Eternal Sorrow
                { 21, 104426 }, -- Purified Bindings of Immerseus
                { 23, 104421 }, -- Encapsulated Essence of Immerseus
                { 24, 104412 }, -- Trident of Corrupted Waters
                { 26, "ac8536" },
                { 27, "ac8463" },
            },
        },
        {	--SoOFallenProtectors
            EncounterJournalID = 849,
            ContentPhaseMoP = 5,
            npcId = 71475,
            [CELESTIAL_DIFF] = {
                { 1, 104939 }, -- Gloomwrap Greatcloak
                { 2, 104943 }, -- Shoulderpads of Dou Dou Chong
                { 3, 104942 }, -- Robes of the Tendered Heart
                { 4, 104944 }, -- Lifebane Bracers
                { 5, 104941 }, -- Sha-Seared Sandals
                { 6, 104947 }, -- Shoulders of the Roiling Inferno
                { 7, 104933 }, -- Stonetoe's Tormented Treads
                { 8, 104949 }, -- Shoulderguards of Dark Meditations
                { 9, 104934 }, -- Grips of Unending Anguish
                { 10, 104948 }, -- Sabatons of Defilement
                { 11, 104951 }, -- Gaze of Echoing Despair
                { 12, 104936 }, -- Darkfallen Shoulderplates
                { 13, 104950 }, -- Grips of the Fallen Council
                { 14, 104937 }, -- Shockstriker Gauntlets
                { 15, 104935 }, -- Poisonbinder Girth
                { 16, 104945 }, -- Petrified Pennyroyal Ring
                { 17, 104938 }, -- Sorrowpath Signet
                { 18, 104940 }, -- Rook's Unlucky Talisman
                { 20, 104931 }, -- Death Lotus Crossbow
                { 21, 104932 }, -- Softfoot's Last Resort
                { 22, 104946 }, -- Purehearted Cricket Cage
            },
            [NORMAL_DIFF] = {
                { 1, 103807 }, -- Shoulderpads of Dou Dou Chong
                { 2, 103802 }, -- Robes of the Tendered Heart
                { 3, 103809 }, -- Lifebane Bracers
                { 4, 103804 }, -- Sha-Seared Sandals
                { 5, 103924 }, -- Shoulders of the Roiling Inferno
                { 6, 103777 }, -- Stonetoe's Tormented Treads
                { 7, 103815 }, -- Shoulderguards of Dark Meditations
                { 8, 103780 }, -- Grips of Unending Anguish
                { 9, 103812 }, -- Sabatons of Defilement
                { 10, 103820 }, -- Gaze of Echoing Despair
                { 11, 103783 }, -- Darkfallen Shoulderplates
                { 12, 103817 }, -- Grips of the Fallen Council
                { 13, 103790 }, -- Shockstriker Gauntlets
                { 14, 103787 }, -- Poisonbinder Girth
                { 16, 103822 }, -- Petrified Pennyroyal Ring
                { 17, 103793 }, -- Sorrowpath Signet
                { 18, 102296 }, -- Rook's Unlucky Talisman
                { 20, 103776 }, -- Death Lotus Crossbow
                { 21, 103775 }, -- Softfoot's Last Resort
                { 22, 103801 }, -- Purehearted Cricket Cage
                { 24, "ac8528" },
            },
            [HEROIC_DIFF] = {
                { 1, 104445 }, -- Shoulderpads of Dou Dou Chong
                { 2, 104444 }, -- Robes of the Tendered Heart
                { 3, 104446 }, -- Lifebane Bracers
                { 4, 104443 }, -- Sha-Seared Sandals
                { 5, 104449 }, -- Shoulders of the Roiling Inferno
                { 6, 104435 }, -- Stonetoe's Tormented Treads
                { 7, 104451 }, -- Shoulderguards of Dark Meditations
                { 8, 104436 }, -- Grips of Unending Anguish
                { 9, 104450 }, -- Sabatons of Defilement
                { 10, 104453 }, -- Gaze of Echoing Despair
                { 11, 104438 }, -- Darkfallen Shoulderplates
                { 12, 104452 }, -- Grips of the Fallen Council
                { 13, 104439 }, -- Shockstriker Gauntlets
                { 14, 104437 }, -- Poisonbinder Girth
                { 16, 104447 }, -- Petrified Pennyroyal Ring
                { 17, 104440 }, -- Sorrowpath Signet
                { 18, 104442 }, -- Rook's Unlucky Talisman
                { 20, 104433 }, -- Death Lotus Crossbow
                { 21, 104434 }, -- Softfoot's Last Resort
                { 22, 104448 }, -- Purehearted Cricket Cage
                { 24, "ac8528" },
                { 25, "ac8465" },
            },
        },
        {	--SoONorushen
            EncounterJournalID = 866,
            ContentPhaseMoP = 5,
            npcId = 72276,
            [CELESTIAL_DIFF] = {
                { 1, 104960 }, -- Drape of the Despairing Pit
                { 2, 104966 }, -- Rime-Rift Shoulders
                { 3, 104963 }, -- Bracers of Broken Causation
                { 4, 104964 }, -- Blight Hurlers
                { 5, 104965 }, -- Sash of the Last Guardian
                { 6, 104954 }, -- Robes of the Blackened Watcher
                { 7, 104970 }, -- Confident Grips
                { 8, 104955 }, -- Gloves of the Golden Protector
                { 9, 104969 }, -- Boots of Broken Reliance
                { 10, 104957 }, -- Quarantine Shoulderguards
                { 11, 104971 }, -- Bracers of Final Serenity
                { 12, 104956 }, -- Leggings of Unabashed Anger
                { 13, 104972 }, -- Shadow-Binder's Kilt
                { 14, 104959 }, -- Rage-Blind Greathelm
                { 15, 104958 }, -- Bracers of Blind Hatred
                { 16, 104973 }, -- Wristplates of Broken Doubt
                { 18, 104967 }, -- Untainted Guardian's Chain
                { 19, 104953 }, -- Reality Ripper Ring
                { 20, 104961 }, -- Fusion-Fire Core
                { 22, 104952 }, -- Norushen's Shortblade
                { 23, 104962 }, -- Xifeng, Longblade of the Titanic Guardian
                { 24, 104968 }, -- Norushen's Enigmatic Barrier
            },
            [NORMAL_DIFF] = {
                { 1, 103857 }, -- Rime-Rift Shoulders
                { 2, 103849 }, -- Bracers of Broken Causation
                { 3, 103852 }, -- Blight Hurlers
                { 4, 103855 }, -- Sash of the Last Guardian
                { 5, 103834 }, -- Robes of the Blackened Watcher
                { 6, 103858 }, -- Confident Grips
                { 7, 103830 }, -- Gloves of the Golden Protector
                { 8, 103762 }, -- Boots of Broken Reliance
                { 9, 103836 }, -- Quarantine Shoulderguards
                { 10, 103861 }, -- Bracers of Final Serenity
                { 11, 103838 }, -- Leggings of Unabashed Anger
                { 12, 103942 }, -- Shadow-Binder's Kilt
                { 13, 103839 }, -- Rage-Blind Greathelm
                { 14, 103740 }, -- Bracers of Blind Hatred
                { 16, 103864 }, -- Wristplates of Broken Doubt
                { 18, 103867 }, -- Untainted Guardian's Chain
                { 19, 103841 }, -- Reality Ripper Ring
                { 20, 102295 }, -- Fusion-Fire Core
                { 22, 103827 }, -- Norushen's Shortblade
                { 23, 103826 }, -- Xifeng, Longblade of the Titanic Guardian
                { 24, 103847 }, -- Norushen's Enigmatic Barrier
                { 26, "ac8532" },
            },
            [HEROIC_DIFF] = {
                { 1, 104468 }, -- Rime-Rift Shoulders
                { 2, 104465 }, -- Bracers of Broken Causation
                { 3, 104466 }, -- Blight Hurlers
                { 4, 104467 }, -- Sash of the Last Guardian
                { 5, 104456 }, -- Robes of the Blackened Watcher
                { 6, 104472 }, -- Confident Grips
                { 7, 104457 }, -- Gloves of the Golden Protector
                { 8, 104471 }, -- Boots of Broken Reliance
                { 9, 104459 }, -- Quarantine Shoulderguards
                { 10, 104473 }, -- Bracers of Final Serenity
                { 11, 104458 }, -- Leggings of Unabashed Anger
                { 12, 104474 }, -- Shadow-Binder's Kilt
                { 13, 104461 }, -- Rage-Blind Greathelm
                { 14, 104460 }, -- Bracers of Blind Hatred
                { 16, 104475 }, -- Wristplates of Broken Doubt
                { 18, 104469 }, -- Untainted Guardian's Chain
                { 19, 104455 }, -- Reality Ripper Ring
                { 20, 104463 }, -- Fusion-Fire Core
                { 22, 104454 }, -- Norushen's Shortblade
                { 23, 104464 }, -- Xifeng, Longblade of the Titanic Guardian
                { 24, 104470 }, -- Norushen's Enigmatic Barrier
                { 26, "ac8532" },
                { 27, "ac8466" },
            },
        },
        {	--SoOShaofPride
            EncounterJournalID = 867,
            ContentPhaseMoP = 5,
            npcId = 71734,
            [CELESTIAL_DIFF] = {
                { 1, 104978 }, -- Self-Reflecting Mask
                { 2, 104979 }, -- Crown of Boastful Words
                { 3, 104980 }, -- Greaves of Sublime Superiority
                { 5, 104982 }, -- Choker of the Final Word
                { 6, 104975 }, -- Necklace of Fading Light
                { 7, 104974 }, -- Assurance of Consequence
                { 8, 104976 }, -- Prismatic Prison of Pride
                { 16, 99678 }, -- Chest of the Cursed Conqueror
                { 17, 99679 }, -- Chest of the Cursed Protector
                { 18, 99677 }, -- Chest of the Cursed Vanquisher
                { 20, 104977 }, -- Gaze of Arrogance
                { 21, 104981 }, -- Greatsword of Pride's Fall
                { 22, 104983 }, -- Shield of Mockery
            },
            [NORMAL_DIFF] = {
                { 1, 103876 }, -- Self-Reflecting Mask
                { 2, 103821 }, -- Crown of Boastful Words
                { 3, 103878 }, -- Greaves of Sublime Superiority
                { 5, 103883 }, -- Choker of the Final Word
                { 6, 103881 }, -- Necklace of Fading Light
                { 7, 102292 }, -- Assurance of Consequence
                { 8, 102299 }, -- Prismatic Prison of Pride
                { 16, 99686 }, -- Chest of the Cursed Conqueror
                { 17, 99691 }, -- Chest of the Cursed Protector
                { 18, 99696 }, -- Chest of the Cursed Vanquisher
                { 20, 103873 }, -- Gaze of Arrogance
                { 21, 103869 }, -- Greatsword of Pride's Fall
                { 22, 103870 }, -- Shield of Mockery
                { 24, 104162, "pet1331" }, -- Droplet of Y'Shaarj
                { 25, 104163, "pet1332" }, -- Gooey Sha-ling
                { 27, "ac8521" },
            },
            [HEROIC_DIFF] = {
                { 1, 104480 }, -- Self-Reflecting Mask
                { 2, 104481 }, -- Crown of Boastful Words
                { 3, 104482 }, -- Greaves of Sublime Superiority
                { 5, 104484 }, -- Choker of the Final Word
                { 6, 104477 }, -- Necklace of Fading Light
                { 7, 104476 }, -- Assurance of Consequence
                { 8, 104478 }, -- Prismatic Prison of Pride
                { 16, 99715 }, -- Chest of the Cursed Conqueror
                { 17, 99716 }, -- Chest of the Cursed Protector
                { 18, 99714 }, -- Chest of the Cursed Vanquisher
                { 20, 104479 }, -- Gaze of Arrogance
                { 21, 104483 }, -- Greatsword of Pride's Fall
                { 22, 104485 }, -- Shield of Mockery
                { 24, 104162, "pet1331" }, -- Droplet of Y'Shaarj
                { 25, 104163, "pet1332" }, -- Gooey Sha-ling
                { 27, "ac8521" },
                { 28, "ac8467" },
            },
        },
        {	--SoOGalakras
            EncounterJournalID = 868,
            ContentPhaseMoP = 5,
            npcId = 72249,
            [CELESTIAL_DIFF] = {
                { 1, 104997 }, -- Flameslinger's Fiery Cowl
                { 2, 104999 }, -- Shoulderpads of Pulsing Protection
                { 3, 104996 }, -- Scalebane Bracers
                { 4, 104995 }, -- Bone-Inlaid Sandals
                { 5, 104998 }, -- Skydancer Boots
                { 6, 104987 }, -- Korgra's Venom-Soaked Gauntlets
                { 7, 105002 }, -- Dragonmaw Emergency Strap
                { 8, 104986 }, -- Unrepentant Heels
                { 9, 104989 }, -- Dagryn's Fuselight Bracers
                { 10, 105003 }, -- Grips of Tidal Force
                { 11, 104988 }, -- Cannoneer's Multipocket Gunbelt
                { 12, 104990 }, -- Thranok's Shattering Helm
                { 13, 104992 }, -- Krugruk's Rigid Shoulderplates
                { 14, 104991 }, -- Arcsmasher Bracers
                { 15, 105004 }, -- Smoldering Drakescale Bracers
                { 16, 105005 }, -- Windfire Legplates
                { 18, 105000 }, -- Extinguished Ember of Galakras
                { 19, 104994 }, -- Galakrond Control Band
                { 20, 104985 }, -- Swift Serpent Signet
                { 21, 104993 }, -- Evil Eye of Galakras
                { 23, 104984 }, -- Dagryn's Discarded Longbow
                { 24, 105001 }, -- Drakebinder Greatstaff
            },
            [NORMAL_DIFF] = {
                { 1, 103900 }, -- Flameslinger's Fiery Cowl
                { 2, 103756 }, -- Shoulderpads of Pulsing Protection
                { 3, 103850 }, -- Scalebane Bracers
                { 4, 103805 }, -- Bone-Inlaid Sandals
                { 5, 103902 }, -- Skydancer Boots
                { 6, 103831 }, -- Korgra's Venom-Soaked Gauntlets
                { 7, 103905 }, -- Dragonmaw Emergency Strap
                { 8, 103778 }, -- Unrepentant Heels
                { 9, 103889 }, -- Dagryn's Fuselight Bracers
                { 10, 103765 }, -- Grips of Tidal Force
                { 11, 103887 }, -- Cannoneer's Multipocket Gunbelt
                { 12, 103892 }, -- Thranok's Shattering Helm
                { 13, 103748 }, -- Krugruk's Rigid Shoulderplates
                { 14, 103743 }, -- Arcsmasher Bracers
                { 15, 103865 }, -- Smoldering Drakescale Bracers
                { 16, 103907 }, -- Windfire Legplates
                { 18, 103823 }, -- Extinguished Ember of Galakras
                { 19, 103894 }, -- Galakrond Control Band
                { 20, 103842 }, -- Swift Serpent Signet
                { 21, 102298 }, -- Evil Eye of Galakras
                { 23, 103885 }, -- Dagryn's Discarded Longbow
                { 24, 103875 }, -- Drakebinder Greatstaff
                { 26, "ac8530" },
            },
            [HEROIC_DIFF] = {
                { 1, 104499 }, -- Flameslinger's Fiery Cowl
                { 2, 104501 }, -- Shoulderpads of Pulsing Protection
                { 3, 104498 }, -- Scalebane Bracers
                { 4, 104497 }, -- Bone-Inlaid Sandals
                { 5, 104500 }, -- Skydancer Boots
                { 6, 104489 }, -- Korgra's Venom-Soaked Gauntlets
                { 7, 104504 }, -- Dragonmaw Emergency Strap
                { 8, 104488 }, -- Unrepentant Heels
                { 9, 104491 }, -- Dagryn's Fuselight Bracers
                { 10, 104505 }, -- Grips of Tidal Force
                { 11, 104490 }, -- Cannoneer's Multipocket Gunbelt
                { 12, 104492 }, -- Thranok's Shattering Helm
                { 13, 104494 }, -- Krugruk's Rigid Shoulderplates
                { 14, 104493 }, -- Arcsmasher Bracers
                { 15, 104506 }, -- Smoldering Drakescale Bracers
                { 16, 104507 }, -- Windfire Legplates
                { 18, 104502 }, -- Extinguished Ember of Galakras
                { 19, 104496 }, -- Galakrond Control Band
                { 20, 104487 }, -- Swift Serpent Signet
                { 21, 104495 }, -- Evil Eye of Galakras
                { 23, 104486 }, -- Dagryn's Discarded Longbow
                { 24, 104503 }, -- Drakebinder Greatstaff
                { 26, "ac8530" },
                { 27, "ac8468" },
            },
        },
        {	--SoOIronJuggernaut
            EncounterJournalID = 864,
            ContentPhaseMoP = 5,
            npcId = 71466,
            [CELESTIAL_DIFF] = {
                { 1, 105021 }, -- Shock Pulse Robes
                { 2, 105019 }, -- Bracers of the Broken Fault
                { 3, 105020 }, -- Earthripper Gloves
                { 4, 105017 }, -- Belt of Ominous Trembles
                { 5, 105018 }, -- Leggings of Furious Flame
                { 6, 105008 }, -- Ricocheting Shoulderguards
                { 7, 105024 }, -- Castlebreaker Bracers
                { 8, 105007 }, -- Laser Burn Bracers
                { 9, 105026 }, -- Cavemaker Wristguards
                { 10, 105010 }, -- Precision Cutters
                { 11, 105009 }, -- Minelayer's Padded Boots
                { 12, 105025 }, -- Treads of Autonomic Motion
                { 13, 105014 }, -- Earthbreaker's Steaming Chestplate
                { 14, 105012 }, -- Wall-Borer Bracers
                { 15, 105013 }, -- Tar-Coated Gauntlets
                { 16, 105011 }, -- Demolisher's Reinforced Belt
                { 17, 105027 }, -- Borer Drill Boots
                { 19, 105015 }, -- Juggernaut's Ignition Keys
                { 20, 105022 }, -- Laser-Slice Signet
                { 21, 105016 }, -- Juggernaut's Focusing Crystal
                { 23, 105006 }, -- Seismic Bore
                { 24, 105023 }, -- Juggernaut's Power Core
            },
            [NORMAL_DIFF] = {
                { 1, 103922 }, -- Shock Pulse Robes
                { 2, 103811 }, -- Bracers of the Broken Fault
                { 3, 103754 }, -- Earthripper Gloves
                { 4, 103898 }, -- Belt of Ominous Trembles
                { 5, 103921 }, -- Leggings of Furious Flame
                { 6, 103912 }, -- Ricocheting Shoulderguards
                { 7, 103759 }, -- Castlebreaker Bracers
                { 8, 103909 }, -- Laser Burn Bracers
                { 9, 103863 }, -- Cavemaker Wristguards
                { 10, 103782 }, -- Precision Cutters
                { 11, 103731 }, -- Minelayer's Padded Boots
                { 12, 103813 }, -- Treads of Autonomic Motion
                { 13, 103914 }, -- Earthbreaker's Steaming Chestplate
                { 14, 103739 }, -- Wall-Borer Bracers
                { 15, 103735 }, -- Tar-Coated Gauntlets
                { 16, 103788 }, -- Demolisher's Reinforced Belt
                { 17, 103767 }, -- Borer Drill Boots
                { 19, 103916 }, -- Juggernaut's Ignition Keys
                { 20, 103773 }, -- Laser-Slice Signet
                { 21, 102297 }, -- Juggernaut's Focusing Crystal
                { 23, 103908 }, -- Seismic Bore
                { 24, 103918 }, -- Juggernaut's Power Core
                { 26, "ac8520" },
            },
            [HEROIC_DIFF] = {
                { 1, 104523 }, -- Shock Pulse Robes
                { 2, 104521 }, -- Bracers of the Broken Fault
                { 3, 104522 }, -- Earthripper Gloves
                { 4, 104519 }, -- Belt of Ominous Trembles
                { 5, 104520 }, -- Leggings of Furious Flame
                { 6, 104510 }, -- Ricocheting Shoulderguards
                { 7, 104526 }, -- Castlebreaker Bracers
                { 8, 104509 }, -- Laser Burn Bracers
                { 9, 104528 }, -- Cavemaker Wristguards
                { 10, 104512 }, -- Precision Cutters
                { 11, 104511 }, -- Minelayer's Padded Boots
                { 12, 104527 }, -- Treads of Autonomic Motion
                { 13, 104516 }, -- Earthbreaker's Steaming Chestplate
                { 14, 104514 }, -- Wall-Borer Bracers
                { 15, 104515 }, -- Tar-Coated Gauntlets
                { 16, 104513 }, -- Demolisher's Reinforced Belt
                { 17, 104529 }, -- Borer Drill Boots
                { 19, 104517 }, -- Juggernaut's Ignition Keys
                { 20, 104524 }, -- Laser-Slice Signet
                { 21, 104518 }, -- Juggernaut's Focusing Crystal
                { 23, 104508 }, -- Seismic Bore
                { 24, 104525 }, -- Juggernaut's Power Core
                { 26, "ac8520" },
                { 27, "ac8469" },
            },
        },
        {	--SoODarkShaman
            EncounterJournalID = 856,
            ContentPhaseMoP = 5,
            npcId = 71859,
            [CELESTIAL_DIFF] = {
                { 1, 105028 }, -- Poisonmist Nightcloak
                { 2, 105040 }, -- Iron Wolf Hood
                { 3, 105039 }, -- Toxic Tornado Treads
                { 4, 105044 }, -- Darkfang Mask
                { 5, 105030 }, -- Damron's Belt of Darkness
                { 6, 105031 }, -- Riou's Vigilant Leggings
                { 7, 105032 }, -- Haromm's Horrifying Helm
                { 8, 105046 }, -- Shoulderguards of Foul Streams
                { 9, 105045 }, -- Belt of the Iron Prison
                { 10, 105048 }, -- Shoulderplates of Gushing Geysers
                { 11, 105034 }, -- Breastplate of Shamanic Mirrors
                { 12, 105047 }, -- Shackles of Stinking Slime
                { 13, 105035 }, -- Ashen Wall Girdle
                { 14, 105033 }, -- Wolf-Rider Spurs
                { 16, 105041 }, -- Ashflare Pendant
                { 17, 105036 }, -- Bloodclaw Band
                { 18, 105038 }, -- Ring of the Iron Tomb
                { 19, 105029 }, -- Haromm's Talisman
                { 20, 105042 }, -- Kardris' Toxic Totem
                { 22, 105037 }, -- Haromm's Frozen Crescent
                { 23, 105043 }, -- Kardris' Scepter
            },
            [NORMAL_DIFF] = {
                { 1, 103938 }, -- Iron Wolf Hood
                { 2, 103806 }, -- Toxic Tornado Treads
                { 3, 103877 }, -- Darkfang Mask
                { 4, 103927 }, -- Damron's Belt of Darkness
                { 5, 103929 }, -- Riou's Vigilant Leggings
                { 6, 103930 }, -- Haromm's Horrifying Helm
                { 7, 103816 }, -- Shoulderguards of Foul Streams
                { 8, 103940 }, -- Belt of the Iron Prison
                { 9, 103943 }, -- Shoulderplates of Gushing Geysers
                { 10, 103737 }, -- Breastplate of Shamanic Mirrors
                { 11, 103866 }, -- Shackles of Stinking Slime
                { 12, 103932 }, -- Ashen Wall Girdle
                { 13, 103880 }, -- Wolf-Rider Spurs
                { 16, 103868 }, -- Ashflare Pendant
                { 17, 103798 }, -- Bloodclaw Band
                { 18, 103895 }, -- Ring of the Iron Tomb
                { 19, 102301 }, -- Haromm's Talisman
                { 20, 102300 }, -- Kardris' Toxic Totem
                { 22, 103926 }, -- Haromm's Frozen Crescent
                { 23, 103936 }, -- Kardris' Scepter
                { 25, "ac8453" },
            },
            [HEROIC_DIFF] = {
                { 1, 104542 }, -- Iron Wolf Hood
                { 2, 104541 }, -- Toxic Tornado Treads
                { 3, 104546 }, -- Darkfang Mask
                { 4, 104532 }, -- Damron's Belt of Darkness
                { 5, 104533 }, -- Riou's Vigilant Leggings
                { 6, 104534 }, -- Haromm's Horrifying Helm
                { 7, 104548 }, -- Shoulderguards of Foul Streams
                { 8, 104547 }, -- Belt of the Iron Prison
                { 9, 104550 }, -- Shoulderplates of Gushing Geysers
                { 10, 104536 }, -- Breastplate of Shamanic Mirrors
                { 11, 104549 }, -- Shackles of Stinking Slime
                { 12, 104537 }, -- Ashen Wall Girdle
                { 13, 104535 }, -- Wolf-Rider Spurs
                { 16, 104543 }, -- Ashflare Pendant
                { 17, 104538 }, -- Bloodclaw Band
                { 18, 104540 }, -- Ring of the Iron Tomb
                { 19, 104531 }, -- Haromm's Talisman
                { 20, 104544 }, -- Kardris' Toxic Totem
                { 22, 104539 }, -- Haromm's Frozen Crescent
                { 23, 104545 }, -- Kardris' Scepter
                { 25, "ac8453" },
                { 26, "ac8470" },
            },
        },
        {	--SoONazgrim
            EncounterJournalID = 850,
            ContentPhaseMoP = 5,
            npcId = 71515,
            [CELESTIAL_DIFF] = {
                { 1, 105059 }, -- Spaulders of Kor'kron Fealty
                { 2, 105050 }, -- Sandals of Two Little Bees
                { 3, 105053 }, -- Shoulderguards of the Righteous Stand
                { 4, 105054 }, -- Robes of the Warrior's Fall
                { 5, 105056 }, -- Crown of Tragic Truth
                { 6, 105055 }, -- Ravager's Pathwalkers
                { 8, 105051 }, -- Nazgrim's Burnished Insignia
                { 16, 99681 }, -- Gauntlets of the Cursed Conqueror
                { 17, 99667 }, -- Gauntlets of the Cursed Protector
                { 18, 99680 }, -- Gauntlets of the Cursed Vanquisher
                { 20, 105052 }, -- Arcweaver Spell Sword
                { 21, 105057 }, -- Gar'tok, Strength of the Faithful
                { 22, 105049 }, -- Nazgrim's Gutripper
                { 23, 105058 }, -- Bulwark of the Fallen General
            },
            [NORMAL_DIFF] = {
                { 1, 103808 }, -- Spaulders of Kor'kron Fealty
                { 2, 103904 }, -- Sandals of Two Little Bees
                { 3, 103913 }, -- Shoulderguards of the Righteous Stand
                { 4, 103947 }, -- Robes of the Warrior's Fall
                { 5, 103949 }, -- Crown of Tragic Truth
                { 6, 103732 }, -- Ravager's Pathwalkers
                { 8, 102294 }, -- Nazgrim's Burnished Insignia
                { 16, 99687 }, -- Gauntlets of the Cursed Conqueror
                { 17, 99692 }, -- Gauntlets of the Cursed Protector
                { 18, 99682 }, -- Gauntlets of the Cursed Vanquisher
                { 20, 103946 }, -- Arcweaver Spell Sword
                { 21, 103945 }, -- Gar'tok, Strength of the Faithful
                { 22, 103829 }, -- Nazgrim's Gutripper
                { 23, 103872 }, -- Bulwark of the Fallen General
                { 25, "ac8448" },
            },
            [HEROIC_DIFF] = {
                { 1, 104561 }, -- Spaulders of Kor'kron Fealty
                { 2, 104552 }, -- Sandals of Two Little Bees
                { 3, 104555 }, -- Shoulderguards of the Righteous Stand
                { 4, 104556 }, -- Robes of the Warrior's Fall
                { 5, 104558 }, -- Crown of Tragic Truth
                { 6, 104557 }, -- Ravager's Pathwalkers
                { 8, 104553 }, -- Nazgrim's Burnished Insignia
                { 16, 99721 }, -- Gauntlets of the Cursed Conqueror
                { 17, 99722 }, -- Gauntlets of the Cursed Protector
                { 18, 99720 }, -- Gauntlets of the Cursed Vanquisher
                { 20, 104554 }, -- Arcweaver Spell Sword
                { 21, 104559 }, -- Gar'tok, Strength of the Faithful
                { 22, 104551 }, -- Nazgrim's Gutripper
                { 23, 104560 }, -- Bulwark of the Fallen General
                { 25, "ac8448" },
                { 26, "ac8471" },
            },
        },
        {	--SoOMalkorok
            EncounterJournalID = 846,
            ContentPhaseMoP = 5,
            npcId = 71454,
            [CELESTIAL_DIFF] = {
                { 1, 105075 }, -- Black-Blooded Drape
                { 2, 105072 }, -- Hood of Perpetual Implosion
                { 3, 105073 }, -- Robes of Riven Dreams
                { 4, 105071 }, -- Miasmic Skullbelt
                { 5, 105063 }, -- Lazahk's Lost Shadowrap
                { 6, 105079 }, -- Bracers of Averted Fatality
                { 7, 105078 }, -- Boots of Perilous Infusion
                { 8, 105080 }, -- Ebon Blood Chestguard
                { 9, 105064 }, -- Wristguards of Ruination
                { 10, 105081 }, -- Terrorguard Chestplate
                { 11, 105066 }, -- Blood Rage Bracers
                { 12, 105067 }, -- Legplates of Willful Doom
                { 13, 105065 }, -- Malkorok's Giant Stompers
                { 16, 105068 }, -- Malkorok's Tainted Dog Tags
                { 17, 105060 }, -- Ring of Restless Energy
                { 18, 105076 }, -- Seal of Sullen Fury
                { 19, 105074 }, -- Frenzied Crystal of Rage
                { 20, 105070 }, -- Vial of Living Corruption
                { 22, 105062 }, -- Halberd of Inner Shadows
                { 23, 105061 }, -- Kor'kron Hand Cannon
                { 24, 105069 }, -- Malkorok's Skullcleaver
                { 25, 105077 }, -- Visage of the Monstrous
            },
            [NORMAL_DIFF] = {
                { 1, 103939 }, -- Hood of Perpetual Implosion
                { 2, 103923 }, -- Robes of Riven Dreams
                { 3, 103899 }, -- Miasmic Skullbelt
                { 4, 103835 }, -- Lazahk's Lost Shadowrap
                { 5, 103758 }, -- Bracers of Averted Fatality
                { 6, 103761 }, -- Boots of Perilous Infusion
                { 7, 103955 }, -- Ebon Blood Chestguard
                { 8, 103890 }, -- Wristguards of Ruination
                { 9, 103957 }, -- Terrorguard Chestplate
                { 10, 103742 }, -- Blood Rage Bracers
                { 11, 103954 }, -- Legplates of Willful Doom
                { 12, 103879 }, -- Malkorok's Giant Stompers
                { 16, 103917 }, -- Malkorok's Tainted Dog Tags
                { 17, 103843 }, -- Ring of Restless Energy
                { 18, 103772 }, -- Seal of Sullen Fury
                { 19, 102303 }, -- Frenzied Crystal of Rage
                { 20, 102306 }, -- Vial of Living Corruption
                { 22, 103952 }, -- Halberd of Inner Shadows
                { 23, 103953 }, -- Kor'kron Hand Cannon
                { 24, 103951 }, -- Malkorok's Skullcleaver
                { 25, 103848 }, -- Visage of the Monstrous
                { 27, "ac8538" },
            },
            [HEROIC_DIFF] = {
                { 1, 104574 }, -- Hood of Perpetual Implosion
                { 2, 104575 }, -- Robes of Riven Dreams
                { 3, 104573 }, -- Miasmic Skullbelt
                { 4, 104565 }, -- Lazahk's Lost Shadowrap
                { 5, 104581 }, -- Bracers of Averted Fatality
                { 6, 104580 }, -- Boots of Perilous Infusion
                { 7, 104582 }, -- Ebon Blood Chestguard
                { 8, 104566 }, -- Wristguards of Ruination
                { 9, 104583 }, -- Terrorguard Chestplate
                { 10, 104568 }, -- Blood Rage Bracers
                { 11, 104569 }, -- Legplates of Willful Doom
                { 12, 104567 }, -- Malkorok's Giant Stompers
                { 16, 104570 }, -- Malkorok's Tainted Dog Tags
                { 17, 104562 }, -- Ring of Restless Energy
                { 18, 104578 }, -- Seal of Sullen Fury
                { 19, 104576 }, -- Frenzied Crystal of Rage
                { 20, 104572 }, -- Vial of Living Corruption
                { 22, 104564 }, -- Halberd of Inner Shadows
                { 23, 104563 }, -- Kor'kron Hand Cannon
                { 24, 104571 }, -- Malkorok's Skullcleaver
                { 25, 104579 }, -- Visage of the Monstrous
                { 27, "ac8538" },
                { 28, "ac8472" },
            },
        },
        {	--SoOSpoils
            EncounterJournalID = 870,
            ContentPhaseMoP = 5,
            npcId = 71889,
                        -- "Spoils",
            [CELESTIAL_DIFF] = {
                { 1, 105094 }, -- Mantid Vizier's Robes
                { 2, 105093 }, -- Avool's Ancestral Bracers
                { 3, 105085 }, -- Mantid Carapace Augments
                { 4, 105097 }, -- Klaxxi Grips of Rejuvenation
                { 5, 105098 }, -- Shado-Pan Reliquary Kilt
                { 6, 105084 }, -- Pandaren Roofsprinters
                { 7, 105087 }, -- Ancient Archer's Chestguard
                { 8, 105100 }, -- Bracers of the Pristine Purifier
                { 9, 105086 }, -- Arrowflight Girdle
                { 10, 105099 }, -- Chitin-Link Chain Belt
                { 11, 105088 }, -- Helm of the Night Watchman
                { 12, 105101 }, -- Plate Belt of the War-Healer
                { 13, 105089 }, -- Untarnishable Greatbelt
                { 14, 105102 }, -- Mogu Mindbender's Greaves
                { 15, 105090 }, -- Ominous Mogu Greatboots
                { 16, 105095 }, -- Lost Necklace of the Mogu Empress
                { 17, 105091 }, -- Seal of the Forgotten Kings
                { 18, 105082 }, -- Sigil of Rampage
                { 20, 105083 }, -- Enchanted Shao-Tien Saber
                { 21, 105096 }, -- Immaculately Preserved Wand
                { 22, 105092 }, -- Ancient Mogu Tower Shield
            },
            [NORMAL_DIFF] = {
                { 1, 103803 }, -- Mantid Vizier's Robes
                { 2, 103851 }, -- Avool's Ancestral Bracers
                { 3, 103911 }, -- Mantid Carapace Augments
                { 4, 103860 }, -- Klaxxi Grips of Rejuvenation
                { 5, 103967 }, -- Shado-Pan Reliquary Kilt
                { 6, 103779 }, -- Pandaren Roofsprinters
                { 7, 103962 }, -- Ancient Archer's Chestguard
                { 8, 103862 }, -- Bracers of the Pristine Purifier
                { 9, 103888 }, -- Arrowflight Girdle
                { 10, 103941 }, -- Chitin-Link Chain Belt
                { 11, 103893 }, -- Helm of the Night Watchman
                { 12, 103965 }, -- Plate Belt of the War-Healer
                { 13, 103933 }, -- Untarnishable Greatbelt
                { 14, 103768 }, -- Mogu Mindbender's Greaves
                { 15, 103745 }, -- Ominous Mogu Greatboots
                { 16, 103882 }, -- Lost Necklace of the Mogu Empress
                { 17, 103796 }, -- Seal of the Forgotten Kings
                { 18, 102302 }, -- Sigil of Rampage
                { 20, 103961 }, -- Enchanted Shao-Tien Saber
                { 21, 103964 }, -- Immaculately Preserved Wand
                { 22, 103871 }, -- Ancient Mogu Tower Shield
                { 24, "ac8529" },
            },
            [HEROIC_DIFF] = {
                { 1, 104596 }, -- Mantid Vizier's Robes
                { 2, 104595 }, -- Avool's Ancestral Bracers
                { 3, 104587 }, -- Mantid Carapace Augments
                { 4, 104599 }, -- Klaxxi Grips of Rejuvenation
                { 5, 104600 }, -- Shado-Pan Reliquary Kilt
                { 6, 104586 }, -- Pandaren Roofsprinters
                { 7, 104589 }, -- Ancient Archer's Chestguard
                { 8, 104602 }, -- Bracers of the Pristine Purifier
                { 9, 104588 }, -- Arrowflight Girdle
                { 10, 104601 }, -- Chitin-Link Chain Belt
                { 11, 104590 }, -- Helm of the Night Watchman
                { 12, 104603 }, -- Plate Belt of the War-Healer
                { 13, 104591 }, -- Untarnishable Greatbelt
                { 14, 104604 }, -- Mogu Mindbender's Greaves
                { 15, 104592 }, -- Ominous Mogu Greatboots
                { 16, 104597 }, -- Lost Necklace of the Mogu Empress
                { 17, 104593 }, -- Seal of the Forgotten Kings
                { 18, 104584 }, -- Sigil of Rampage
                { 20, 104585 }, -- Enchanted Shao-Tien Saber
                { 21, 104598 }, -- Immaculately Preserved Wand
                { 22, 104594 }, -- Ancient Mogu Tower Shield
                { 24, "ac8529" },
                { 25, "ac8478" },
            },
        },
        {	--SoOThok
            EncounterJournalID = 851,
            ContentPhaseMoP = 5,
            npcId = 71529,
            [CELESTIAL_DIFF] = {
                { 1, 105106 }, -- Akolik's Acid-Soaked Robes
                { 2, 105105 }, -- Montak's Grips of Scorching Breath
                { 3, 105110 }, -- Icy Blood Chestplate
                { 5, 105104 }, -- Gleaming Eye of the Devilsaur
                { 6, 105113 }, -- Devilfang Band
                { 7, 105108 }, -- Signet of the Dinomancers
                { 8, 105109 }, -- Thok's Acid-Grooved Tooth
                { 9, 105111 }, -- Thok's Tail Tip
                { 16, 99672 }, -- Helm of the Cursed Conqueror
                { 17, 99673 }, -- Helm of the Cursed Protector
                { 18, 99671 }, -- Helm of the Cursed Vanquisher
                { 20, 105112 }, -- Britomart's Jagged Pike
                { 21, 105103 }, -- Hvitserk's Formidable Shanker
                { 22, 105107 }, -- Festering Primordial Globule
            },
            [NORMAL_DIFF] = {
                { 1, 104308 }, -- Akolik's Acid-Soaked Robes
                { 2, 103853 }, -- Montak's Grips of Scorching Breath
                { 3, 103915 }, -- Icy Blood Chestplate
                { 5, 103750 }, -- Gleaming Eye of the Devilsaur
                { 6, 103896 }, -- Devilfang Band
                { 7, 103774 }, -- Signet of the Dinomancers
                { 8, 102304 }, -- Thok's Acid-Grooved Tooth
                { 9, 102305 }, -- Thok's Tail Tip
                { 16, 99689 }, -- Helm of the Cursed Conqueror
                { 17, 99694 }, -- Helm of the Cursed Protector
                { 18, 99683 }, -- Helm of the Cursed Vanquisher
                { 20, 103968 }, -- Britomart's Jagged Pike
                { 21, 103828 }, -- Hvitserk's Formidable Shanker
                { 22, 103919 }, -- Festering Primordial Globule
                { 24, "ac8527" },
            },
            [HEROIC_DIFF] = {
                { 1, 104608 }, -- Akolik's Acid-Soaked Robes
                { 2, 104607 }, -- Montak's Grips of Scorching Breath
                { 3, 104612 }, -- Icy Blood Chestplate
                { 5, 104606 }, -- Gleaming Eye of the Devilsaur
                { 6, 104615 }, -- Devilfang Band
                { 7, 104610 }, -- Signet of the Dinomancers
                { 8, 104611 }, -- Thok's Acid-Grooved Tooth
                { 9, 104613 }, -- Thok's Tail Tip
                { 16, 99724 }, -- Helm of the Cursed Conqueror
                { 17, 99725 }, -- Helm of the Cursed Protector
                { 18, 99723 }, -- Helm of the Cursed Vanquisher
                { 20, 104614 }, -- Britomart's Jagged Pike
                { 21, 104605 }, -- Hvitserk's Formidable Shanker
                { 22, 104609 }, -- Festering Primordial Globule
                { 24, "ac8527" },
                { 25, "ac8479" },
            },
        },
        {	--SoOBlackfuse
            EncounterJournalID = 865,
            ContentPhaseMoP = 5,
            npcId = 71504,
            [CELESTIAL_DIFF] = {
                { 1, 105115 }, -- Fusespark Gloves
                { 2, 105118 }, -- Bomber's Blackened Wristwatch
                { 3, 105119 }, -- Bracers of Infinite Pipes
                { 4, 105120 }, -- Powder-Stained Totemic Treads
                { 5, 105121 }, -- Calixian Bladebreakers
                { 7, 105124 }, -- Blackfuse's Blasting Cord
                { 8, 105122 }, -- Asgorathian Blood Seal
                { 9, 105117 }, -- Dysmorphic Samophlange of Discontinuity
                { 10, 105114 }, -- Ticking Ebon Detonator
                { 16, 99669 }, -- Shoulders of the Cursed Conqueror
                { 17, 99670 }, -- Shoulders of the Cursed Protector
                { 18, 99668 }, -- Shoulders of the Cursed Vanquisher
                { 20, 105116 }, -- Lever of the Megantholithic Apparatus
                { 21, 105123 }, -- Siegecrafter's Forge Hammer
            },
            [NORMAL_DIFF] = {
                { 1, 103970 }, -- Fusespark Gloves
                { 2, 103910 }, -- Bomber's Blackened Wristwatch
                { 3, 103891 }, -- Bracers of Infinite Pipes
                { 4, 103814 }, -- Powder-Stained Totemic Treads
                { 5, 103792 }, -- Calixian Bladebreakers
                { 7, 103884 }, -- Blackfuse's Blasting Cord
                { 8, 103794 }, -- Asgorathian Blood Seal
                { 9, 102309 }, -- Dysmorphic Samophlange of Discontinuity
                { 10, 102311 }, -- Ticking Ebon Detonator
                { 16, 99690 }, -- Shoulders of the Cursed Conqueror
                { 17, 99695 }, -- Shoulders of the Cursed Protector
                { 18, 99685 }, -- Shoulders of the Cursed Vanquisher
                { 20, 103874 }, -- Lever of the Megantholithic Apparatus
                { 21, 103969 }, -- Siegecrafter's Forge Hammer
                { 23, 104158, "pet1322" }, -- Blackfuse Bombling
                { 25, "ac8543" },
            },
            [HEROIC_DIFF] = {
                { 1, 104617 }, -- Fusespark Gloves
                { 2, 104620 }, -- Bomber's Blackened Wristwatch
                { 3, 104621 }, -- Bracers of Infinite Pipes
                { 4, 104622 }, -- Powder-Stained Totemic Treads
                { 5, 104623 }, -- Calixian Bladebreakers
                { 7, 104626 }, -- Blackfuse's Blasting Cord
                { 8, 104624 }, -- Asgorathian Blood Seal
                { 9, 104619 }, -- Dysmorphic Samophlange of Discontinuity
                { 10, 104616 }, -- Ticking Ebon Detonator
                { 16, 99718 }, -- Shoulders of the Cursed Conqueror
                { 17, 99719 }, -- Shoulders of the Cursed Protector
                { 18, 99717 }, -- Shoulders of the Cursed Vanquisher
                { 20, 104618 }, -- Lever of the Megantholithic Apparatus
                { 21, 104625 }, -- Siegecrafter's Forge Hammer
                { 23, 104158, "pet1322" }, -- Blackfuse Bombling
                { 25, "ac8543" },
                { 26, "ac8480" },
            },
        },
        {	--SoOParagons
            EncounterJournalID = 853,
            ContentPhaseMoP = 5,
            npcId = 71161,
            [CELESTIAL_DIFF] = {
                { 1, 105128 }, -- Bracers of Sonic Projection
                { 2, 105131 }, -- Amber Parasite Wraps
                { 3, 105132 }, -- Chestguard of Toxic Injections
                { 4, 105133 }, -- Gauntlets of Insane Calculations
                { 6, 105130 }, -- Iyyokuk's Hereditary Seal
                { 7, 105126 }, -- Kil'ruk's Band of Ascendancy
                { 8, 105134 }, -- Skeer's Bloodsoaked Talisman
                { 16, 99675 }, -- Leggings of the Cursed Conqueror
                { 17, 99676 }, -- Leggings of the Cursed Protector
                { 18, 99674 }, -- Leggings of the Cursed Vanquisher
                { 20, 105125 }, -- Hisek's Reserve Longbow
                { 21, 105135 }, -- Kil'ruk's Furious Blade
                { 22, 105127 }, -- Korven's Crimson Crescent
                { 23, 105129 }, -- Rik'kal's Bloody Scalpel
            },
            [NORMAL_DIFF] = {
                { 1, 103810 }, -- Bracers of Sonic Projection
                { 2, 103948 }, -- Amber Parasite Wraps
                { 3, 103956 }, -- Chestguard of Toxic Injections
                { 4, 103819 }, -- Gauntlets of Insane Calculations
                { 6, 103824 }, -- Iyyokuk's Hereditary Seal
                { 7, 103844 }, -- Kil'ruk's Band of Ascendancy
                { 8, 102308 }, -- Skeer's Bloodsoaked Talisman
                { 16, 99688 }, -- Leggings of the Cursed Conqueror
                { 17, 99693 }, -- Leggings of the Cursed Protector
                { 18, 99684 }, -- Leggings of the Cursed Vanquisher
                { 20, 103886 }, -- Hisek's Reserve Longbow
                { 21, 103972 }, -- Kil'ruk's Furious Blade
                { 22, 103971 }, -- Korven's Crimson Crescent
                { 23, 103973 }, -- Rik'kal's Bloody Scalpel
                { 25, 104165, "pet1334"  }, -- Kovok
                { 27, "ac8531" },
            },
            [HEROIC_DIFF] = {
                { 1, 104630 }, -- Bracers of Sonic Projection
                { 2, 104633 }, -- Amber Parasite Wraps
                { 3, 104634 }, -- Chestguard of Toxic Injections
                { 4, 104635 }, -- Gauntlets of Insane Calculations
                { 6, 104632 }, -- Iyyokuk's Hereditary Seal
                { 7, 104628 }, -- Kil'ruk's Band of Ascendancy
                { 8, 104636 }, -- Skeer's Bloodsoaked Talisman
                { 16, 99712 }, -- Leggings of the Cursed Conqueror
                { 17, 99713 }, -- Leggings of the Cursed Protector
                { 18, 99726 }, -- Leggings of the Cursed Vanquisher
                { 20, 104627 }, -- Hisek's Reserve Longbow
                { 21, 104637 }, -- Kil'ruk's Furious Blade
                { 22, 104629 }, -- Korven's Crimson Crescent
                { 23, 104631 }, -- Rik'kal's Bloody Scalpel
                { 25, 104165, "pet1334"  }, -- Kovok
                { 27, "ac8531" },
                { 28, "ac8481" },
            },
        },
        {	--SoOGarrosh
            EncounterJournalID = 869,
            ContentPhaseMoP = 5,
            npcId = 71865,
            [CELESTIAL_DIFF] = {
                { 1, 105149 }, -- Ebon Ritual Hood
                { 2, 105148 }, -- Belt of the Broken Pact
                { 3, 105138 }, -- Kor'kron Elite Skullmask
                { 4, 105154 }, -- Hopeglow Spaulders
                { 5, 105137 }, -- Cord of Black Dreams
                { 6, 105153 }, -- Seal of Karmic Return
                { 7, 105155 }, -- Cowl of Smoking Dreams
                { 8, 105140 }, -- Penetrating Gaze of Y'Shaarj
                { 9, 105141 }, -- Shoulderguards of Intended Power
                { 10, 105139 }, -- Chestguard of Relentless Tyranny
                { 11, 105145 }, -- Greathelm of the Warchief
                { 12, 105157 }, -- Mantle of Looming Darkness
                { 13, 105143 }, -- Spaulders of the Fallen Warchief
                { 14, 105156 }, -- Chestplate of Fallen Passion
                { 15, 105142 }, -- Legplates of Unthinking Strife
                { 16, 105861 }, -- Essence of the Cursed Conqueror
                { 17, 105860 }, -- Essence of the Cursed Protector
                { 18, 105862 }, -- Essence of the Cursed Vanquisher
                { 20, 105150 }, -- Black Blood of Y'Shaarj
                { 21, 105147 }, -- Curse of Hubris
                { 23, 105151 }, -- Horned Mace of the Old Ones
                { 24, 105136 }, -- Kor'kron Spire of Supremacy
                { 25, 105146 }, -- Xal'atoh, Desecrated Image of Gorehowl
                { 26, 105152 }, -- Revelations of Y'Shaarj
            },
            [NORMAL_DIFF] = {
                { 1, 103901 }, -- Ebon Ritual Hood
                { 2, 103856 }, -- Belt of the Broken Pact
                { 3, 103729 }, -- Kor'kron Elite Skullmask
                { 4, 103925 }, -- Hopeglow Spaulders
                { 5, 103928 }, -- Cord of Black Dreams
                { 6, 103906 }, -- Seal of Karmic Return
                { 7, 103950 }, -- Cowl of Smoking Dreams
                { 8, 103931 }, -- Penetrating Gaze of Y'Shaarj
                { 9, 103837 }, -- Shoulderguards of Intended Power
                { 10, 103963 }, -- Chestguard of Relentless Tyranny
                { 11, 103840 }, -- Greathelm of the Warchief
                { 12, 103944 }, -- Mantle of Looming Darkness
                { 13, 103784 }, -- Spaulders of the Fallen Warchief
                { 14, 103785 }, -- Tusks of Mannoroth
                { 15, 103958 }, -- Chestplate of Fallen Passion
                { 16, 104311 }, -- Legplates of Unthinking Strife
                { 18, 105858 }, -- Essence of the Cursed Conqueror
                { 19, 105857 }, -- Essence of the Cursed Protector
                { 20, 105859 }, -- Essence of the Cursed Vanquisher
                { 22, 102310 }, -- Black Blood of Y'Shaarj
                { 23, 102307 }, -- Curse of Hubris
                { 25, 103937 }, -- Horned Mace of the Old Ones
                { 26, 103974 }, -- Kor'kron Spire of Supremacy
                { 27, 103649 }, -- Xal'atoh, Desecrated Image of Gorehowl
                { 28, 103920 }, -- Revelations of Y'Shaarj
                { 101, 104404 }, -- Hellscream's Cleaver
                { 102, 104405 }, -- Hellscream's Decapitator
                { 103, 104401 }, -- Hellscream's Doomblade
                { 104, 104403 }, -- Hellscream's Pig Sticker
                { 105, 104400 }, -- Hellscream's Razor
                { 106, 104406 }, -- Hellscream's War Staff
                { 107, 104399 }, -- Hellscream's Warbow
                { 108, 104402 }, -- Hellscream's Warmace
                { 109, 104409 }, -- Hellscream's Barrier
                { 110, 104407 }, -- Hellscream's Shield Wall
                { 111, 104408, [ATLASLOOT_IT_FILTERIGNORE] = true }, -- Hellscream's Tome of Destruction
                { 116, "ac8537" },
                { 117, [ATLASLOOT_IT_ALLIANCE] = "ac8679", [ATLASLOOT_IT_HORDE] = "ac8680" },
            },
            [HEROIC_DIFF] = {
                { 1, 104651 }, -- Ebon Ritual Hood
                { 2, 104650 }, -- Belt of the Broken Pact
                { 3, 104640 }, -- Kor'kron Elite Skullmask
                { 4, 104656 }, -- Hopeglow Spaulders
                { 5, 104639 }, -- Cord of Black Dreams
                { 6, 104655 }, -- Seal of Karmic Return
                { 7, 104657 }, -- Cowl of Smoking Dreams
                { 8, 104642 }, -- Penetrating Gaze of Y'Shaarj
                { 9, 104643 }, -- Shoulderguards of Intended Power
                { 10, 104641 }, -- Chestguard of Relentless Tyranny
                { 11, 104647 }, -- Greathelm of the Warchief
                { 12, 104659 }, -- Mantle of Looming Darkness
                { 13, 104645 }, -- Spaulders of the Fallen Warchief
                { 14, 104646 }, -- Tusks of Mannoroth
                { 15, 104658 }, -- Chestplate of Fallen Passion
                { 16, 104644 }, -- Legplates of Unthinking Strife
                { 18, 105867 }, -- Essence of the Cursed Conqueror
                { 19, 105866 }, -- Essence of the Cursed Protector
                { 20, 105868 }, -- Essence of the Cursed Vanquisher
                { 22, 104652 }, -- Black Blood of Y'Shaarj
                { 23, 104649 }, -- Curse of Hubris
                { 25, 104653 }, -- Horned Mace of the Old Ones
                { 26, 104638 }, -- Kor'kron Spire of Supremacy
                { 27, 104648 }, -- Xal'atoh, Desecrated Image of Gorehowl
                { 28, 104654 }, -- Revelations of Y'Shaarj
                { 30, 104253 }, -- Kor'kron Juggernaut
                { 101, 105685 }, -- Hellscream's Cleaver
                { 102, 105692 }, -- Hellscream's Decapitator
                { 103, 105691 }, -- Hellscream's Doomblade
                { 104, 105686 }, -- Hellscream's Pig Sticker
                { 105, 105684 }, -- Hellscream's Razor
                { 106, 105690 }, -- Hellscream's War Staff
                { 107, 105683 }, -- Hellscream's Warbow
                { 108, 105688 }, -- Hellscream's Warmace
                { 109, 105687 }, -- Hellscream's Barrier
                { 110, 105693 }, -- Hellscream's Shield Wall
                { 111, 105689, [ATLASLOOT_IT_FILTERIGNORE] = true }, -- Hellscream's Tome of Destruction
                { 116, "ac8537" },
                { 117, [ATLASLOOT_IT_ALLIANCE] = "ac8679", [ATLASLOOT_IT_HORDE] = "ac8680" },
                { 118, "ac8482" },
            },
        },
        {	--SoOShared
            name = AL["Shared Boss Loot"],
            ContentPhaseMoP = 5,
            ExtraList = true,
            [CELESTIAL_DIFF] = {
                { 1, 104271 }, -- Coalesced Turmoil
                { 2, 104275 }, -- Twisted Treasures of the Vale
                { 3, 105824 }, -- Aeth's Swiftcinder Cloak
                { 4, 105816 }, -- Brave Niunai's Cloak
                { 5, 105812 }, -- Cape of the Alpha
                { 6, 105815 }, -- Drape of the Omega
                { 7, 105825 }, -- Turtleshell Greatcloak
                { 16, 105813 }, -- Kalaena's Arcane Handwraps
                { 17, 105814 }, -- Seebo's Sainted Touch
                { 18, 105818 }, -- Crimson Gauntlets of Death
                { 19, 105817 }, -- Siid's Silent Stranglers
                { 20, 105819 }, -- Keengrip Arrowpullers
                { 21, 105820 }, -- Marco's Crackling Gloves
                { 22, 105823 }, -- Gauntlets of Discarded Time
                { 23, 105821 }, -- Romy's Reliable Grips
                { 24, 105822 }, -- Zoid's Molten Gauntlets
            },
            [HEROIC_DIFF] = {
                { 1, 105856 }, -- Echoes of War
                { 3, 105841 }, -- Kalaena's Arcane Handwraps
                { 4, 105842 }, -- Seebo's Sainted Touch
                { 5, 105846 }, -- Crimson Gauntlets of Death
                { 6, 105845 }, -- Siid's Silent Stranglers
                { 7, 105847 }, -- Keengrip Arrowpullers
                { 8, 105848 }, -- Marco's Crackling Gloves
                { 9, 105851 }, -- Gauntlets of Discarded Time
                { 10, 105849 }, -- Romy's Reliable Grips
                { 11, 105850 }, -- Zoid's Molten Gauntlets
            },
        },
        {	--SoOTrash
            name = AL["Trash Mobs"],
            ContentPhaseMoP = 5,
            ExtraList = true,
            [NORMAL_DIFF] = {
                { 1, 103846 }, -- Aeth's Swiftcinder Cloak
                { 2, 103960 }, -- Brave Niunai's Cloak
                { 3, 103935 }, -- Cape of the Alpha
                { 4, 103770 }, -- Drape of the Omega
                { 5, 103800 }, -- Turtleshell Greatcloak
                { 7, 103854 }, -- Kalaena's Arcane Handwraps
                { 8, 103753 }, -- Seebo's Sainted Touch
                { 9, 103859 }, -- Crimson Gauntlets of Death
                { 10, 103832 }, -- Siid's Silent Stranglers
                { 11, 103781 }, -- Keengrip Arrowpullers
                { 12, 103764 }, -- Marco's Crackling Gloves
                { 13, 103791 }, -- Gauntlets of Discarded Time
                { 14, 103818 }, -- Romy's Reliable Grips
                { 15, 103734 }, -- Zoid's Molten Gauntlets
                { 16, 105745 }, -- Kor'kron Dark Shaman Cowl
                { 17, 105747 }, -- Kor'kron Dark Shaman Shoulder
                { 18, 105743 }, -- Kor'kron Dark Shaman Vestment
                { 19, 105748 }, -- Kor'kron Dark Shaman Bracers
                { 20, 105744 }, -- Kor'kron Dark Shaman Gloves
                { 21, 105741 }, -- Kor'kron Dark Shaman Belt
                { 22, 105746 }, -- Kor'kron Dark Shaman Kilt
                { 23, 105742 }, -- Kor'kron Dark Shaman Treads
            },
        },
        T16_SET,
        {	--ACPage
            name = AL["Achievements"],
            ContentPhaseMoP = 5,
            TableType = AC_ITTYPE,
            ExtraList = true,
            CoinTexture = "Achievement",
            [NORMAL_DIFF] = {
                { 1, 8454 },
                { 2, 8536 },
                { 3, 8532 },
                { 4, 8530 },
                { 5, 8453 },
                { 6, 8538 },
                { 7, 8527 },
                { 8, 8531 },
                { 17, 8528 },
                { 18, 8521 },
                { 19, 8520 },
                { 20, 8448 },
                { 21, 8529 },
                { 22, 8543 },
                { 23, 8537 },
                { 10, 8458 },
                { 25, 8459 },
                { 11, 8461 },
                { 26, 8462 },
            },
            [HEROIC_DIFF] = {
                { 1, 8463 },
                { 2, 8465 },
                { 3, 8466 },
                { 4, 8467 },
                { 5, 8468 },
                { 6, 8469 },
                { 7, 8470 },
                { 16, 8471 },
                { 17, 8472 },
                { 18, 8478 },
                { 19, 8479 },
                { 20, 8480 },
                { 21, 8481 },
                { 22, 8482 },
            },
        },
    },
}
